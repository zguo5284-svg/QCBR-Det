# QCBR-Det

**Quality Calibration and Context--Boundary Refinement for Cross-Domain Few-Shot Object Detection**

Research code and recorded results for the fixed QCBR-Det configuration. The detector uses **MMGroundingDINO-B / Swin-B** with the **hybrid ensemble decoder (HED) from FT-FSOD**, and three additions: **QCAL**, **OCCA**, and **SABR**. HED is an existing component, not a new contribution of this work. This is not the earlier VFMDETR/ResNet50 or DCLF-Det implementation.

## Method

- **HED**: the FT-FSOD hybrid ensemble decoder (one shared serial layer and five parallel layers).
- **QCAL**: localization-quality estimation from query and region features, used to adjust detection scores.
- **OCCA**: object--context feature comparison and bounded residual class-score adjustment; no extra contrastive-learning loss is implied.
- **SABR**: scale-aware boundary pooling and size-relative residual box refinement.

Stage I adapts the detector and QCAL for 100 epochs (the backbone, language model and feature encoder have frozen parameter updates during the first 50). Stage II freezes that detector and QCAL and trains only OCCA/SABR for 100 epochs. The fixed method uses quality/agreement/shot-conditioned residual gating, zero-initialized residual outputs and residual regularization. All supervision comes from annotated support images. Final epochs are used, not checkpoints selected by test AP.

See [implementation and protocol](docs/PROTOCOL.md), [reproduction instructions](docs/REPRODUCE.md), and [release scope](docs/RELEASE_SCOPE.md).

## Main results

COCO bounding-box AP@[0.50:0.05:0.95], in percent. Each domain entry is the arithmetic mean over training seeds 0, 1 and 2, using fixed support splits. The final column gives mean ± sample SD of the three seed-wise six-domain averages.

| Setting | ArTaxOr | Clipart1k | DIOR | DeepFish | NEU-DET | UODD | Average |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1-shot | 36.68 | 56.89 | 20.00 | 40.04 | 10.67 | 21.70 | 31.00 ± 0.57 |
| 5-shot | 69.32 | 57.61 | 29.48 | 36.97 | 18.79 | 25.30 | 39.58 ± 0.41 |
| 10-shot | 74.28 | 52.60 | 30.96 | 44.66 | 22.60 | 30.48 | 42.60 ± 0.31 |

All 54 per-run records, their evaluation metadata, and derived CSV tables are included. Averages are calculated from unrounded AP values. `FISH` and `clipart1k` in historical records denote DeepFish and Clipart1k.

### Same-framework budget control

| Setting | HED-200 | QCBR-Det | Paired mean difference (percentage points) |
|---|---:|---:|---:|
| 1-shot | 31.03 ± 1.09 | 31.00 ± 0.57 | -0.03 |
| 5-shot | 39.49 ± 0.33 | 39.58 ± 0.41 | +0.09 |
| 10-shot | 40.54 ± 0.82 | 42.60 ± 0.31 | +2.06 |

The strongest controlled evidence is the 10-shot improvement; the low-shot averages do not establish a universal gain. The HED-200 control matches nominal training epochs, not identical trainable parameters or compute. Cross-paper comparisons also differ in backbone, pretraining and possibly support protocol. Fixed-split seed variation is not support-resampling variation. Previously inspected test data remain exploratory; these records do not constitute an untouched independent confirmation.

## Contents

```text
frozen/experiments/    Historical fixed code/configs and supplementary experiment implementations
third_party/FT-FSOD/   Retained FT-FSOD/OpenMMLab source snapshot and Apache-2.0 license
results/raw/          Recorded result JSON (generic cloud paths replaced with placeholders)
results/tables/       Recomputed main results, controls and ablation CSVs
results/training_stability/  Logged-loss summaries and plot data
figures/              Architecture, motivation and non-image experimental charts
provenance/           Frozen-code hashes, source snapshot and result provenance
tools/                CPU result verification and new release preparation utilities
environment/          Historical package versions and core runtime requirements
docs/                 Reproduction, protocol and attribution notes
```

## Verify results without a GPU

Only the Python standard library is required:

```bash
python tools/verify_results.py
python tools/export_tables.py
```

The first command checks the code/result manifests, exact run grids and recomputed statistics. The second regenerates CSVs from the recorded JSON; it does not train or select models. New release utilities are distinct from the frozen experiment implementation and are not claimed to have been GPU-retrained during packaging.

## Reproduce training

Use Linux, the historical CUDA/PyTorch/OpenMMLab environment and four GPUs as described in [REPRODUCE.md](docs/REPRODUCE.md). Obtain datasets and pretrained assets from their respective owners. **No datasets, pretrained/trained model weights, credentials or cloud environment binaries are redistributed here.** Hashes of historical support annotations and checkpoints are evidence identifiers, not downloadable files.

## Attribution and licensing

We acknowledge [FT-FSOD](https://github.com/Intellindust-AI-Lab/FT-FSOD), [MMDetection / MMGroundingDINO](https://github.com/open-mmlab/mmdetection), and their dependencies. See [THIRD_PARTY.md](THIRD_PARTY.md). Upstream files retain their notices and Apache-2.0 terms. No blanket license grant is inferred for newly authored QCBR-Det files; see [LICENSE](LICENSE). Dataset and pretrained-model licenses apply independently. A paper citation will be added once bibliographic details are finalized; no published acceptance is implied.
