# Reproduction

## Scope

The frozen files are the actual retained experiment implementations, not a rewritten approximation. They contain historical generic cloud paths. The new helpers below relocate those paths to a **new** workspace without modifying the frozen public copies. They are packaging conveniences: their syntax and CPU result processing are checked, but no fresh GPU training was performed to validate this release. Original historical checkpoints/rank states are not shipped, and must not be resumed through a path-rewritten workspace. Reported AP is the recorded experiment evidence, not a claim of a fresh clean-room reproduction.

## Environment

The retained experiment environment used Linux, Python 3.9.25, PyTorch 2.1.0+cu121, torchvision 0.16.0, MMCV 2.1.0, MMEngine 0.10.7, MMDetection 3.3.0, NumPy 1.26.4 and transformers 4.44.2. Four distributed ranks and batch size 1/rank were fixed. The later cloud environment inventory reported four logical 32-GB GPUs; timing is specific to that environment.

Create an isolated environment. Install the CUDA-compatible torch/torchvision and MMCV compiled operators first, then the core dependencies in `environment/requirements-core.txt`. `environment/historical_pip_versions.txt` is a historical version inventory, **not** a portable installation lock: unrelated packages may be present and local file/editable references were omitted. Do not substitute the current upstream FT-FSOD README's newer package versions and call them the exact experimental environment.

The retained `third_party/FT-FSOD/mmdet` must precede the installed MMDetection Python source on `PYTHONPATH`; it contains HED-specific detector/head/transform changes. The installed mmdet package supplies metadata/dependencies while imports resolve to the snapshot. Test the MMCV CUDA operators in the actual environment before training. No automatic dependency downloads or installations are performed by the release tools.

## Assets and data

Obtain the MMGroundingDINO-B checkpoint and BERT assets from their original providers, following the [FT-FSOD instructions](https://github.com/Intellindust-AI-Lab/FT-FSOD). The checkpoint filename is `grounding_dino_swin-b_pretrain_all-f9818a7c.pth`, SHA-256:

```text
f9818a7c6a4591d8ecda0d54491b143c5f1aedc64c21eb63822a32eb4f408aa1
```

Dataset preparation follows the original six-domain benchmark. Each folder is expected to contain `train/`, `test/`, and `annotations/{1_shot,5_shot,10_shot,test}.json`. Folder names are `ArTaxOr`, `clipart1k`, `DIOR`, `FISH`, `NEU-DET`, and `UODD`. Do not regenerate support samples for the fixed-split main experiment. Compare the original support and test hashes in `results/raw/ORIGINAL_DATA_AUDIT.json`; acquiring a similarly named dataset does not ensure the same split. Dataset/license restrictions are the reason raw images and annotations are not redistributed here.

```text
/data/datasets/ArTaxOr/{train,test,annotations}/...
/data/datasets/clipart1k/{train,test,annotations}/...
/data/datasets/DIOR/{train,test,annotations}/...
/data/datasets/FISH/{train,test,annotations}/...
/data/datasets/NEU-DET/{train,test,annotations}/...
/data/datasets/UODD/{train,test,annotations}/...
/data/assets/grounding_dino_swin-b_pretrain_all-f9818a7c.pth
/data/assets/bert-base-uncased/...
```

From this repository, prepare a new Linux layout (all paths are examples):

```bash
python tools/prepare_workspace.py --workspace /data/qcbr_run \
  --datasets /data/datasets --assets /data/assets
python /data/qcbr_run/experiments/qcal_hed_20261006/prepare_data.py
```

The second command audits files and creates integer-ID views; it does not modify dataset originals. It writes a new `DATA_AUDIT.json`. Check its source/view hashes against the published audit before starting the main run. Differences require investigation, not silent replacement. Keep at least the historical 80-GiB free-space guard plus enough space for full detector/optimizer/rank-state checkpoints; disk demand exceeds code size substantially.

## Fixed two-phase run

Print commands first (this does not train):

```bash
python tools/run_fixed.py --workspace /data/qcbr_run --domain DIOR --shot 10 --seed 0
```

After validating the environment/data, explicitly start that one configuration:

```bash
python tools/run_fixed.py --workspace /data/qcbr_run --domain DIOR --shot 10 --seed 0 --execute
```

The helper launches four-rank source adaptation for 100 epochs, 100 adapter-only epochs, audited final inference, and fixed-protocol COCO evaluation. It refuses existing work directories and pause markers. It does not run an unbounded queue, alter batch size, resume an existing experiment, select a model by AP, or automatically launch the supplementary studies. Repeat deliberately for each domain, shot in 1/5/10, and seed in 0/1/2 to obtain 54 main results. Each seed gets its own target-adapted source checkpoint; sharing seed 0's source across seeds would measure a different procedure.

Historical seed-0 `evaluate_saved.py` also reports differences to an earlier source-only result inventory. The release evaluator instead computes the same COCO metrics directly from audited final predictions without that historical comparison dependency. It does not modify the model or historical results.

## Pause / resume

The historical hooks save optimizer, four-rank RNG and CachedMixUp caches at checkpoint boundaries; setting `PAUSE_REQUESTED` in the relevant experiment control root requests a safe pause. Preserve the complete workspace for any resume. Manual resume requires the same code/plan hashes, source model, all four rank-state paths and optimizer states. Never automatically remove a user pause marker. See the frozen entry points' `--resume` options; the new helper intentionally refuses automatic restart.

## Supplementary experiments

The corresponding frozen implementations and plans are retained for the 16-combination 10-shot component ablation, HED-100/HED-200 controls, training-strategy ablation, support resampling, mechanism diagnostics, timing and inference sensitivity. These share historical dependencies and plan guards; inspect their plans and paths before a deliberate separate run. Infrastructure launchers and automatic restart scripts are not distributed as executable release entry points. Keep failed/control histories when repeating an audit repair. The repository includes the relevant recorded repair provenance.

For reproducing published numbers without retraining, use `python tools/verify_results.py` and `python tools/export_tables.py`. These operate exclusively on recorded evidence and require no GPU packages.
