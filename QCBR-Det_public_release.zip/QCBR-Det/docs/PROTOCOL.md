# Fixed method and evaluation protocol

## Implementation map

The dated directory names are historical experiment identifiers. They are retained to avoid confusing successive candidates with the fixed paper method.

| Component | Authoritative file |
|---|---|
| QCAL, localization-quality targets and score adjustment | `frozen/experiments/qcal_hed_20261006/qcal_model.py` |
| Stage-I data augmentation, model and optimizer settings | `frozen/experiments/qcal_hed_20261006/qcal_config.py` |
| Progressive freezing, finite-gradient safeguards and exact resume | `frozen/experiments/qcal_hed_20261006/qcal_runtime.py` |
| OCCA, SABR, residual gates, losses and final predictions | `frozen/experiments/qcal_hed_occa_sabr_20261007/extension_model.py` |
| Stage-II frozen-base configuration and adapter optimization | `extension_config.py` and `extension_runtime.py` in the same directory |
| Seeds 1/2 and same-seed source/adapter provenance | `frozen/experiments/qcal_hed_occa_sabr_three_seeds_20261007/` |
| HED and MMGroundingDINO implementation | `third_party/FT-FSOD/mmdet/` |

QCAL combines decoder queries and pooled predicted regions to estimate matched-box IoU. Its multiplier is bounded and shot-dependent; this is localization-quality-aware scoring, not a demonstrated probability calibration guarantee. OCCA compares interior features with surrounding strips. SABR pools multi-level boundary features and predicts box-size-relative corrections. Agreement between decoder branches, predicted quality and shot count bound the corrections. The quality head is reused for refined boxes.

## Training

- MMGroundingDINO-B/Swin-B pretrained checkpoint; HED adopted from FT-FSOD.
- Four distributed ranks, one image/rank, effective batch four, no accumulation or automatic batch/precision fallback.
- Stage I: 100 epochs; backbone/language/feature-encoder updates frozen for epochs 1--50, unfrozen for epochs 51--100. Frozen updates also omit Adam moments rather than relying solely on a zero learning rate.
- Stage II: 100 epochs; corresponding seed's entire final detector/QCAL frozen in evaluation mode; OCCA and SABR trainable only.
- AdamW, base LR 1e-4; backbone/language initial LR 2e-5; cosine floor 1e-6; weight decay 0.05; gradient norm clipping 0.1. Exact augmentation and loss coefficients are in the frozen files.
- Support-only detection/matched-box supervision. No test-time annotation input, AP-based schedule, or best-test-AP checkpoint selection.
- Four-rank RNG and CachedMixUp states accompany resumable checkpoints. Every inference run explicitly loads the full source checkpoint before the adapter-only checkpoint and audits the loaded state.

## Data and metrics

The benchmark contains ArTaxOr (arthropods), Clipart1k, DIOR, DeepFish, NEU-DET and UODD. Original 1/5/10-shot supports and test partitions are retained. IDs are converted to consistent integer views without modifying box coordinates, labels, support membership or original area fields. Identical repeated image rows are deduplicated consistently with COCO's ID dictionary. The original Clipart1k 10-shot motorbike class has seven annotations; it is not silently padded or resampled. Historical data-audit counts/hashes are included as machine-readable provenance, not as an extra manuscript dataset-statistics table.

Evaluation: COCO bbox AP averaged over IoU 0.50, 0.55, ..., 0.95 (percent), maxDets=[1,10,100]. Predictions retain 300 ranked candidates/image before COCO evaluation. Short-side resizing uses 800 with maximum side 1333; no test-time augmentation. AP50/AP75 and scale-specific metrics remain available in the raw records, but the main table reports AP.

For each cell compute mean and sample SD (ddof=1) over training seeds 0/1/2. Compute the six-domain average separately for each seed before reporting its mean/SD. Do not average domain SDs, select the best seed, or aggregate already-rounded entries. Fixed supports isolate optimization variation, not support-draw variation.

## Supplementary checks and interpretation

The 16-row component study enumerates all masks in HED/QCAL/OCCA/SABR order at 10-shot, with three seeds/domain. `0000` means a serial decoder without those four extensions, not an untrained detector. HED-only and serial controls need not rank monotonically. HED is inherited; other components and their interactions are evaluated without claiming each adds AP on every domain.

HED-200 is a same-framework 200-epoch adaptation control. QCBR-Det's second 100 epochs update only adapters, so matching epoch counts does not equal matching FLOPs or trainable capacity. Strategy and mechanism studies cover NEU-DET/DIOR at 1/10-shot. Support resampling uses three alternative support draws, training seed 0, and HED-100 on those two domains; it is exploratory image/near-duplicate-isolated verification, not independent-scene validation or the official main result. Inference sensitivity is a bounded single-seed check and does not change defaults.

Efficiency is measured only for the 20-class DIOR configuration: 171,965 added parameters and approximately 9.8% latency overhead in the recorded setting. The increment is `170665 + 65*C`, ranging from 170,730 to 171,965 parameters over these datasets, because OCCA's output depends on class count. Do not transfer one measured latency to all deployments.

The evidence supports improved 10-shot six-domain mean over the HED-200 control; 1/5-shot differences are -0.03/+0.09 points and do not establish universal low-shot superiority. Descriptive mechanism metrics are not substitutes for AP. Prior benchmark exposure and differences in other papers' backbone/pretraining/support/seed protocols must remain disclosed.
