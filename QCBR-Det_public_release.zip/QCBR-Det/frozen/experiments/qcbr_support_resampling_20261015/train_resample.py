"""Frozen-model four-rank training and exact same-draw inference restoration."""
import argparse
from pathlib import Path
from resample_common import ROOT,SOURCE,read,write,sha,setup,verify,support_for
setup()
import torch
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmdet.utils import register_all_modules
from qcal_runtime import rank,model_of,barrier,ControlledPause
from extension_model import is_adapter
from resample_config import make_config
def run(a):
 verify();register_all_modules(init_default_scope=True)
 cfg=make_config(a.variant,a.domain,a.shot,a.draw,a.phase,a.work_dir,a.engineering)
 import_modules_from_strings(**cfg.custom_imports)
 if a.resume:cfg.load_from=a.resume;cfg.resume=not a.test
 if a.support_smoke:
  assert a.test
  cfg.test_dataloader.dataset.ann_file=str(support_for(a.domain,a.shot,a.draw))
  cfg.test_dataloader.dataset.data_prefix.img=cfg.train_dataloader.dataset.data_prefix.img
  cfg.test_evaluator.ann_file=cfg.test_dataloader.dataset.ann_file
  cfg.test_evaluator.outfile_prefix=str(Path(a.work_dir)/'support_smoke')
 runner=Runner.from_cfg(cfg);assert runner.seed==0
 if not a.test:
  runner.train()
  if rank()==0:write(Path(a.work_dir)/'TRAIN_COMPLETE.json',dict(variant=a.variant,domain=a.domain,shot=a.shot,draw=a.draw,training_seed=0,phase=a.phase,completed_epochs=runner.epoch,completed_iter=runner.iter,plan_sha256=sha(ROOT/'PLAN.json'),support_sha256=sha(support_for(a.domain,a.shot,a.draw)),engineering=a.engineering))
  return
 assert a.resume
 model=model_of(runner);model.init_weights();runner.load_or_resume()
 saved=torch.load(a.resume,map_location='cpu');current=model.state_dict();expected=2 if a.engineering else 100
 assert saved['meta']['seed']==0 and saved['meta']['epoch']==expected
 meta=saved['resampling'];assert (meta['variant'],meta['domain'],meta['shot'],meta['draw'],meta['training_seed'])==(a.variant,a.domain,a.shot,a.draw,0)
 assert meta['support_sha256']==sha(support_for(a.domain,a.shot,a.draw)) and saved['ablation_plan_sha256']==sha(ROOT/'PLAN.json')
 assert all(torch.equal(current[n].cpu(),v) for n,v in saved['state_dict'].items())
 if a.phase=='adapter':
  assert a.variant=='qcbr' and set(saved['state_dict'])=={n for n in current if is_adapter(n)}
  original=torch.load(model.reference_checkpoint,map_location='cpu');assert original['resampling']==meta and original['meta']['epoch']==expected
  assert saved['reference_sha256']==sha(model.reference_checkpoint)
  assert all(torch.equal(current[n].cpu(),original['state_dict'][n]) for n in current if not is_adapter(n))
  del original
 else:assert set(saved['state_dict'])==set(current)
 evidence=dict(rank=rank(),metadata=meta,checkpoint_sha256=sha(a.resume),all_tensors_equal=True,source_before_adapter_verified=a.phase=='adapter')
 gathered=[None]*4;torch.distributed.all_gather_object(gathered,evidence)
 assert {r['rank'] for r in gathered}==set(range(4)) and len({r['checkpoint_sha256'] for r in gathered})==1
 if rank()==0:write(Path(a.work_dir)/'INFERENCE_MODEL_AUDIT_PASS.json',dict(status='PASS',four_ranks_verified=True,ranks=gathered))
 del current,saved
 barrier();runner.test()
 if rank()==0:
  w=Path(a.work_dir);p=w/('support_smoke.bbox.json' if a.support_smoke else 'predictions.bbox.json')
  write(w/'INFERENCE_COMPLETE.json',dict(status='PASS',support_smoke=a.support_smoke,predictions_sha256=sha(p),model_audit_sha256=sha(w/'INFERENCE_MODEL_AUDIT_PASS.json')))
 barrier()
if __name__=='__main__':
 p=argparse.ArgumentParser()
 for n in ['variant','domain','phase','work-dir']:p.add_argument('--'+n,required=True)
 p.add_argument('--shot',type=int,required=True);p.add_argument('--draw',type=int,required=True)
 p.add_argument('--engineering',action='store_true');p.add_argument('--resume');p.add_argument('--test',action='store_true');p.add_argument('--support-smoke',action='store_true')
 try:run(p.parse_args())
 except ControlledPause:
  if torch.distributed.is_initialized():torch.distributed.destroy_process_group()
  raise SystemExit(75)
