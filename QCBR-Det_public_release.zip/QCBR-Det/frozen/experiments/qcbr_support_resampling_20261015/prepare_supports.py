"""Prespecified label-only sampling. No model, predictions or AP access."""
import collections,copy,concurrent.futures,hashlib,math,random,time
import numpy as np
from PIL import Image
from scipy.fft import dctn
from resample_common import ROOT,BASE,SOURCE,read,write,sha,guard
def distance(a,b):return bin(a^b).count('1')
class BK:
 def __init__(self):self.root=None
 def add(self,x):
  if self.root is None:self.root=(x,{});return
  node=self.root
  while True:
   d=distance(x,node[0])
   if not d:return
   if d not in node[1]:node[1][d]=(x,{});return
   node=node[1][d]
 def near(self,x,r=4):
  stack=[self.root] if self.root else []
  while stack:
   v,children=stack.pop();d=distance(x,v)
   if d<=r:return True
   stack.extend(children[k] for k in range(max(1,d-r),d+r+1) if k in children)
  return False
def fingerprint(task):
 split,im,prefix=task;p=(prefix/im['file_name']).resolve()
 assert p.is_relative_to(prefix.resolve()) and p.is_file()
 raw=sha(p)
 with Image.open(p) as image:
  assert image.size==(im['width'],im['height']),('DIMENSION_MISMATCH',str(p),image.size)
  rgb=image.convert('RGB');pixel=hashlib.sha256(str(rgb.size).encode()+rgb.tobytes()).hexdigest()
  values=dctn(np.asarray(rgb.convert('L').resize((32,32),Image.Resampling.LANCZOS),dtype=np.float64),type=2,norm='ortho')[:8,:8].reshape(-1)[1:]
  ph=sum(int(v)<<i for i,v in enumerate(values>np.median(values)))
 return dict(split=split,image_id=str(im['id']),file_name=im['file_name'],byte_sha256=raw,pixel_sha256=pixel,phash=ph)
def build_domain(domain):
 folder=BASE/'datasets'/domain;tr,te=[read(folder/'annotations'/f'{n}.json') for n in ['train','test']]
 classes=read(SOURCE/'DATA_AUDIT.json')['domains'][domain]['classes'];ids={str(x['id']):x for x in tr['images']}
 assert len(ids)==len(tr['images']) and len({str(x['id']) for x in tr['annotations']})==len(tr['annotations'])
 cats={x['id']:x['name'] for x in tr['categories']};assert set(cats.values())==set(classes)
 invalid=set()
 for a in tr['annotations']:
  im=ids[str(a['image_id'])];x,y,w,h=a['bbox']
  if (not all(math.isfinite(v) for v in [x,y,w,h,a.get('area',w*h)]) or x<0 or y<0 or w<1 or h<1 or x+w>im['width'] or y+h>im['height'] or a.get('area',w*h)<=0 or a.get('ignore') or a.get('iscrowd')):invalid.add(str(im['id']))
 cache=ROOT/'image_inventory'/f'{domain}.json';source_hashes={n:sha(folder/'annotations'/f'{n}.json') for n in ['train','test']}
 if cache.exists():
  saved=read(cache);assert saved['source_hashes']==source_hashes;fps=saved['records']
 else:
  tasks=[(split,im,folder/split) for split,data in [('train',tr),('test',te)] for im in data['images']];fps=[]
  with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
   for i,item in enumerate(ex.map(fingerprint,tasks)):
    fps.append(item)
    if i%250==0:guard();write(ROOT/'DATA_PROGRESS.json',dict(domain=domain,phase='IMAGE_FINGERPRINTS',done=i+1,total=len(tasks),at=time.time()))
  write(cache,dict(source_hashes=source_hashes,records=fps))
 tests=[r for r in fps if r['split']=='test'];train=[r for r in fps if r['split']=='train']
 test_names={r['file_name'] for r in tests};test_bytes={r['byte_sha256'] for r in tests};test_pixels={r['pixel_sha256'] for r in tests};tree=BK()
 for r in tests:tree.add(r['phash'])
 excluded={};inventory={r['image_id']:r for r in train}
 for r in train:
  if r['image_id'] in invalid:reason='invalid_annotation_image'
  elif r['file_name'] in test_names:reason='test_filename_match'
  elif r['byte_sha256'] in test_bytes:reason='test_byte_match'
  elif r['pixel_sha256'] in test_pixels:reason='test_pixel_match'
  elif tree.near(r['phash']):reason='test_phash_distance_le4'
  else:continue
  excluded[r['image_id']]=reason
 eligible=collections.defaultdict(list)
 for a in tr['annotations']:
  if str(a['image_id']) not in excluded:eligible[cats[a['category_id']]].append(a)
 assert all(len(eligible[c])>=30 for c in classes),('INSUFFICIENT_POOL',domain,{c:len(eligible[c]) for c in classes})
 audit=dict(source_hashes=source_hashes,classes=classes,train_images=len(train),test_images=len(tests),excluded=excluded,exclusion_counts=dict(collections.Counter(excluded.values())),eligible_instances_per_class={c:len(eligible[c]) for c in classes},draws={})
 for draw in read(ROOT/'PLAN.json')['draws']:
  queues={}
  for c in classes:
   values=sorted(eligible[c],key=lambda a:str(a['id']));seed=int.from_bytes(hashlib.sha256(f'{domain}/{draw}/{c}'.encode()).digest()[:8],'big')
   random.Random(seed).shuffle(values);queues[c]=iter(values)
  selected=[];chosen_ids=set();chosen_images={};first=None
  for round_index in range(10):
   for c in classes:
    for a in queues[c]:
     key=str(a['image_id']);fp=inventory[key]
     if key not in chosen_images and any(fp['byte_sha256']==z['byte_sha256'] or fp['pixel_sha256']==z['pixel_sha256'] or distance(fp['phash'],z['phash'])<=4 for z in chosen_images.values()):continue
     assert str(a['id']) not in chosen_ids
     selected.append(a);chosen_ids.add(str(a['id']));chosen_images[key]=fp;break
    else:raise RuntimeError(('SAMPLER_EXHAUSTED',domain,draw,c,round_index))
   if round_index==0:first=list(selected)
  for shot,anns in [(1,first),(10,selected)]:
   counts=collections.Counter(cats[a['category_id']] for a in anns);assert all(counts[c]==shot for c in classes)
   image_ids=list(dict.fromkeys(str(a['image_id']) for a in anns));imap={key:i+1 for i,key in enumerate(image_ids)}
   images=[dict(copy.deepcopy(ids[key]),id=imap[key]) for key in image_ids];converted=[]
   for i,a in enumerate(anns):
    new=dict(copy.deepcopy(a),id=i+1,image_id=imap[str(a['image_id'])],category_id=classes.index(cats[a['category_id']])+1)
    assert {k:v for k,v in a.items() if k not in ['id','image_id','category_id']}=={k:v for k,v in new.items() if k not in ['id','image_id','category_id']};converted.append(new)
   destination=ROOT/'supports'/str(draw)/domain/f'{shot}_shot.json';value=dict(images=images,annotations=converted,categories=[dict(id=i+1,name=c,supercategory='none') for i,c in enumerate(classes)])
   if destination.exists():assert read(destination)==value,'NEVER_OVERWRITE_DIFFERENT_SUPPORTS'
   else:write(destination,value)
   write(destination.with_name(f'{shot}_provenance.json'),dict(original_image_ids=image_ids,original_annotation_ids=[str(a['id']) for a in anns],sha256=sha(destination),images=len(images),annotations=len(anns),counts=dict(counts),training_seed=0,draw=draw,no_model_or_AP_used=True,nested_1_in_10=True))
   audit['draws'][f'{draw}/{shot}']=dict(images=len(images),annotations=len(anns),sha256=sha(destination))
 audit['test_view_sha256']=sha(read(SOURCE/'DATA_AUDIT.json')['domains'][domain]['splits']['test']['view']);return audit
if __name__=='__main__':
 assert not (ROOT/'SUPPORTS_FROZEN.json').exists(),'Already frozen; never regenerate'
 audits={d:build_domain(d) for d in read(ROOT/'PLAN.json')['domains']};files={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'supports').rglob('*.json')}
 write(ROOT/'DATA_AUDIT.json',dict(status='PASS',domains=audits,no_test_AP_used=True,scene_independence_verified=False));files['DATA_AUDIT.json']=sha(ROOT/'DATA_AUDIT.json')
 write(ROOT/'SUPPORTS_FROZEN.json',dict(status='PASS',files=files,plan_sha256=sha(ROOT/'PLAN.json'),at=time.time()));print('SUPPORTS_FROZEN_PASS',len(files),flush=True)
