"""Only support files, experiment paths and audit hooks differ from frozen recipes."""
from resample_common import ROOT,read,sha,work_for,support_for
from qcal_config import make_config as source_config
from extension_config import make_config as adapter_config
def make_config(v,d,k,draw,phase,work,engineering=False):
 assert v in ['hed','qcbr'] and phase in ['source','adapter'] and (v=='qcbr' or phase=='source')
 cfg=(adapter_config if phase=='adapter' else source_config)(d,k,work,False)
 cfg.randomness.seed=0
 cfg.train_dataloader.dataset.ann_file=str(support_for(d,k,draw))
 cfg.custom_imports.imports+=['ablation_model','ablation_runtime','resample_runtime']
 epochs=2 if engineering else 100;cfg.train_cfg.max_epochs=epochs
 arguments=dict(root=str(ROOT),seed=0,mask='1000' if v=='hed' else '1111',engineering=engineering,
  total_epochs=epochs,variant=v,domain=d,shot=k,draw=draw)
 if phase=='source':
  if v=='hed':
   cfg.model.update(type='AblationSourceDetector',hed=True)
   cfg.model.bbox_head.update(type='AblationSourceHead',hed=True,qcal=False)
  cfg.custom_hooks=[dict(type='AblationStageHook',root=str(ROOT),stage2_epoch=1 if engineering else 50,total_epochs=epochs),dict(type='ResampleSourceHook',**arguments)]
 else:
  cfg.model.reference_checkpoint=str(work_for(v,d,k,draw,'source',engineering)/'checkpoint_latest.pth')
  cfg.custom_hooks=[dict(type='ResampleAdapterHook',**arguments)]
 return cfg
