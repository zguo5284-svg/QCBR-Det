"""Existing optimization/checkpoint equations, plus support-draw metadata audits."""
from pathlib import Path
import random
import numpy as np
import torch
from mmengine.registry import HOOKS
from ablation_runtime import AblationSourceHook,AblationAdapterHook
from qcal_runtime import model_of,rank,mixup_transforms
from resample_common import ROOT,read,write,sha,support_for
def exact(a,b):
 if isinstance(a,torch.Tensor):return isinstance(b,torch.Tensor) and torch.equal(a.detach().cpu(),b.detach().cpu())
 if hasattr(a,'tensor') and isinstance(a.tensor,torch.Tensor):return type(a) is type(b) and torch.equal(a.tensor.detach().cpu(),b.tensor.detach().cpu())
 if isinstance(a,np.ndarray):return isinstance(b,np.ndarray) and np.array_equal(a,b)
 if isinstance(a,dict):return isinstance(b,dict) and a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,(list,tuple)):return isinstance(b,(list,tuple)) and len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
class MetadataMixin:
 def __init__(self,variant,domain,shot,draw,**kwargs):
  super().__init__(**kwargs);self.variant=variant;self.domain=domain;self.shot=shot;self.draw=draw
 def metadata(self):
  return dict(variant=self.variant,domain=self.domain,shot=self.shot,draw=self.draw,training_seed=0,support_sha256=sha(support_for(self.domain,self.shot,self.draw)))
 def after_load_checkpoint(self,runner,checkpoint):
  super().after_load_checkpoint(runner,checkpoint)
  if getattr(runner,'_resume',False):assert checkpoint['resampling']==self.metadata()
 def before_train(self,runner):
  assert runner.seed==0 and runner.cfg.train_dataloader.dataset.ann_file==str(support_for(self.domain,self.shot,self.draw))
  super().before_train(runner)
  if getattr(runner,'_resume',False):
   saved=torch.load(runner.cfg.load_from,map_location='cpu');model=model_of(runner)
   assert all(torch.equal(model.state_dict()[n].detach().cpu(),v) for n,v in saved['state_dict'].items())
   optim=runner.optim_wrapper.optimizer.state_dict();assert exact(optim['state'],saved['optimizer']['state'])
   # The higher-priority stage hook applies the deterministic NEXT-epoch LR before this hook.
   without_schedule=lambda g:{k:v for k,v in g.items() if k not in ['lr','_stage_frozen']}
   assert exact([without_schedule(g) for g in optim['param_groups']],[without_schedule(g) for g in saved['optimizer']['param_groups']])
   state=torch.load(saved['ablation_rank_states'][rank()]['path'],map_location='cpu')
   assert exact(random.getstate(),state['python_rng']) and exact(np.random.get_state(),state['numpy_rng'])
   assert torch.equal(torch.get_rng_state(),state['torch_rng']) and torch.equal(torch.cuda.get_rng_state().cpu(),state['cuda_rng'].cpu())
   assert all(exact(t.results_cache,state['augmentation_caches'][i]) for i,t in mixup_transforms(runner))
   write(Path(runner.work_dir)/f'RESUME_INTEGRITY_PASS_rank{rank()}.json',dict(status='PASS',model_optimizer_moments_RNG_and_cache_exact=True,next_epoch_LR_applied_by_original_stage_hook=True,metadata=self.metadata()))
 def before_save_checkpoint(self,runner,checkpoint):
  super().before_save_checkpoint(runner,checkpoint);checkpoint['resampling']=self.metadata()
@HOOKS.register_module()
class ResampleSourceHook(MetadataMixin,AblationSourceHook):pass
@HOOKS.register_module()
class ResampleAdapterHook(MetadataMixin,AblationAdapterHook):pass
