import hashlib
import itertools
import json
import os
import shutil
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=Path('/root/autodl-tmp/vfmdetr_repro')
SOURCE=BASE/'experiments/qcal_hed_20261006'
EXT=BASE/'experiments/qcal_hed_occa_sabr_20261007'
ABL=BASE/'experiments/qcal_hed_ablation_10shot_20261008'
PY=BASE/'software/envs/qcal_hed/bin/python'
CODE=['PLAN.json','resample_common.py','prepare_supports.py','resample_config.py','resample_runtime.py','train_resample.py','evaluate_resample.py','driver.py']
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp')
 t.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False));t.replace(p)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def setup():
 paths=[ROOT,EXT,SOURCE,SOURCE/'FT-FSOD',ABL];sys.path[:0]=list(map(str,paths))
 os.environ.update(PYTHONPATH=':'.join(map(str,paths)),OMP_NUM_THREADS='4',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',CUBLAS_WORKSPACE_CONFIG=':4096:8',NCCL_DEBUG='WARN')
def guard():
 assert not (ROOT/'PAUSE_REQUESTED').exists(),'USER_OR_SAFETY_PAUSE'
 assert shutil.disk_usage(ROOT).free>80*1024**3,'LOW_DISK_SPACE'
def verify():
 for root in [SOURCE,EXT,ABL,ROOT]:
  for n,h in read(root/'FROZEN_MANIFEST.json').items():assert sha(root/n)==h,('FROZEN_CHANGED',str(root/n))
 for n,h in read(ROOT/'SUPPORTS_FROZEN.json')['files'].items():assert sha(ROOT/n)==h,('SUPPORT_CHANGED',n)
def jobs():
 p=read(ROOT/'PLAN.json');return itertools.product(p['draws'],p['shots'],p['domains'],p['variants'])
def work_for(v,d,k,s,phase,engineering=False):return ROOT/('engineering' if engineering else 'runs')/str(s)/d/f'{k}shot'/v/phase
def support_for(d,k,s):return ROOT/'supports'/str(s)/d/f'{k}_shot.json'
