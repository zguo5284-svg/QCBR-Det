"""Inherited optimization/checkpoints; extra auditing does not change equations."""
from pathlib import Path
import random
import numpy as np
import torch
from mmengine.registry import HOOKS
from ablation_runtime import AblationSourceHook
from qcal_runtime import model_of,rank,barrier,mixup_transforms
from control_common import ROOT,read,write,sha,reference,support
def exact(a,b):
 if isinstance(a,torch.Tensor):return isinstance(b,torch.Tensor) and torch.equal(a.detach().cpu(),b.detach().cpu())
 if hasattr(a,'tensor') and isinstance(a.tensor,torch.Tensor):return type(a) is type(b) and torch.equal(a.tensor.detach().cpu(),b.tensor.detach().cpu())
 if isinstance(a,np.ndarray):return isinstance(b,np.ndarray) and np.array_equal(a,b)
 if isinstance(a,dict):return isinstance(b,dict) and a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,(list,tuple)):return isinstance(b,(list,tuple)) and len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def verify_rng_cache(runner,state):
 assert exact(random.getstate(),state['python_rng']) and exact(np.random.get_state(),state['numpy_rng'])
 assert torch.equal(torch.get_rng_state(),state['torch_rng'])
 assert torch.equal(torch.cuda.get_rng_state().cpu(),state['cuda_rng'].cpu())
 assert all(exact(t.results_cache,state['augmentation_caches'][i]) for i,t in mixup_transforms(runner))
@HOOKS.register_module()
class ControlCheckpointHook(AblationSourceHook):
 def __init__(self,variant,domain,shot,**kwargs):
  super().__init__(**kwargs);self.variant=variant;self.domain=domain;self.shot=shot
 def metadata(self):
  return dict(variant=self.variant,domain=self.domain,shot=self.shot,seed=self.seed,support_sha256=sha(support(self.domain,self.shot)),reference_sha256=reference(self.domain,self.shot,self.seed)['checkpoint']['sha256'])
 def after_load_checkpoint(self,runner,checkpoint):
  super().after_load_checkpoint(runner,checkpoint)
  if getattr(runner,'_resume',False):assert checkpoint['lowshot_control']==self.metadata()
 def before_train(self,runner):
  assert runner.seed==self.seed and runner.cfg.train_dataloader.dataset.ann_file==support(self.domain,self.shot)
  model=model_of(runner)
  assert not any(hasattr(model.bbox_head,n) for n in ['quality_net','occa','sabr'])
  if getattr(runner,'_resume',False):
   super().before_train(runner)
   saved=torch.load(runner.cfg.load_from,map_location='cpu')
   assert all(torch.equal(model.state_dict()[n].detach().cpu(),v) for n,v in saved['state_dict'].items())
   optim=runner.optim_wrapper.optimizer.state_dict();assert exact(optim['state'],saved['optimizer']['state'])
   strip=lambda g:{k:v for k,v in g.items() if k not in ['lr','_stage_frozen']}
   assert exact([strip(g) for g in optim['param_groups']],[strip(g) for g in saved['optimizer']['param_groups']])
   state=torch.load(saved['ablation_rank_states'][rank()]['path'],map_location='cpu');verify_rng_cache(runner,state)
   write(Path(runner.work_dir)/f'RESUME_INTEGRITY_PASS_rank{rank()}.json',dict(status='PASS',model_optimizer_moments_RNG_and_cache_exact=True,next_epoch_LR_applied_by_original_stage_hook=True,metadata=self.metadata()))
   del saved,state;barrier();return
  ref=reference(self.domain,self.shot,self.seed);path=Path(ref['checkpoint']['path'])
  assert sha(path)==ref['checkpoint']['sha256']
  saved=torch.load(path,map_location='cpu');current=model.state_dict()
  assert saved['meta']['seed']==self.seed and saved['meta']['epoch']==100
  assert saved['ablation_mask']=='1000' and saved['ablation_phase']=='source'
  assert saved['control_variant']=='hed100' and saved['control_domain']==self.domain and saved['control_shot']==self.shot
  assert set(current)==set(saved['state_dict'])
  assert all(torch.equal(t.cpu(),saved['state_dict'][n]) for n,t in current.items())
  assert not runner.optim_wrapper.optimizer.state,'Phase boundary uses fresh AdamW moments, as in prior HED200'
  info=saved['ablation_rank_states'][rank()];assert sha(info['path'])==info['sha256']
  state=torch.load(info['path'],map_location='cpu');assert state['epoch']==100
  for i,t in mixup_transforms(runner):t.results_cache=state['augmentation_caches'][i]
  random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
  torch.set_rng_state(state['torch_rng']);torch.cuda.set_rng_state(state['cuda_rng']);verify_rng_cache(runner,state)
  evidence=dict(status='PASS',rank=rank(),every_model_tensor_equal=True,fresh_optimizer=True,original_epoch=100,
   original_iter=ref['checkpoint']['completed_iter'],RNG_cache_exact=True,metadata=self.metadata())
  write(Path(runner.work_dir)/f'WARM_START_PASS_rank{rank()}.json',evidence)
  gathered=[None]*4;torch.distributed.all_gather_object(gathered,evidence)
  assert {x['rank'] for x in gathered}==set(range(4)) and all(x['every_model_tensor_equal'] and x['RNG_cache_exact'] and x['fresh_optimizer'] for x in gathered)
  if rank()==0:write(Path(runner.work_dir)/'WARM_START_PASS.json',dict(status='PASS',reference=str(path),reference_sha256=ref['checkpoint']['sha256'],all_four_ranks_verified=True,ranks=gathered))
  if self.engineering:
   self.budget_probe={}
   for prefix in ['backbone.','language_model.','encoder.','decoder.']:
    n,p=next((n,p) for n,p in model.named_parameters() if n.startswith(prefix) and n.endswith('weight'))
    self.budget_probe[n]=p.detach().cpu().clone()
  del saved,state,current;barrier()
 def after_train_iter(self,runner,batch_idx,data_batch=None,outputs=None):
  super().after_train_iter(runner,batch_idx,data_batch,outputs)
  if rank()==0:
   p=Path(runner.work_dir)/'PROGRESS.json';v=read(p);v.update(variant=self.variant,domain=self.domain,shot=self.shot,prior_source_epochs=100);write(p,v)
 def after_train_epoch(self,runner):
  super().after_train_epoch(runner)
  if self.engineering and hasattr(self,'budget_probe') and runner.epoch+1==runner.max_epochs:
   params=dict(model_of(runner).named_parameters());changed={n:not torch.equal(params[n].detach().cpu(),v) for n,v in self.budget_probe.items()}
   assert all(changed.values())
   if rank()==0:write(Path(runner.work_dir)/'BUDGET_ACTIVE_UPDATE_PASS.json',dict(status='PASS',updated=changed,no_frozen_noop_budget=True))
 def before_save_checkpoint(self,runner,checkpoint):
  super().before_save_checkpoint(runner,checkpoint)
  checkpoint.update(control_variant=self.variant,control_domain=self.domain,control_shot=self.shot,prior_source_epochs=100,lowshot_control=self.metadata())
