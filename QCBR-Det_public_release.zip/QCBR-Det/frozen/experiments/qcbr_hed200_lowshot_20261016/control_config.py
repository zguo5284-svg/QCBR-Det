"""Exact prior HED200 second-phase recipe, now with same-shot HED100 references."""
from qcal_config import make_config as original_config
from control_common import ROOT,reference
def make_config(variant,domain,shot,seed,work,engineering=False):
 assert variant=='hed200' and shot in [1,5]
 cfg=original_config(domain,shot,work,False)
 cfg.custom_imports=dict(imports=['ablation_model','ablation_runtime','control_runtime'],allow_failed_imports=False)
 cfg.randomness.seed=seed
 cfg.model.update(type='AblationSourceDetector',hed=True)
 cfg.model.bbox_head.update(type='AblationSourceHead',hed=True,qcal=False)
 epochs=2 if engineering else 100;cfg.train_cfg.max_epochs=epochs
 cfg.custom_hooks=[dict(type='AblationStageHook',root=str(ROOT),stage2_epoch=0,total_epochs=epochs),
  dict(type='ControlCheckpointHook',root=str(ROOT),seed=seed,mask='1000',engineering=engineering,total_epochs=epochs,variant=variant,domain=domain,shot=shot)]
 cfg.load_from=reference(domain,shot,seed)['checkpoint']['path']
 return cfg
