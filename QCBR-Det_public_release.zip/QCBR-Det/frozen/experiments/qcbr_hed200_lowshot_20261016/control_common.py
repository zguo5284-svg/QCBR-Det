"""New low-shot control root; all prior methods, code and records are read-only."""
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parent
BASE=Path('/root/autodl-tmp/vfmdetr_repro')
SOURCE=BASE/'experiments/qcal_hed_20261006'
EXTENSION=BASE/'experiments/qcal_hed_occa_sabr_20261007'
THREE=BASE/'experiments/qcal_hed_occa_sabr_three_seeds_20261007'
ABLATION=BASE/'experiments/qcal_hed_ablation_10shot_20261008'
PRIOR=BASE/'experiments/qcbr_baseline_budget_20261013'
PY=BASE/'software/envs/qcal_hed/bin/python'
DOMAINS=['ArTaxOr','clipart1k','DIOR','FISH','NEU-DET','UODD']
CODE=['PLAN.json','control_common.py','control_config.py','control_runtime.py','train_control.py','evaluate_control.py','driver_control.py']
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=Path(str(p)+'.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False));t.replace(p)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def setup():
 paths=[ROOT,ABLATION,EXTENSION,SOURCE,SOURCE/'FT-FSOD'];sys.path[:0]=list(map(str,paths))
 os.environ.update(PYTHONPATH=':'.join(map(str,paths)),OMP_NUM_THREADS='4',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',CUBLAS_WORKSPACE_CONFIG=':4096:8',NCCL_DEBUG='WARN')
def guard():
 assert not (ROOT/'PAUSE_REQUESTED').exists(),'USER_OR_SAFETY_PAUSE'
 assert shutil.disk_usage(ROOT).free>80*1024**3,'LOW_DISK_SPACE'
def reference(domain,shot,seed):
 assert domain in DOMAINS and shot in [1,5] and seed in [0,1,2]
 return next(x for x in read(PRIOR/'RESULTS.json')['results'] if (x['variant'],x['domain'],x['shot'],x['seed'])==('hed100',domain,shot,seed))
def support(domain,shot):return read(SOURCE/'DATA_AUDIT.json')['domains'][domain]['splits'][f'{shot}_shot']['view']
def work_for(v,d,k,s,engineering=False):
 assert v=='hed200' and d in DOMAINS and k in [1,5] and s in [0,1,2]
 return ROOT/('engineering' if engineering else 'runs')/v/f'{d}_{k}shot_seed{s}'
def jobs():
 for seed,shot,domain in itertools.product([0,1,2],[1,5],DOMAINS):yield 'hed200',domain,shot,seed
def verify_frozen():
 for root in [SOURCE,EXTENSION,THREE,ABLATION,PRIOR,ROOT]:
  for n,h in read(root/'FROZEN_MANIFEST.json').items():assert sha(root/n)==h,('FROZEN_CHANGED',str(root/n))
 refs=read(ROOT/'PLAN.json')['references']
 for root,key in [(THREE,'main_results_sha256'),(ABLATION,'ablation_results_sha256'),(PRIOR,'prior_controls_results_sha256')]:
  assert sha(root/'RESULTS.json')==read(root/'ALL_COMPLETE.json')['results_sha256']==refs[key]
 if (ROOT/'INPUTS_FROZEN.json').exists():
  for name,h in read(ROOT/'INPUTS_FROZEN.json')['files'].items():assert sha(name)==h,('SUPPORT_OR_REFERENCE_INDEX_CHANGED',name)
