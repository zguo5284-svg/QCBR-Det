"""Original COCO evaluation, without training feedback or result selection."""
import argparse
import math
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from control_common import ROOT,SOURCE,read,write,sha,reference,work_for
def evaluate(a):
 w=work_for(a.variant,a.domain,a.shot,a.seed);data=read(SOURCE/'DATA_AUDIT.json')['domains'][a.domain]['splits']
 ann=data['test']['view'];pred=w/'predictions.bbox.json';inf=read(w/'INFERENCE_COMPLETE.json');audit=read(w/'INFERENCE_MODEL_AUDIT_PASS.json')
 last=read(w/'LAST_CHECKPOINT.json');done=read(w/'TRAIN_COMPLETE.json')
 assert inf['status']=='PASS' and not inf['support_smoke'] and audit['four_ranks_verified']
 assert inf['predictions_sha256']==sha(pred) and inf['model_audit_sha256']==sha(w/'INFERENCE_MODEL_AUDIT_PASS.json')
 assert last['completed_epoch']==done['completed_epochs']==100 and done['total_detector_epochs']==200 and last['readback_exact']
 assert last['sha256']==sha(last['path']) and done['plan_sha256']==sha(ROOT/'PLAN.json')
 assert done['support_sha256']==sha(data[f'{a.shot}_shot']['view'])
 assert all((x['variant'],x['domain'],x['shot'],x['seed'],x['checkpoint_sha256'])==(a.variant,a.domain,a.shot,a.seed,last['sha256']) for x in audit['ranks'])
 raw=read(ann);predictions=read(pred);ids={x['id'] for x in raw['images']};cats={x['id'] for x in raw['categories']}
 assert len(predictions)==300*len(ids)
 assert all(x['image_id'] in ids and x['category_id'] in cats and math.isfinite(x['score']) and all(math.isfinite(v) for v in x['bbox']) for x in predictions)
 gt=COCO(ann);gt.dataset.setdefault('info',{})
 ev=COCOeval(gt,gt.loadRes(predictions),'bbox');ev.params.imgIds=sorted(ids);ev.params.catIds=sorted(cats);ev.params.maxDets=[1,10,100]
 ev.evaluate();ev.accumulate();ev.summarize()
 names=['AP','AP50','AP75','APs','APm','APl','AR1','AR10','AR100','ARs','ARm','ARl'];metrics={n:(None if v<0 else float(v)*100) for n,v in zip(names,ev.stats)}
 assert all(v is None or math.isfinite(v) for v in metrics.values())
 ref=reference(a.domain,a.shot,a.seed)
 result=dict(variant=a.variant,domain=a.domain,shot=a.shot,seed=a.seed,metrics=metrics,checkpoint=last,warm_start=ref['checkpoint'],
  backbone='Swin-B',source_epochs=200,additional_phase_epochs=100,phase_updates=done['completed_iter'],total_updates=done['completed_iter']+ref['checkpoint']['completed_iter'],
  evaluation_images=len(ids),annotation_sha256=sha(ann),support_annotation_sha256=sha(data[f'{a.shot}_shot']['view']),predictions_sha256=sha(pred),four_rank_inference_weights_verified=True,fixed_support=True,
  plan_sha256=sha(ROOT/'PLAN.json'),metric='COCO bbox AP@[0.50:0.95] (%)',selection='fixed final additional epoch100, no AP selection',budget_interpretation='epoch/update exposure control, not equal GPU time/FLOPs')
 write(w/'RESULT.json',result);write(w/'COMPLETE.json',dict(status='COMPLETE',result_sha256=sha(w/'RESULT.json')))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--variant',required=True);p.add_argument('--domain',required=True);p.add_argument('--shot',type=int,required=True);p.add_argument('--seed',type=int,required=True)
 evaluate(p.parse_args())
