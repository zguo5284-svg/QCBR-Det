"""Frozen QCAL-HED with two zero-output, bounded residual adapters.

Only annotated support instances provide new classification/localization labels.
Context rings are descriptive features, not background supervision.
"""
import torch
from torch import nn
from torch.nn import functional as F
from mmcv.ops import roi_align
from mmengine.structures import InstanceData
from mmdet.registry import MODELS
from mmdet.structures.bbox import bbox_cxcywh_to_xyxy, bbox_overlaps
from mmdet.models.dense_heads.atss_vlfusion_head import convert_grounding_to_cls_scores
from qcal_model import QCalHEDDetector, QCalHEDHead

ADAPTER_PREFIXES = ('bbox_head.occa.', 'bbox_head.sabr.')


def is_adapter(name):
    return name.startswith(ADAPTER_PREFIXES)


def mlp(inputs, outputs):
    module = nn.Sequential(nn.LayerNorm(inputs), nn.Linear(inputs, 64),
                           nn.SiLU(), nn.Linear(64, outputs))
    nn.init.zeros_(module[-1].weight)
    nn.init.zeros_(module[-1].bias)
    return module


def global_count(count):
    if torch.distributed.is_initialized():
        torch.distributed.all_reduce(count)
        count /= torch.distributed.get_world_size()
    return count.clamp_min(1)


@MODELS.register_module()
class FourModuleDetector(QCalHEDDetector):
    def __init__(self, reference_checkpoint, **kwargs):
        self.reference_checkpoint = reference_checkpoint
        super().__init__(**kwargs)
        for name, parameter in self.named_parameters():
            parameter.requires_grad_(is_adapter(name))
        self.train(False)

    def init_weights(self):
        super().init_weights()
        raw = torch.load(self.reference_checkpoint, map_location='cpu')
        source = raw['state_dict']
        current = self.state_dict()
        original = [name for name in current if not is_adapter(name)]
        assert all(name in source and source[name].shape == current[name].shape
                   for name in original), 'Original checkpoint coverage mismatch'
        missing, unexpected = self.load_state_dict(source, strict=False)
        assert all(is_adapter(name) for name in missing) and not unexpected
        self.bbox_head.reset_adapters()
        self._reference_loaded_exact = all(torch.equal(current[name].cpu(), source[name])
                                          for name in original)
        assert self._reference_loaded_exact
        del raw, source, current

    def train(self, mode=True):
        # Frozen modules must not change dropout/normalization behavior.
        super().train(False)
        self.bbox_head.occa.train(mode)
        self.bbox_head.sabr.train(mode)
        return self

    def loss(self, batch_inputs, batch_data_samples):
        with torch.no_grad():
            prompts = []
            for sample in batch_data_samples:
                tokenized, caption, spans, _ = self.get_tokens_and_prompts(sample.text, True)
                mapping, positive = self.get_positive_map(tokenized, spans)
                sample.token_positive_map = mapping
                labels = sample.gt_instances.labels
                sample.gt_instances.positive_maps = positive.to(batch_inputs.device)[labels].bool().float()
                prompts.append(caption)
            text = self.language_model(prompts)
            text['embedded'] = self.text_feat_map(text['embedded'])
            for i, sample in enumerate(batch_data_samples):
                sample.gt_instances.text_token_mask = text['text_token_mask'][i].unsqueeze(0).repeat(
                    len(sample.gt_instances), 1)
            visual = self.extract_feat(batch_inputs)
            inputs = self.forward_transformer(visual, text, batch_data_samples)
        return self.bbox_head.adapter_loss(**inputs, batch_data_samples=batch_data_samples)


@MODELS.register_module()
class FourModuleHead(QCalHEDHead):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        dim = self.embed_dims
        self.occa = mlp(3*dim + 9, self.num_classes)
        self.sabr = mlp(5*dim + 9, 4)
        self.adapters_enabled = True
        self.identity_checked = False

    def reset_adapters(self):
        for module in (self.occa, self.sabr):
            nn.init.zeros_(module[-1].weight)
            nn.init.zeros_(module[-1].bias)

    def _pool(self, feature, valid, boxes, ratio):
        batch, queries, _ = boxes.shape
        h, w = feature.shape[-2:]
        xyxy = bbox_cxcywh_to_xyxy(boxes).clamp(0,1)
        scale = torch.stack([ratio[:,0]*w, ratio[:,1]*h,
                             ratio[:,0]*w, ratio[:,1]*h], -1)
        xyxy = xyxy * scale[:,None]
        indices = torch.arange(batch, device=boxes.device, dtype=boxes.dtype)
        indices = indices[:,None,None].expand(batch,queries,1)
        rois = torch.cat([indices,xyxy], -1).reshape(-1,5).contiguous()
        numerator = roi_align(feature*valid, rois, (3,3), 1.0,2,'avg',True)
        denominator = roi_align(valid, rois, (3,3), 1.0,2,'avg',True)
        return (numerator/denominator.clamp_min(1e-6)).reshape(
            batch,queries,self.embed_dims,3,3)

    def _base(self, hidden_states, references, memory_text, text_token_mask, samples,
              quality_memory, quality_shapes, quality_ratios, quality_mask):
        with torch.no_grad():
            token_logits, coords = self(hidden_states, references, memory_text, text_token_mask)
            assert coords.shape[2] == self.matching_queries, 'Frozen eval must have matching queries only'
            boxes = coords.mean(0)
            scores = []
            for i, sample in enumerate(samples):
                assert sample.token_positive_map is not None
                scores.append(torch.stack([convert_grounding_to_cls_scores(
                    layer[i].sigmoid()[None],[sample.token_positive_map])[0]
                    for layer in token_logits]).mean(0))
            scores = torch.stack(scores)
            quality_logits = self.quality_logits(hidden_states,boxes,quality_memory,
                                                 quality_shapes,quality_ratios,quality_mask)
            quality = quality_logits.sigmoid()
            widths = torch.stack([boxes[...,2],boxes[...,3],boxes[...,2],boxes[...,3]],-1)
            disagreement = coords.std(0,unbiased=False)/widths.clamp_min(1e-3)
            agreement = torch.exp(-disagreement.mean(-1).clamp(max=20))
            gate = (quality*agreement).detach()
            inner_levels,context_levels,boundary_levels,level_logits = [],[],[],[]
            start = 0
            for level,(height,width) in enumerate(quality_shapes[:3].tolist()):
                size = height*width
                feature = quality_memory[:,start:start+size].float().transpose(1,2).reshape(
                    boxes.shape[0],self.embed_dims,height,width)
                if quality_mask is None:
                    valid = feature.new_ones(boxes.shape[0],1,height,width)
                else:
                    valid = (~quality_mask[:,start:start+size]).float().reshape(
                        boxes.shape[0],1,height,width)
                start += size
                ratio = quality_ratios[:,level]
                grid = self._pool(feature,valid,boxes,ratio)
                # Four outside strips, not a falsely labelled background ring.
                cx,cy,bw,bh = boxes.unbind(-1)
                ring_boxes = [torch.stack([cx,cy-.625*bh,1.5*bw,.25*bh],-1),
                              torch.stack([cx,cy+.625*bh,1.5*bw,.25*bh],-1),
                              torch.stack([cx-.625*bw,cy,.25*bw,bh],-1),
                              torch.stack([cx+.625*bw,cy,.25*bw,bh],-1)]
                context = torch.stack([self._pool(feature,valid,b,ratio).mean((-2,-1))
                                       for b in ring_boxes]).mean(0)
                inner = grid.mean((-2,-1))
                edges = torch.cat([grid[:,:,:,0,:].mean(-1),grid[:,:,:,-1,:].mean(-1),
                                   grid[:,:,:,:,0].mean(-1),grid[:,:,:,:,-1].mean(-1)],-1)
                inner_levels.append(inner)
                context_levels.append(inner-context)
                boundary_levels.append(edges)
                diameter = (bw*bh*ratio[:,None,0]*ratio[:,None,1]*height*width).clamp_min(1e-6).sqrt()
                level_logits.append(-(diameter/4).log2().abs())
            weights = torch.stack(level_logits,-1).softmax(-1)
            def weighted(features):
                return (torch.stack(features,2)*weights[:,:,:,None]).sum(2)
            query = hidden_states.mean(0).float()
            geometry = torch.cat([boxes,quality[...,None],disagreement],-1)
            occa_features = torch.cat([query,weighted(inner_levels),weighted(context_levels),geometry],-1)
            sabr_features = torch.cat([query,weighted(boundary_levels),geometry],-1)
            token_scores = token_logits.sigmoid().mean(0)
        return dict(boxes=boxes,scores=scores,quality_logits=quality_logits,gate=gate,
                    token_scores=token_scores,occa_features=occa_features,sabr_features=sabr_features)

    def _extend(self, base):
        residual = self.occa(base['occa_features']).tanh()
        correction = self.sabr(base['sabr_features']).tanh()
        evidence = self.shot/(self.shot+2) * base['gate'][...,None]
        residual = .25*evidence*residual
        correction = .10*evidence*correction
        boxes = base['boxes']
        width_scale = torch.stack([boxes[...,2],boxes[...,3],boxes[...,2],boxes[...,3]],-1)
        refined = boxes + correction*width_scale
        if not self.adapters_enabled:
            residual = residual*0
            refined = boxes
        return refined,residual,correction

    def adapter_loss(self, hidden_states,references,memory_text,text_token_mask,
                     batch_data_samples,quality_memory,quality_shapes,quality_ratios,
                     quality_mask,**kwargs):
        base = self._base(hidden_states,references,memory_text,text_token_mask,batch_data_samples,
                          quality_memory,quality_shapes,quality_ratios,quality_mask)
        refined,residual,correction = self._extend(base)
        if not self.identity_checked:
            assert torch.equal(refined,base['boxes']) and not torch.count_nonzero(residual)
            arguments = dict(hidden_states=hidden_states,references=references,
                memory_text=memory_text,text_token_mask=text_token_mask,
                batch_data_samples=batch_data_samples,quality_memory=quality_memory,
                quality_shapes=quality_shapes,quality_ratios=quality_ratios,quality_mask=quality_mask)
            with torch.no_grad():
                original_predictions = QCalHEDHead.predict(self,**arguments)
                extended_predictions = self.predict(**arguments)
                assert all(torch.equal(getattr(a,k),getattr(b,k))
                           for a,b in zip(original_predictions,extended_predictions)
                           for k in ('bboxes','scores','labels')), 'Zero-output prediction identity failed'
            self.zero_prediction_identity_pass = True
            self.identity_checked = True
        zero = residual.sum()*0 + correction.sum()*0
        cls_loss = zero
        l1_loss = zero
        giou_loss = zero
        count = 0
        for i,sample in enumerate(batch_data_samples):
            gt = sample.gt_instances
            h,w = sample.img_shape[:2]
            scale = refined.new_tensor([w,h,w,h])
            with torch.no_grad():
                assigned = self.assigner.assign(InstanceData(
                    scores=torch.logit(base['token_scores'][i].clamp(1e-6,1-1e-6)),
                    bboxes=bbox_cxcywh_to_xyxy(base['boxes'][i])*scale),gt,sample.metainfo)
                positive = torch.where(assigned.gt_inds>0)[0]
                target_indices = assigned.gt_inds[positive]-1
            if len(positive):
                labels = gt.labels[target_indices]
                targets = F.one_hot(labels,self.num_classes).float()
                original_logits = torch.logit(base['scores'][i,positive].clamp(1e-6,1-1e-6))
                cls_loss = cls_loss + F.binary_cross_entropy_with_logits(
                    original_logits+residual[i,positive],targets,reduction='none').mean(-1).sum()
                predicted = bbox_cxcywh_to_xyxy(refined[i,positive])
                target = gt.bboxes[target_indices]/scale
                l1_loss = l1_loss + F.l1_loss(predicted,target,reduction='none').sum(-1).sum()
                giou_loss = giou_loss + (1-bbox_overlaps(predicted,target,mode='giou',is_aligned=True)).sum()
                count += len(positive)
        divisor = global_count(residual.new_tensor(float(count)))
        preservation = residual.square().mean()+correction.square().mean()
        losses = dict(loss_occa=cls_loss/divisor,loss_sabr_l1=5*l1_loss/divisor,
                      loss_sabr_giou=2*giou_loss/divisor,loss_preservation=.05*preservation)
        self.adapter_diagnostics = dict(finite=bool(torch.isfinite(refined).all() and
                                                 torch.isfinite(residual).all()),
            positives=count,mean_score_residual=float(residual.detach().abs().mean()),
            mean_box_relative_residual=float(correction.detach().abs().mean()))
        return losses

    def predict(self, hidden_states,references,memory_text,text_token_mask,batch_data_samples,
                quality_memory,quality_shapes,quality_ratios,quality_mask,rescale=True):
        base = self._base(hidden_states,references,memory_text,text_token_mask,batch_data_samples,
                          quality_memory,quality_shapes,quality_ratios,quality_mask)
        refined,residual,_ = self._extend(base)
        with torch.no_grad():
            quality_logits = self.quality_logits(hidden_states,refined,quality_memory,
                                                 quality_shapes,quality_ratios,quality_mask)
        scores = base['scores']*self.multiplier(quality_logits)[...,None]*residual.exp()
        return [self._predict_by_feat_single(scores[i],refined[i],sample.token_positive_map,
                                            sample.metainfo,rescale)
                for i,sample in enumerate(batch_data_samples)]
