"""Four GPU adapter-only training; original forward remains frozen eval."""
import argparse
import json
import os
import sys
from pathlib import Path

os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import torch
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmdet.utils import register_all_modules
from extension_config import make_config,REFERENCE
from qcal_runtime import ControlledPause,json_write,rank
from inference_audit import restore_and_audit,record_predictions


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--domain',required=True);p.add_argument('--shot',type=int,required=True)
    p.add_argument('--work-dir',required=True);p.add_argument('--engineering',action='store_true')
    p.add_argument('--resume');p.add_argument('--test',action='store_true')
    p.add_argument('--support-smoke',action='store_true')
    args=p.parse_args()
    register_all_modules(init_default_scope=True)
    cfg=make_config(args.domain,args.shot,args.work_dir,args.engineering)
    import_modules_from_strings(**cfg.custom_imports)
    if args.resume:
        cfg.load_from=args.resume;cfg.resume=not args.test
    if args.support_smoke:
        audit=json.loads((REFERENCE/'DATA_AUDIT.json').read_text())['domains'][args.domain]
        cfg.test_dataloader.dataset.ann_file=audit['splits'][f'{args.shot}_shot']['view']
        cfg.test_dataloader.dataset.data_prefix.img=cfg.train_dataloader.dataset.data_prefix.img
        cfg.test_evaluator.ann_file=cfg.test_dataloader.dataset.ann_file
        cfg.test_evaluator.outfile_prefix=str(Path(args.work_dir)/'support_smoke')
    runner=Runner.from_cfg(cfg)
    if args.test:
        assert args.resume
        restore_and_audit(runner,args.resume)
        runner.test()
        record_predictions(runner,args.support_smoke)
    else:
        runner.train()
        if rank()==0:
            json_write(Path(args.work_dir)/'TRAIN_COMPLETE.json',dict(
                domain=args.domain,shot=args.shot,seed=0,adapter_epochs=runner.epoch,
                completed_iter=runner.iter,selection='fixed final adapter epoch',engineering=args.engineering))


if __name__=='__main__':
    try: main()
    except ControlledPause as error:
        print(str(error),flush=True)
        if torch.distributed.is_initialized(): torch.distributed.destroy_process_group()
        sys.exit(75)
