"""Small adapter-only snapshots; frozen source checkpoints are never rewritten."""
import json
import math
import random
import shutil
import time
from pathlib import Path
import numpy as np
import torch
from mmengine.hooks import Hook
from mmengine.optim import OptimWrapper
from mmengine.registry import HOOKS,OPTIM_WRAPPERS
from qcal_runtime import (model_of,rank,barrier,sha256,json_write,mixup_transforms,
                          ControlledPause)
from extension_model import is_adapter


@OPTIM_WRAPPERS.register_module()
class AdapterOptimWrapper(OptimWrapper):
    def step(self,**kwargs):
        gradients = [p.grad for group in self.optimizer.param_groups
                     for p in group['params'] if p.grad is not None]
        device = self.optimizer.param_groups[0]['params'][0].device
        ok = torch.tensor(all(bool(torch.isfinite(g).all()) for g in gradients),
                          device=device,dtype=torch.int)
        if torch.distributed.is_initialized():
            torch.distributed.all_reduce(ok,op=torch.distributed.ReduceOp.MIN)
        if not ok.item():
            raise FloatingPointError('Nonfinite adapter gradient; no update')
        super().step(**kwargs)


@HOOKS.register_module()
class FrozenAdapterHook(Hook):
    priority = 'LOWEST'

    def __init__(self,root,total_epochs=100,engineering=False):
        self.root = Path(root)
        self.total_epochs = total_epochs
        self.engineering = engineering

    def after_load_checkpoint(self,runner,checkpoint):
        self.resume_states = checkpoint.get('adapter_rank_states')
        self.resume_source_hash = checkpoint.get('reference_sha256')
        self.resume_plan_hash = checkpoint.get('adapter_plan_sha256')

    def before_train(self,runner):
        model = model_of(runner)
        assert model._reference_loaded_exact
        trainable = [n for n,p in model.named_parameters() if p.requires_grad]
        assert trainable and all(is_adapter(n) for n in trainable)
        self.reference_hash = sha256(model.reference_checkpoint) if rank()==0 else None
        hashes = [self.reference_hash]
        torch.distributed.broadcast_object_list(hashes,src=0)
        self.reference_hash = hashes[0]
        if getattr(runner,'_resume',False):
            assert self.resume_source_hash == self.reference_hash
            assert self.resume_plan_hash == sha256(self.root/'PLAN.json')
            assert len(self.resume_states)==4
            info = self.resume_states[rank()]
            assert sha256(info['path'])==info['sha256']
            state = torch.load(info['path'],map_location='cpu')
            for i,t in mixup_transforms(runner):
                t.results_cache = state['augmentation_caches'][i]
            random.setstate(state['python_rng'])
            np.random.set_state(state['numpy_rng'])
            torch.set_rng_state(state['torch_rng'])
            torch.cuda.set_rng_state(state['cuda_rng'])
            model.bbox_head.identity_checked = True
            if rank()==0:
                json_write(Path(runner.work_dir)/'RESUME_PASS.json',dict(
                    epoch=runner.epoch,iter=runner.iter,all_rank_rng_and_cached_mixup_restored=True,
                    reference_checkpoint_unchanged=True))
        elif rank()==0:
            json_write(Path(runner.work_dir)/'SOURCE_COVERAGE_PASS.json',dict(
                status='PASS',all_existing_keys_loaded_exactly=True,
                source=model.reference_checkpoint,source_sha256=self.reference_hash,
                trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
                trainable_names=trainable))
        if self.engineering:
            self.initial_output = {n:p.detach().cpu().clone() for n,p in model.named_parameters()
                                   if is_adapter(n) and '.3.' in n}
        barrier()

    def before_train_epoch(self,runner):
        model = model_of(runner)
        assert not model.training and not model.encoder.training and not model.backbone.training
        assert not model.language_model.training and not model.bbox_head.quality_net.training
        if rank()==0 and shutil.disk_usage(self.root).free<80*1024**3:
            json_write(self.root/'PAUSE_REQUESTED',dict(reason='free-space guard',at=time.time()))
        cosine = (1+math.cos(math.pi*runner.epoch/max(self.total_epochs-1,1)))/2
        for group in runner.optim_wrapper.optimizer.param_groups:
            group['lr'] = 1e-6+(1e-4-1e-6)*cosine

    def after_train_iter(self,runner,batch_idx,data_batch=None,outputs=None):
        model = model_of(runner)
        assert all(p.grad is None for n,p in model.named_parameters() if not is_adapter(n))
        if rank()==0:
            losses = {k:float(v) for k,v in (outputs or {}).items()}
            assert all(math.isfinite(v) for v in losses.values())
            assert model.bbox_head.adapter_diagnostics['finite']
            json_write(Path(runner.work_dir)/'PROGRESS.json',dict(
                status='TRAINING_ADAPTERS',epoch=runner.epoch,completed_iter=runner.iter+1,
                epoch_batch=batch_idx+1,batches_per_epoch=len(runner.train_dataloader),
                time=time.time(),losses=losses,adapters=model.bbox_head.adapter_diagnostics))
            if getattr(model.bbox_head,'zero_prediction_identity_pass',False):
                p=Path(runner.work_dir)/'ZERO_IDENTITY_PASS.json'
                if not p.exists():
                    json_write(p,dict(status='PASS',bboxes_scores_labels_bitwise_equal=True))

    def _verify_frozen(self,runner):
        model = model_of(runner)
        source = torch.load(model.reference_checkpoint,map_location='cpu')['state_dict']
        current = model.state_dict()
        original = [n for n in current if not is_adapter(n)]
        assert all(torch.equal(current[n].cpu(),source[n]) for n in original)
        json_write(Path(runner.work_dir)/'FROZEN_BASE_PASS.json',dict(
            status='PASS',existing_state_keys_unchanged=len(original),
            reference_sha256=self.reference_hash))

    def after_train_epoch(self,runner):
        completed = runner.epoch+1
        pause = (self.root/'PAUSE_REQUESTED').exists()
        final = completed==runner.max_epochs
        if not (self.engineering or completed%10==0 or pause or final):
            return
        work=Path(runner.work_dir)
        payload=dict(epoch=completed,iter=runner.iter,python_rng=random.getstate(),
                     numpy_rng=np.random.get_state(),torch_rng=torch.get_rng_state(),
                     cuda_rng=torch.cuda.get_rng_state(),
                     augmentation_caches={i:t.results_cache for i,t in mixup_transforms(runner)})
        path=work/f'rank_state_epoch{completed:03d}_rank{rank()}.pth'
        temp=path.with_suffix('.tmp');torch.save(payload,temp);temp.replace(path)
        info=dict(path=str(path),sha256=sha256(path));states=[None]*4
        torch.distributed.all_gather_object(states,info)
        self.rank_states=states
        if rank()==0:
            runner.save_checkpoint(str(work),'checkpoint_pending.pth',save_optimizer=True,
                                   save_param_scheduler=False,by_epoch=True)
            pending=work/'checkpoint_pending.pth'
            saved=torch.load(pending,map_location='cpu')
            current={n:t for n,t in model_of(runner).state_dict().items() if is_adapter(n)}
            assert saved['meta']['epoch']==completed and 'optimizer' in saved
            assert set(saved['state_dict'])==set(current)
            assert all(torch.equal(t.cpu(),saved['state_dict'][n]) for n,t in current.items())
            latest=work/'checkpoint_latest.pth'
            if latest.exists(): latest.replace(work/'checkpoint_previous.pth')
            pending.replace(latest)
            json_write(work/'LAST_CHECKPOINT.json',dict(
                path=str(latest),sha256=sha256(latest),completed_epoch=completed,
                completed_iter=runner.iter,readback_exact=True,head_only=True,
                reference_checkpoint=model_of(runner).reference_checkpoint,
                reference_sha256=self.reference_hash,rank_states=states))
            if final or self.engineering:
                self._verify_frozen(runner)
            if self.engineering and not getattr(runner,'_resume',False):
                current=dict(model_of(runner).named_parameters())
                updated={prefix:any(not torch.equal(current[n].cpu(),t) for n,t in self.initial_output.items()
                                    if n.startswith(prefix)) for prefix in ('bbox_head.occa.','bbox_head.sabr.')}
                assert all(updated.values()),updated
                json_write(work/'ADAPTER_UPDATE_PASS.json',dict(status='PASS',updated=updated))
            if pause: json_write(work/'PAUSED.json',dict(completed_epoch=completed,at=time.time()))
        barrier()
        if pause: raise ControlledPause('Epoch-boundary adapter and rank-state checkpoint saved')

    def before_save_checkpoint(self,runner,checkpoint):
        checkpoint['state_dict']={n:t for n,t in checkpoint['state_dict'].items() if is_adapter(n)}
        checkpoint['adapter_rank_states']=self.rank_states
        checkpoint['reference_sha256']=self.reference_hash
        checkpoint['adapter_plan_sha256']=sha256(self.root/'PLAN.json')
