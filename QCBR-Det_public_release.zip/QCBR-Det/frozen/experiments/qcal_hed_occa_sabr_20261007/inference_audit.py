"""Explicit full-model restoration for adapter-only inference checkpoints."""
from pathlib import Path
import json
import torch
from qcal_runtime import model_of, rank, barrier, sha256, json_write
from extension_model import is_adapter


def restore_and_audit(runner, adapter_checkpoint):
    """Runner.test does not initialize weights; load frozen source first."""
    model = model_of(runner)
    model.init_weights()
    assert model._reference_loaded_exact
    runner.load_or_resume()
    current = model.state_dict()
    saved = torch.load(adapter_checkpoint, map_location='cpu')
    adapters = {name for name in current if is_adapter(name)}
    assert set(saved['state_dict']) == adapters, 'Adapter checkpoint key mismatch'
    assert all(torch.equal(current[name].cpu(), saved['state_dict'][name])
               for name in adapters), 'Adapter inference readback mismatch'
    source_hash = sha256(model.reference_checkpoint)
    assert saved['reference_sha256'] == source_hash, 'Wrong frozen reference'
    assert saved['adapter_plan_sha256'] == sha256(Path(__file__).parent/'PLAN.json')
    source = torch.load(model.reference_checkpoint, map_location='cpu')['state_dict']
    original = [name for name in current if not is_adapter(name)]
    assert all(name in source and torch.equal(current[name].cpu(), source[name])
               for name in original), 'Frozen inference weights mismatch'
    evidence = dict(status='PASS',rank=rank(),full_source_loaded_before_adapters=True,
        existing_state_keys_verified=len(original),adapter_state_keys_verified=len(adapters),
        reference_checkpoint=model.reference_checkpoint,reference_sha256=source_hash,
        adapter_checkpoint=str(adapter_checkpoint),adapter_sha256=sha256(adapter_checkpoint),
        adapter_epoch=saved['meta']['epoch'],plan_sha256=saved['adapter_plan_sha256'])
    del source, saved, current
    gathered = [None]*torch.distributed.get_world_size()
    torch.distributed.all_gather_object(gathered, evidence)
    assert len(gathered)==4 and all(x['status']=='PASS' for x in gathered)
    assert len({x['reference_sha256'] for x in gathered})==1
    assert len({x['adapter_sha256'] for x in gathered})==1
    if rank()==0:
        json_write(Path(runner.work_dir)/'INFERENCE_MODEL_AUDIT_PASS.json',
                   dict(status='PASS',four_ranks_verified=True,ranks=gathered))
    barrier()


def record_predictions(runner, support_smoke):
    if rank()==0:
        work=Path(runner.work_dir)
        name='support_smoke.bbox.json' if support_smoke else 'predictions.bbox.json'
        audit=json.loads((work/'INFERENCE_MODEL_AUDIT_PASS.json').read_text())
        assert audit['four_ranks_verified']
        json_write(work/'INFERENCE_COMPLETE.json',dict(status='PASS',support_smoke=support_smoke,
            predictions_sha256=sha256(work/name),model_audit_sha256=sha256(
                work/'INFERENCE_MODEL_AUDIT_PASS.json')))
    barrier()
