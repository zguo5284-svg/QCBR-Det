"""Same data and inference protocol, fixed adapter-only optimization."""
import json
from pathlib import Path
from qcal_config import make_config as reference_config

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT.parent/'qcal_hed_20261006'


def make_config(domain,shot,work_dir,engineering=False):
    cfg = reference_config(domain,shot,work_dir,False)
    source = REFERENCE/'runs'/f'{domain}_{shot}shot_seed0'/'checkpoint_latest.pth'
    cfg.model.update(type='FourModuleDetector',reference_checkpoint=str(source))
    cfg.model.bbox_head.type = 'FourModuleHead'
    cfg.custom_imports = dict(imports=['extension_model','extension_runtime'],allow_failed_imports=False)
    cfg.load_from = None
    cfg.train_cfg.max_epochs = 2 if engineering else 100
    cfg.train_cfg.val_interval = 101
    cfg.optim_wrapper = dict(type='AdapterOptimWrapper',
        optimizer=dict(type='AdamW',lr=1e-4,weight_decay=.05),
        clip_grad=dict(max_norm=.1,norm_type=2))
    cfg.custom_hooks = [dict(type='FrozenAdapterHook',root=str(ROOT),
                             total_epochs=2 if engineering else 100,
                             engineering=engineering)]
    cfg.model_wrapper_cfg.find_unused_parameters = False
    return cfg
