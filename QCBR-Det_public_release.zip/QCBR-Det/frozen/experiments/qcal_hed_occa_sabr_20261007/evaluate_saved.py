"""COCO evaluation of saved fixed-final adapter predictions; no model choice."""
import argparse,json,math
from pathlib import Path
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from qcal_runtime import json_write,sha256
from extension_config import REFERENCE


def main():
    p=argparse.ArgumentParser();p.add_argument('--domain',required=True)
    p.add_argument('--shot',required=True,type=int);p.add_argument('--work-dir',required=True)
    a=p.parse_args();work=Path(a.work_dir)
    audit=json.loads((REFERENCE/'DATA_AUDIT.json').read_text())['domains'][a.domain]
    annotation=Path(audit['splits']['test']['view']);prediction=work/'predictions.bbox.json'
    raw=json.loads(annotation.read_text());pred=json.loads(prediction.read_text())
    inference=json.loads((work/'INFERENCE_COMPLETE.json').read_text())
    assert inference['status']=='PASS' and not inference['support_smoke']
    assert inference['predictions_sha256']==sha256(prediction)
    audit_path=work/'INFERENCE_MODEL_AUDIT_PASS.json'
    assert inference['model_audit_sha256']==sha256(audit_path)
    model_audit=json.loads(audit_path.read_text())
    assert model_audit['status']=='PASS' and model_audit['four_ranks_verified']
    ids={x['id'] for x in raw['images']};cats={x['id'] for x in raw['categories']}
    assert pred and len(pred)==300*len(ids)
    assert all(x['image_id'] in ids and x['category_id'] in cats and math.isfinite(x['score'])
               and all(math.isfinite(v) for v in x['bbox']) for x in pred)
    gt=COCO(str(annotation));gt.dataset.setdefault('info',{})
    evaluator=COCOeval(gt,gt.loadRes(pred),'bbox')
    evaluator.params.imgIds=sorted(ids);evaluator.params.catIds=sorted(cats)
    evaluator.params.maxDets=[1,10,100]
    evaluator.evaluate();evaluator.accumulate();evaluator.summarize()
    metrics={k:float(v)*100 for k,v in zip(
        ['AP','AP50','AP75','APs','APm','APl','AR1','AR10','AR100','ARs','ARm','ARl'],evaluator.stats)}
    last=json.loads((work/'LAST_CHECKPOINT.json').read_text())
    assert last['completed_epoch']==100 and last['readback_exact'] and last['head_only']
    assert all(x['adapter_sha256']==last['sha256'] and x['adapter_epoch']==100
               and x['reference_sha256']==last['reference_sha256']
               for x in model_audit['ranks'])
    frozen=json.loads((work/'FROZEN_BASE_PASS.json').read_text());assert frozen['status']=='PASS'
    reference=next(x for x in json.loads((REFERENCE/'RESULTS.json').read_text())['results']
                   if x['domain']==a.domain and x['shot']==a.shot and x['seed']==0)
    result=dict(domain=a.domain,shot=a.shot,seed=0,method='QCAL-HED + OCCA + SABR candidate v2',
        metrics=metrics,metric='COCO bbox AP@[0.50:0.95] (%)',maxDets=[1,10,100],
        evaluation_images=len(ids),candidate_detections=len(pred),adapter_checkpoint=last,
        frozen_reference_checkpoint_unchanged=True,reference_checkpoint=last['reference_checkpoint'],
        inference_model_audit_sha256=sha256(audit_path),four_rank_inference_weights_verified=True,
        reference_sha256=last['reference_sha256'],predictions_sha256=sha256(prediction),
        annotation_sha256=sha256(annotation),reference_v1_metrics=reference['metrics'],
        difference_from_v1={k:metrics[k]-reference['metrics'][k] for k in ['AP','AP50','AP75']},
        model_selection='fixed final adapter epoch100, not test AP',backbone='Swin-B',
        training_budget='v1 100 epochs + 100 adapter-only epochs',single_seed_not_three_seed_mean=True)
    json_write(work/'RESULT.json',result)
    json_write(work/'COMPLETE.json',dict(status='COMPLETE',result_sha256=sha256(work/'RESULT.json')))


if __name__=='__main__': main()
