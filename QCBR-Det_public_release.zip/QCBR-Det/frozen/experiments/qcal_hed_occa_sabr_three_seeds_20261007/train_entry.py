"""Same full procedure per seed; no support resampling or AP-driven selection."""
import argparse
import os
import sys
from pathlib import Path

os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import torch
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmdet.utils import register_all_modules
from qcal_runtime import ControlledPause,json_write,rank
from common import ROOT,OLD_SOURCE,read,sha
from seed_config import make_config
from inference_audit import restore_and_audit,record_predictions


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--domain',required=True);p.add_argument('--shot',type=int,required=True)
    p.add_argument('--seed',type=int,choices=[1,2],required=True)
    p.add_argument('--phase',choices=['source','adapter'],required=True)
    p.add_argument('--work-dir',required=True);p.add_argument('--engineering',action='store_true')
    p.add_argument('--resume');p.add_argument('--test',action='store_true')
    p.add_argument('--support-smoke',action='store_true')
    a=p.parse_args()
    register_all_modules(init_default_scope=True)
    cfg=make_config(a.domain,a.shot,a.seed,a.phase,a.work_dir,a.engineering)
    import_modules_from_strings(**cfg.custom_imports)
    if a.resume:cfg.load_from=a.resume;cfg.resume=not a.test
    if a.support_smoke:
        assert a.test and a.phase=='adapter'
        audit=read(OLD_SOURCE/'DATA_AUDIT.json')['domains'][a.domain]
        cfg.test_dataloader.dataset.ann_file=audit['splits'][f'{a.shot}_shot']['view']
        cfg.test_dataloader.dataset.data_prefix.img=cfg.train_dataloader.dataset.data_prefix.img
        cfg.test_evaluator.ann_file=cfg.test_dataloader.dataset.ann_file
        cfg.test_evaluator.outfile_prefix=str(Path(a.work_dir)/'support_smoke')
    runner=Runner.from_cfg(cfg)
    assert runner.seed==a.seed
    if a.test:
        assert a.phase=='adapter' and a.resume
        restore_and_audit(runner,a.resume,a.seed,2 if a.engineering else 100)
        runner.test();record_predictions(runner,a.support_smoke)
    else:
        runner.train()
        if rank()==0:
            json_write(Path(a.work_dir)/'TRAIN_COMPLETE.json',dict(
                domain=a.domain,shot=a.shot,seed=a.seed,phase=a.phase,
                completed_epochs=runner.epoch,completed_iter=runner.iter,
                selection='fixed final epoch, no test AP selection',engineering=a.engineering,
                plan_sha256=sha(ROOT/'PLAN.json')))


if __name__=='__main__':
    try:main()
    except ControlledPause as error:
        print(str(error),flush=True)
        if torch.distributed.is_initialized():torch.distributed.destroy_process_group()
        sys.exit(75)
