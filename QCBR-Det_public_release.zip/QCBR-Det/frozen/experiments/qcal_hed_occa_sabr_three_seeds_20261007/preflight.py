"""Protocol equivalence, data/provenance and schedules; no accuracy screen."""
import json
import math
import shutil
from types import SimpleNamespace
from common import (ROOT,OLD_SOURCE,OLD_FINAL,DOMAINS,SHOTS,NEW_SEEDS,CODE,
                    read,write,sha,verify_reference_manifests,work_for)
from seed_config import make_config
from qcal_config import make_config as source_config
from extension_config import make_config as adapter_config


def normalized(cfg,phase):
    d=cfg.to_dict()
    d['randomness']['seed']=0;d['work_dir']='/WORK'
    d['test_evaluator']['outfile_prefix']='/PREDICTIONS'
    d['custom_imports']['imports']=[x for x in d['custom_imports']['imports'] if x!='seed_runtime']
    mapping={'SeedStageHook':'FixedTwoStageHook','SeedCheckpointHook':'AuditedCheckpointHook','SeedAdapterHook':'FrozenAdapterHook'}
    for hook in d['custom_hooks']:
        hook['type']=mapping.get(hook['type'],hook['type']);hook.pop('seed',None)
        if hook['type']=='FixedTwoStageHook':hook.pop('root',None)
        elif 'root' in hook:hook['root']='/CONTROL_ROOT'
    if phase=='adapter':d['model']['reference_checkpoint']='/SAME_SEED_FINAL_SOURCE'
    return json.dumps(d,sort_keys=True)


def check_schedules():
    from seed_runtime import SeedStageHook
    from qcal_runtime import FixedTwoStageHook
    # Full 100-epoch formula equivalence, using isolated lightweight groups.
    names=['backbone.weight','language_model.weight','encoder.weight','decoder.weight','bbox_head.quality_net.weight']
    old=FixedTwoStageHook(stage2_epoch=50,total_epochs=100)
    new=SeedStageHook(root=str(ROOT),stage2_epoch=50,total_epochs=100)
    old.group_names=new.group_names=names
    for epoch in range(100):
        a=SimpleNamespace(epoch=epoch,work_dir=str(ROOT/'engineering/schedule_old'),
                          optim_wrapper=SimpleNamespace(optimizer=SimpleNamespace(param_groups=[{} for _ in names])))
        b=SimpleNamespace(epoch=epoch,work_dir=str(ROOT/'engineering/schedule_new'),
                          optim_wrapper=SimpleNamespace(optimizer=SimpleNamespace(param_groups=[{} for _ in names])))
        (ROOT/'engineering/schedule_old').mkdir(parents=True,exist_ok=True)
        (ROOT/'engineering/schedule_new').mkdir(parents=True,exist_ok=True)
        old.before_train_epoch(a);new.before_train_epoch(b)
        assert a.optim_wrapper.optimizer.param_groups==b.optim_wrapper.optimizer.param_groups


def main():
    assert shutil.disk_usage(ROOT).free>80*1024**3
    verify_reference_manifests()
    old=read(OLD_FINAL/'RESULTS.json');assert old['completed']==18 and old['seed']==0
    assert read(OLD_FINAL/'ALL_COMPLETE.json')['results_sha256']==sha(OLD_FINAL/'RESULTS.json')
    checked=0
    for seed in NEW_SEEDS:
        for shot in SHOTS:
            for domain in DOMAINS:
                for phase,constructor in [('source',source_config),('adapter',adapter_config)]:
                    w=work_for(seed,phase,domain,shot)
                    cfg=make_config(domain,shot,seed,phase,w)
                    ref=constructor(domain,shot,'/REFERENCE_WORK',False)
                    assert cfg.randomness.seed==seed
                    assert normalized(cfg,phase)==normalized(ref,phase),(seed,domain,shot,phase)
                    checked+=1
    audit=read(OLD_SOURCE/'DATA_AUDIT.json');assert audit['status']=='PASS'
    for domain in DOMAINS:
        for split,record in audit['domains'][domain]['splits'].items():
            assert sha(record['view'])==record['view_sha256'],(domain,split)
    check_schedules()
    from aggregate import self_test
    self_test()
    write(ROOT/'PROTOCOL_PASS.json',dict(status='PASS',normalized_configs_verified=checked,
        only_seed_and_output_control_paths_changed=True,support_resampling=False,
        original_code_manifests_verified=True,all_views_hash_verified=True,
        source_100_epoch_optimizer_schedules_exactly_equal=True,statistics_unit_pass=True,
        seed0_results_sha256=sha(OLD_FINAL/'RESULTS.json'),plan_sha256=sha(ROOT/'PLAN.json')))
    print('PROTOCOL_PREFLIGHT_PASS',checked)


if __name__=='__main__':main()
