"""Isolated control/audit hooks; optimization matches the frozen seed0 code."""
import math
import shutil
import time
from pathlib import Path
from mmengine.registry import HOOKS
from qcal_runtime import (FixedTwoStageHook,AuditedCheckpointHook,rank,
                          json_write,sha256)
from extension_runtime import FrozenAdapterHook


@HOOKS.register_module()
class SeedStageHook(FixedTwoStageHook):
    def __init__(self,root,**kwargs):
        super().__init__(**kwargs);self.root=Path(root)

    def before_train_epoch(self,runner):
        # Same equations/groups as FixedTwoStageHook, with a new control root.
        if rank()==0 and shutil.disk_usage(self.root).free<80*1024**3:
            json_write(self.root/'PAUSE_REQUESTED',{'reason':'free-space safety guard','at':time.time()})
        epoch=runner.epoch
        cosine=(1+math.cos(math.pi*epoch/max(self.total_epochs-1,1)))/2
        frozen_prefixes=('backbone.','language_model.','encoder.')
        for name,group in zip(self.group_names,runner.optim_wrapper.optimizer.param_groups):
            frozen=epoch<self.stage2_epoch and name.startswith(frozen_prefixes)
            initial=2e-5 if name.startswith(('backbone.','language_model.')) else 1e-4
            group['_stage_frozen']=frozen
            group['lr']=0.0 if frozen else 1e-6+(initial-1e-6)*cosine
        if rank()==0 and epoch in (0,self.stage2_epoch):
            json_write(Path(runner.work_dir)/f'STAGE_{1 if epoch<self.stage2_epoch else 2}.json',
                dict(epoch=epoch,policy='fixed epoch; no AP feedback',
                     frozen_prefixes=list(frozen_prefixes) if epoch<self.stage2_epoch else [],
                     optimizer_freezing='zero LR and absent gradients/moment updates',
                     all_requires_grad_stable_for_DDP=True))


@HOOKS.register_module()
class SeedCheckpointHook(AuditedCheckpointHook):
    def __init__(self,seed,**kwargs):
        super().__init__(**kwargs);self.seed=seed

    def after_load_checkpoint(self,runner,checkpoint):
        super().after_load_checkpoint(runner,checkpoint)
        if getattr(runner,'_resume',False):
            assert checkpoint['validation_seed']==self.seed==checkpoint['meta']['seed']
            assert checkpoint['qcal_plan_sha256']==sha256(self.root/'PLAN.json')

    def before_train(self,runner):
        assert runner.seed==self.seed
        super().before_train(runner)

    def before_save_checkpoint(self,runner,checkpoint):
        super().before_save_checkpoint(runner,checkpoint)
        checkpoint['validation_seed']=self.seed


@HOOKS.register_module()
class SeedAdapterHook(FrozenAdapterHook):
    def __init__(self,seed,**kwargs):
        super().__init__(**kwargs);self.seed=seed

    def after_load_checkpoint(self,runner,checkpoint):
        super().after_load_checkpoint(runner,checkpoint)
        if getattr(runner,'_resume',False):
            assert checkpoint['validation_seed']==self.seed==checkpoint['meta']['seed']

    def before_train(self,runner):
        assert runner.seed==self.seed
        super().before_train(runner)

    def before_save_checkpoint(self,runner,checkpoint):
        super().before_save_checkpoint(runner,checkpoint)
        checkpoint['validation_seed']=self.seed
