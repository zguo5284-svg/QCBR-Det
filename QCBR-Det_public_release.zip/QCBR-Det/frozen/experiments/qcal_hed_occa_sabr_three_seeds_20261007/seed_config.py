"""Reuse frozen algorithms; expose the training seed and isolated run paths."""
from common import ROOT,work_for
from qcal_config import make_config as source_config
from extension_config import make_config as adapter_config


def make_config(domain,shot,seed,phase,work_dir,engineering=False):
    assert seed in (1,2)
    if phase=='source':
        cfg=source_config(domain,shot,work_dir,engineering)
        cfg.custom_imports.imports += ['seed_runtime']
        cfg.custom_hooks[0].update(type='SeedStageHook',root=str(ROOT))
        cfg.custom_hooks[1].update(type='SeedCheckpointHook',root=str(ROOT),seed=seed)
    elif phase=='adapter':
        cfg=adapter_config(domain,shot,work_dir,engineering)
        cfg.custom_imports.imports += ['seed_runtime']
        cfg.model.reference_checkpoint=str(work_for(seed,'source',domain,shot,engineering)/'checkpoint_latest.pth')
        cfg.custom_hooks[0].update(type='SeedAdapterHook',root=str(ROOT),seed=seed)
    else:
        raise ValueError(phase)
    cfg.randomness.seed=seed
    return cfg
