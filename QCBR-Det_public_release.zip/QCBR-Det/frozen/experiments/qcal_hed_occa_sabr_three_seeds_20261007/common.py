"""Paths/protocol utilities; completed seed0 artifacts are read-only."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path('/root/autodl-tmp/vfmdetr_repro')
OLD_SOURCE = BASE/'experiments/qcal_hed_20261006'
OLD_FINAL = BASE/'experiments/qcal_hed_occa_sabr_20261007'
PY = BASE/'software/envs/qcal_hed/bin/python'
DOMAINS = ['ArTaxOr','clipart1k','DIOR','FISH','NEU-DET','UODD']
SHOTS = [1,5,10]
NEW_SEEDS = [1,2]
CODE = ['PLAN.json','common.py','seed_config.py','seed_runtime.py',
        'train_entry.py','inference_audit.py','evaluate_saved.py',
        'aggregate.py','preflight.py','driver.py']


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(obj,ensure_ascii=False,indent=2))
    temporary.replace(path)


def work_for(seed,phase,domain,shot,engineering=False):
    assert seed in NEW_SEEDS and phase in ('source','adapter')
    if engineering:
        assert seed==1
        return ROOT/'engineering'/phase
    folder='source_runs' if phase=='source' else 'runs'
    return ROOT/f'seed{seed}'/folder/f'{domain}_{shot}shot_seed{seed}'


def verify_reference_manifests():
    for root in (OLD_SOURCE,OLD_FINAL):
        manifest=read(root/'FROZEN_MANIFEST.json')
        assert all(sha(root/n)==v for n,v in manifest.items()),str(root)


def verify_frozen():
    manifest=read(ROOT/'FROZEN_MANIFEST.json')
    assert all(sha(ROOT/n)==v for n,v in manifest.items())
    verify_reference_manifests()
