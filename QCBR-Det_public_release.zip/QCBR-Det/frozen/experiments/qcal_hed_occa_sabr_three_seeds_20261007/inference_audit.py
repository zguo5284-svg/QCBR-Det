"""Verify same-seed full source + adapters before any inference."""
from pathlib import Path
import torch
from common import ROOT,sha,read,write
from qcal_runtime import model_of,rank,barrier
from extension_model import is_adapter


def restore_and_audit(runner,adapter_checkpoint,seed,expected_epoch):
    model=model_of(runner)
    model.init_weights();assert model._reference_loaded_exact
    runner.load_or_resume()
    current=model.state_dict()
    saved=torch.load(adapter_checkpoint,map_location='cpu')
    adapters={n for n in current if is_adapter(n)}
    assert saved['validation_seed']==saved['meta']['seed']==seed==runner.seed
    assert saved['meta']['epoch']==expected_epoch
    assert set(saved['state_dict'])==adapters
    assert all(torch.equal(current[n].cpu(),saved['state_dict'][n]) for n in adapters)
    source_hash=sha(model.reference_checkpoint)
    assert saved['reference_sha256']==source_hash
    assert saved['adapter_plan_sha256']==sha(ROOT/'PLAN.json')
    full=torch.load(model.reference_checkpoint,map_location='cpu')
    assert full['validation_seed']==full['meta']['seed']==seed
    assert full['meta']['epoch']==expected_epoch
    source=full['state_dict'];original=[n for n in current if not is_adapter(n)]
    assert all(n in source and torch.equal(current[n].cpu(),source[n]) for n in original)
    evidence=dict(status='PASS',rank=rank(),seed=seed,full_source_loaded_before_adapters=True,
        existing_state_keys_verified=len(original),adapter_state_keys_verified=len(adapters),
        reference_checkpoint=model.reference_checkpoint,reference_sha256=source_hash,
        source_epoch=expected_epoch,adapter_checkpoint=str(adapter_checkpoint),
        adapter_sha256=sha(adapter_checkpoint),adapter_epoch=expected_epoch,
        plan_sha256=sha(ROOT/'PLAN.json'))
    del current,saved,source,full
    gathered=[None]*torch.distributed.get_world_size()
    torch.distributed.all_gather_object(gathered,evidence)
    assert len(gathered)==4 and {x['rank'] for x in gathered}==set(range(4))
    assert all(x['status']=='PASS' and x['seed']==seed for x in gathered)
    assert len({x['reference_sha256'] for x in gathered})==1
    assert len({x['adapter_sha256'] for x in gathered})==1
    if rank()==0:
        write(Path(runner.work_dir)/'INFERENCE_MODEL_AUDIT_PASS.json',dict(
            status='PASS',four_ranks_verified=True,ranks=gathered))
    barrier()


def record_predictions(runner,support_smoke):
    if rank()==0:
        w=Path(runner.work_dir)
        prediction=w/('support_smoke.bbox.json' if support_smoke else 'predictions.bbox.json')
        audit=w/'INFERENCE_MODEL_AUDIT_PASS.json'
        assert read(audit)['four_ranks_verified']
        write(w/'INFERENCE_COMPLETE.json',dict(status='PASS',support_smoke=support_smoke,
            predictions_sha256=sha(prediction),model_audit_sha256=sha(audit)))
    barrier()
