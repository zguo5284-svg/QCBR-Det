"""Fixed-final COCO evaluation with full same-seed weight provenance."""
import argparse
import math
from pathlib import Path
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from common import ROOT,OLD_SOURCE,read,write,sha,work_for


def main():
    p=argparse.ArgumentParser();p.add_argument('--domain',required=True)
    p.add_argument('--shot',type=int,required=True);p.add_argument('--seed',type=int,required=True)
    a=p.parse_args();w=work_for(a.seed,'adapter',a.domain,a.shot)
    annotation=Path(read(OLD_SOURCE/'DATA_AUDIT.json')['domains'][a.domain]['splits']['test']['view'])
    prediction=w/'predictions.bbox.json'
    inference=read(w/'INFERENCE_COMPLETE.json');audit_path=w/'INFERENCE_MODEL_AUDIT_PASS.json'
    assert inference['status']=='PASS' and not inference['support_smoke']
    assert inference['predictions_sha256']==sha(prediction)
    assert inference['model_audit_sha256']==sha(audit_path)
    audit=read(audit_path);assert audit['four_ranks_verified']
    last=read(w/'LAST_CHECKPOINT.json')
    assert last['completed_epoch']==100 and last['readback_exact'] and last['head_only']
    assert last['sha256']==sha(last['path'])
    source=work_for(a.seed,'source',a.domain,a.shot)
    source_last=read(source/'LAST_CHECKPOINT.json')
    for phase,folder in [('source',source),('adapter',w)]:
        complete=read(folder/'TRAIN_COMPLETE.json')
        assert complete['completed_epochs']==100 and complete['seed']==a.seed
        assert complete['phase']==phase and not complete['engineering']
        assert complete['plan_sha256']==sha(ROOT/'PLAN.json')
    assert source_last['completed_epoch']==100 and source_last['readback_exact']
    assert source_last['sha256']==last['reference_sha256']==sha(source_last['path'])
    assert all(x['seed']==a.seed and x['source_epoch']==x['adapter_epoch']==100
               and x['adapter_sha256']==last['sha256'] and x['reference_sha256']==last['reference_sha256']
               for x in audit['ranks'])
    raw=read(annotation);pred=read(prediction)
    ids={x['id'] for x in raw['images']};cats={x['id'] for x in raw['categories']}
    assert len(pred)==300*len(ids)
    assert all(x['image_id'] in ids and x['category_id'] in cats and math.isfinite(x['score'])
               and all(math.isfinite(v) for v in x['bbox']) for x in pred)
    gt=COCO(str(annotation));gt.dataset.setdefault('info',{})
    evaluator=COCOeval(gt,gt.loadRes(pred),'bbox')
    evaluator.params.imgIds=sorted(ids);evaluator.params.catIds=sorted(cats)
    evaluator.params.maxDets=[1,10,100]
    evaluator.evaluate();evaluator.accumulate();evaluator.summarize()
    names=['AP','AP50','AP75','APs','APm','APl','AR1','AR10','AR100','ARs','ARm','ARl']
    metrics={k:float(v)*100 for k,v in zip(names,evaluator.stats)}
    assert all(math.isfinite(x) for x in metrics.values())
    result=dict(method='Fixed QCAL-HED + OCCA + SABR candidate v2',domain=a.domain,shot=a.shot,
        seed=a.seed,metrics=metrics,metric='COCO bbox AP@[0.50:0.95] (%)',maxDets=[1,10,100],
        backbone='Swin-B',training_budget='100 same-seed source epochs + 100 adapter-only epochs',
        support_resampled=False,evaluation_images=len(ids),candidate_detections=len(pred),
        adapter_checkpoint=last,reference_checkpoint=source_last,
        inference_model_audit_sha256=sha(audit_path),four_rank_inference_weights_verified=True,
        predictions_sha256=sha(prediction),annotation_sha256=sha(annotation),
        support_annotation_sha256=sha(read(OLD_SOURCE/'DATA_AUDIT.json')['domains'][a.domain]['splits'][f'{a.shot}_shot']['view']),
        source_pretrained_sha256=read(source/'SOURCE_COVERAGE_PASS.json')['source_sha256'],
        plan_sha256=sha(ROOT/'PLAN.json'),model_selection='fixed final epoch100 per phase; no AP selection')
    write(w/'RESULT.json',result)
    write(w/'COMPLETE.json',dict(status='COMPLETE',result_sha256=sha(w/'RESULT.json')))


if __name__=='__main__':main()
