"""Three-seed arithmetic means and sample SD; never select best seed cells."""
import argparse
import statistics
from common import ROOT,OLD_SOURCE,OLD_FINAL,DOMAINS,SHOTS,NEW_SEEDS,read,write,sha,work_for

METRICS=['AP','AP50','AP75']


def mean_sd(values):
    assert len(values)==3
    return dict(n=3,mean=statistics.mean(values),std=statistics.stdev(values),ddof=1)


def collect(persist=True):
    done=read(OLD_FINAL/'ALL_COMPLETE.json')
    assert done['results_sha256']==sha(OLD_FINAL/'RESULTS.json')
    old=read(OLD_FINAL/'RESULTS.json');assert old['completed']==18 and old['seed']==0
    results=[];origin=[]
    for v in old['results']:
        w=OLD_FINAL/'runs'/f"{v['domain']}_{v['shot']}shot_seed0"
        assert read(w/'COMPLETE.json')['result_sha256']==sha(w/'RESULT.json')
        assert v['four_rank_inference_weights_verified']
        results.append(v);origin.append(dict(seed=0,domain=v['domain'],shot=v['shot'],
                                            path=str(w/'RESULT.json'),sha256=sha(w/'RESULT.json')))
    for seed in NEW_SEEDS:
        for shot in SHOTS:
            for domain in DOMAINS:
                w=work_for(seed,'adapter',domain,shot)
                if not (w/'COMPLETE.json').exists():continue
                assert read(w/'COMPLETE.json')['result_sha256']==sha(w/'RESULT.json')
                v=read(w/'RESULT.json')
                assert (v['seed'],v['domain'],v['shot'])==(seed,domain,shot)
                assert v['four_rank_inference_weights_verified'] and v['plan_sha256']==sha(ROOT/'PLAN.json')
                assert v['inference_model_audit_sha256']==sha(w/'INFERENCE_MODEL_AUDIT_PASS.json')
                assert v['annotation_sha256']==next(x['annotation_sha256'] for x in old['results']
                    if x['domain']==domain and x['shot']==shot)
                assert v['support_annotation_sha256']==read(OLD_SOURCE/'DATA_AUDIT.json')['domains'][domain]['splits'][f'{shot}_shot']['view_sha256']
                results.append(v);origin.append(dict(seed=seed,domain=domain,shot=shot,
                    path=str(w/'RESULT.json'),sha256=sha(w/'RESULT.json')))
    keys=[(v['seed'],v['domain'],v['shot']) for v in results]
    assert len(set(keys))==len(keys)
    cells={}
    for shot in SHOTS:
        cells[str(shot)]={}
        for domain in DOMAINS:
            values=sorted([v for v in results if v['domain']==domain and v['shot']==shot],key=lambda x:x['seed'])
            available=[v['seed'] for v in values]
            assert len(available)==len(set(available))
            cells[str(shot)][domain]=dict(available_seeds=available,
                metrics={m:mean_sd([v['metrics'][m] for v in values]) if available==[0,1,2] else None for m in METRICS})
    seed_averages={}
    for seed in [0,1,2]:
        seed_averages[str(seed)]={}
        for shot in SHOTS:
            group=[v for v in results if v['seed']==seed and v['shot']==shot]
            seed_averages[str(seed)][str(shot)]={m:sum(v['metrics'][m] for v in group)/6 for m in METRICS} if len(group)==6 else None
    averages={}
    for shot in SHOTS:
        group=[seed_averages[str(seed)][str(shot)] for seed in [0,1,2]]
        averages[str(shot)]={m:mean_sd([x[m] for x in group]) for m in METRICS} if all(group) else None
    final=dict(method='Fixed QCAL-HED + OCCA + SABR candidate v2',completed=len(results),planned=54,
        new_completed=len(results)-18,new_planned=36,seeds=[0,1,2],reused_seed0=True,
        results=results,cells=cells,seed_averages=seed_averages,averages=averages,
        provenance=origin,metric='COCO bbox AP@[0.50:0.95] (%)',sample_std_ddof=1,
        fixed_support_splits=True,support_resampling_variability_measured=False,
        results_selected_by_test_AP=False,backbone='Swin-B',
        training_budget='Per seed: 100 source epochs + 100 adapter-only epochs',
        paper_reported_average={'1':18.2,'5':34.7,'10':39.8},
        limitations='Previously observed tests; optimization-seed stability only; not same-backbone/source/budget VFMDETR comparison')
    if persist:
        write(ROOT/'RESULTS.json',final)
        if len(results)==54:
            table={str(shot):{d:cells[str(shot)][d]['metrics']['AP']['mean'] for d in DOMAINS} for shot in SHOTS}
            for shot in SHOTS:table[str(shot)]['Average']=averages[str(shot)]['AP']['mean']
            write(ROOT/'THREE_SEED_AP_MEAN_TABLE.json',dict(metric=final['metric'],seeds=[0,1,2],table=table))
    return final


def self_test():
    x=mean_sd([1,2,3]);assert x['mean']==2 and x['std']==1 and x['ddof']==1
    # SD of a seed-wise domain average is not the average of cell SDs.
    by_seed=[[1,3],[2,2],[3,1]]
    assert mean_sd([statistics.mean(v) for v in by_seed])['std']==0
    assert statistics.mean([statistics.stdev(v) for v in zip(*by_seed)])==1


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--self-test',action='store_true');a=p.parse_args()
    if a.self_test:self_test();print('AGGREGATE_UNIT_PASS')
    else:print('COLLECTED',collect()['completed'])
