"""Terminal COCO evaluation only; no selection/schedule feedback."""
import argparse
import math
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from control_common import ROOT,SOURCE,read,write,sha,work_for,reference

def evaluate(variant,domain,shot,seed):
    w=work_for(variant,domain,shot,seed);data=read(SOURCE/'DATA_AUDIT.json')['domains'][domain]['splits']
    ann=data['test']['view'];pred=w/'predictions.bbox.json'
    inf=read(w/'INFERENCE_COMPLETE.json');audit=read(w/'INFERENCE_MODEL_AUDIT_PASS.json')
    last=read(w/'LAST_CHECKPOINT.json');done=read(w/'TRAIN_COMPLETE.json')
    assert inf['status']=='PASS' and not inf['support_smoke'] and audit['four_ranks_verified']
    assert inf['predictions_sha256']==sha(pred) and inf['model_audit_sha256']==sha(w/'INFERENCE_MODEL_AUDIT_PASS.json')
    assert last['completed_epoch']==done['completed_epochs']==100 and last['readback_exact']
    assert last['sha256']==sha(last['path']) and done['plan_sha256']==sha(ROOT/'PLAN.json')
    assert (done['variant'],done['domain'],done['shot'],done['seed'])==(variant,domain,shot,seed)
    assert all((r['variant'],r['domain'],r['shot'],r['seed'],r['checkpoint_sha256'])==
               (variant,domain,shot,seed,last['sha256']) for r in audit['ranks'])
    raw=read(ann);predictions=read(pred);ids={r['id'] for r in raw['images']};cats={r['id'] for r in raw['categories']}
    assert len(predictions)==300*len(ids)
    assert all(r['image_id'] in ids and r['category_id'] in cats and math.isfinite(r['score']) and
               all(math.isfinite(v) for v in r['bbox']) for r in predictions)
    gt=COCO(ann);gt.dataset.setdefault('info',{})
    ev=COCOeval(gt,gt.loadRes(predictions),'bbox');ev.params.imgIds=sorted(ids);ev.params.catIds=sorted(cats)
    ev.params.maxDets=[1,10,100];ev.evaluate();ev.accumulate();ev.summarize()
    names=['AP','AP50','AP75','APs','APm','APl','AR1','AR10','AR100','ARs','ARm','ARl']
    metrics={k:float(v)*100 for k,v in zip(names,ev.stats)}
    # COCO -1 is explicitly unavailable, never presented as zero accuracy.
    metrics={k:(None if v<0 else v) for k,v in metrics.items()}
    assert all(v is None or math.isfinite(v) for v in metrics.values())
    result=dict(variant=variant,domain=domain,shot=shot,seed=seed,metrics=metrics,checkpoint=last,
        backbone='Swin-B',metric='COCO bbox AP@[0.50:0.95] (%)',source_epochs=100 if variant=='hed100' else 200,
        additional_phase_epochs=100 if variant=='hed200' else 0,phase_updates=done['completed_iter'],
        evaluation_images=len(ids),annotation_sha256=sha(ann),support_annotation_sha256=sha(data[f'{shot}_shot']['view']),
        predictions_sha256=sha(pred),four_rank_inference_weights_verified=True,fixed_support=True,
        plan_sha256=sha(ROOT/'PLAN.json'),selection='fixed final epoch, no AP selection')
    if variant=='hed200':
        ref=reference(domain,seed);result.update(warm_start=ref['checkpoint'],total_updates=done['completed_iter']+ref['checkpoint']['completed_iter'])
    else:result['total_updates']=done['completed_iter']
    write(w/'RESULT.json',result);write(w/'COMPLETE.json',dict(status='COMPLETE',result_sha256=sha(w/'RESULT.json')))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--variant',required=True);p.add_argument('--domain',required=True)
    p.add_argument('--shot',type=int,required=True);p.add_argument('--seed',type=int,required=True)
    a=p.parse_args();evaluate(a.variant,a.domain,a.shot,a.seed)
