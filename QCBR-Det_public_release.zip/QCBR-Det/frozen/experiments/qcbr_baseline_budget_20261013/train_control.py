"""Four-rank train/inference entry with exact tensor and protocol audits."""
import argparse
from pathlib import Path
import torch
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmdet.utils import register_all_modules
from qcal_runtime import rank,model_of,barrier,ControlledPause
from control_common import ROOT,SOURCE,read,write,sha
from control_config import make_config

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--variant',required=True);p.add_argument('--domain',required=True)
    p.add_argument('--shot',type=int,required=True);p.add_argument('--seed',type=int,required=True)
    p.add_argument('--work-dir',required=True);p.add_argument('--engineering',action='store_true')
    p.add_argument('--resume');p.add_argument('--test',action='store_true');p.add_argument('--support-smoke',action='store_true')
    a=p.parse_args();register_all_modules(init_default_scope=True)
    cfg=make_config(a.variant,a.domain,a.shot,a.seed,a.work_dir,a.engineering)
    import_modules_from_strings(**cfg.custom_imports)
    if a.resume:cfg.load_from=a.resume;cfg.resume=not a.test
    if a.support_smoke:
        assert a.test
        ann=read(SOURCE/'DATA_AUDIT.json')['domains'][a.domain]['splits'][f'{a.shot}_shot']['view']
        cfg.test_dataloader.dataset.ann_file=ann
        cfg.test_dataloader.dataset.data_prefix.img=cfg.train_dataloader.dataset.data_prefix.img
        cfg.test_evaluator.ann_file=ann;cfg.test_evaluator.outfile_prefix=str(Path(a.work_dir)/'support_smoke')
    runner=Runner.from_cfg(cfg);assert runner.seed==a.seed
    if not a.test:
        runner.train()
        if rank()==0:write(Path(a.work_dir)/'TRAIN_COMPLETE.json',dict(
            variant=a.variant,domain=a.domain,shot=a.shot,seed=a.seed,completed_epochs=runner.epoch,
            completed_iter=runner.iter,plan_sha256=sha(ROOT/'PLAN.json'),engineering=a.engineering))
        return
    assert a.resume
    model=model_of(runner);model.init_weights();runner.load_or_resume()
    saved=torch.load(a.resume,map_location='cpu');current=model.state_dict()
    expected=2 if a.engineering else 100
    assert saved['meta']['seed']==a.seed and saved['meta']['epoch']==expected
    assert saved['control_variant']==a.variant and saved['control_domain']==a.domain and saved['control_shot']==a.shot
    assert saved['ablation_plan_sha256']==sha(ROOT/'PLAN.json')
    assert set(current)==set(saved['state_dict'])
    assert all(torch.equal(t.cpu(),saved['state_dict'][n]) for n,t in current.items())
    assert not hasattr(model.bbox_head,'quality_net') and not hasattr(model.bbox_head,'occa') and not hasattr(model.bbox_head,'sabr')
    evidence=dict(rank=rank(),seed=a.seed,domain=a.domain,shot=a.shot,variant=a.variant,
                  checkpoint_sha256=sha(a.resume),state_keys=len(current),all_tensors_equal=True)
    gathered=[None]*4;torch.distributed.all_gather_object(gathered,evidence)
    assert {r['rank'] for r in gathered}==set(range(4))
    assert len({r['checkpoint_sha256'] for r in gathered})==1
    if rank()==0:write(Path(a.work_dir)/'INFERENCE_MODEL_AUDIT_PASS.json',dict(status='PASS',four_ranks_verified=True,ranks=gathered))
    del saved,current
    barrier();runner.test()
    if rank()==0:
        w=Path(a.work_dir);pred=w/('support_smoke.bbox.json' if a.support_smoke else 'predictions.bbox.json')
        write(w/'INFERENCE_COMPLETE.json',dict(status='PASS',support_smoke=a.support_smoke,
              predictions_sha256=sha(pred),model_audit_sha256=sha(w/'INFERENCE_MODEL_AUDIT_PASS.json')))
    barrier()

if __name__=='__main__':
    try:main()
    except ControlledPause:
        if torch.distributed.is_initialized():torch.distributed.destroy_process_group()
        raise SystemExit(75)
