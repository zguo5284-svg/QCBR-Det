"""HED-only model and original source recipe; additional budget is explicit."""
from qcal_config import make_config as original_config
from control_common import ROOT,reference

def make_config(variant,domain,shot,seed,work,engineering=False):
    cfg=original_config(domain,shot,work,False)
    cfg.custom_imports=dict(imports=['ablation_model','ablation_runtime','control_runtime'],allow_failed_imports=False)
    cfg.randomness.seed=seed
    cfg.model.update(type='AblationSourceDetector',hed=True)
    cfg.model.bbox_head.update(type='AblationSourceHead',hed=True,qcal=False)
    epochs=2 if engineering else 100
    cfg.train_cfg.max_epochs=epochs
    cfg.custom_hooks=[
        dict(type='AblationStageHook',root=str(ROOT),stage2_epoch=(1 if engineering else 50) if variant=='hed100' else 0,total_epochs=epochs),
        dict(type='ControlCheckpointHook',root=str(ROOT),seed=seed,mask='1000',engineering=engineering,
             total_epochs=epochs,variant=variant,domain=domain,shot=shot)]
    if variant=='hed200':
        assert shot==10
        cfg.load_from=reference(domain,seed)['checkpoint']['path']
    return cfg
