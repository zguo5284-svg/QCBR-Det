"""Inherited audited checkpointing, with exact warm-start and RNG evidence."""
import random
from pathlib import Path
import numpy as np
import torch
from mmengine.registry import HOOKS
from ablation_runtime import AblationSourceHook
from qcal_runtime import model_of,rank,barrier,mixup_transforms
from control_common import ROOT,read,write,sha,reference

@HOOKS.register_module()
class ControlCheckpointHook(AblationSourceHook):
    def __init__(self,variant,domain,shot,**kwargs):
        super().__init__(**kwargs)
        self.variant=variant;self.domain=domain;self.shot=shot

    def after_load_checkpoint(self,runner,checkpoint):
        super().after_load_checkpoint(runner,checkpoint)
        if getattr(runner,'_resume',False):
            assert checkpoint['control_variant']==self.variant
            assert checkpoint['control_domain']==self.domain and checkpoint['control_shot']==self.shot

    def before_train(self,runner):
        if self.variant=='hed100' or getattr(runner,'_resume',False):
            super().before_train(runner)
            return
        assert runner.seed==self.seed
        model=model_of(runner)
        assert not hasattr(model.bbox_head,'quality_net')
        assert not hasattr(model.bbox_head,'occa') and not hasattr(model.bbox_head,'sabr')
        rec=reference(self.domain,self.seed);path=Path(rec['checkpoint']['path'])
        assert sha(path)==rec['checkpoint']['sha256']
        saved=torch.load(path,map_location='cpu')
        assert saved['meta']['seed']==self.seed and saved['meta']['epoch']==100
        assert saved['ablation_mask']=='1000' and saved['ablation_phase']=='source'
        current=model.state_dict()
        assert set(current)==set(saved['state_dict'])
        assert all(torch.equal(t.cpu(),saved['state_dict'][n]) for n,t in current.items())
        assert not runner.optim_wrapper.optimizer.state,'Budget phase starts with fresh optimizer moments'
        info=saved['ablation_rank_states'][rank()]
        assert sha(info['path'])==info['sha256']
        state=torch.load(info['path'],map_location='cpu')
        assert state['epoch']==100
        for index,transform in mixup_transforms(runner):transform.results_cache=state['augmentation_caches'][index]
        random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
        torch.set_rng_state(state['torch_rng']);torch.cuda.set_rng_state(state['cuda_rng'])
        self.initial_iter=rec['checkpoint']['completed_iter']
        if self.engineering:
            self.budget_probe={n:p.detach().cpu().clone() for n,p in model.named_parameters()
                               if n.startswith('decoder.') and n.endswith('weight')}
        if rank()==0:write(Path(runner.work_dir)/'WARM_START_PASS.json',dict(status='PASS',
            reference=str(path),reference_sha256=rec['checkpoint']['sha256'],seed=self.seed,shot=self.shot,
            every_existing_tensor_equal=True,all_rank_RNG_cache_restored=True,fresh_optimizer=True,
            original_completed_epochs=100,original_completed_iter=self.initial_iter))
        del current,saved,state
        barrier()

    def after_train_iter(self,runner,batch_idx,data_batch=None,outputs=None):
        super().after_train_iter(runner,batch_idx,data_batch,outputs)
        if rank()==0:
            p=Path(runner.work_dir)/'PROGRESS.json';obj=read(p)
            obj.update(variant=self.variant,domain=self.domain,shot=self.shot,
                       prior_source_epochs=100 if self.variant=='hed200' else 0)
            write(p,obj)

    def after_train_epoch(self,runner):
        super().after_train_epoch(runner)
        if self.engineering and hasattr(self,'budget_probe') and runner.epoch+1==runner.max_epochs:
            params=dict(model_of(runner).named_parameters())
            assert any(not torch.equal(params[n].detach().cpu(),v) for n,v in self.budget_probe.items())
            if rank()==0:write(Path(runner.work_dir)/'BUDGET_ACTIVE_UPDATE_PASS.json',dict(status='PASS',
                detector_parameters_actually_updated=True,no_frozen_noop_budget=True))

    def before_save_checkpoint(self,runner,checkpoint):
        super().before_save_checkpoint(runner,checkpoint)
        checkpoint.update(control_variant=self.variant,control_domain=self.domain,control_shot=self.shot,
            prior_source_epochs=100 if self.variant=='hed200' else 0)
