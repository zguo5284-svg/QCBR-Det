"""Separate controls; imports and original experiments remain immutable."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path('/root/autodl-tmp/vfmdetr_repro')
SOURCE = BASE/'experiments/qcal_hed_20261006'
EXTENSION = BASE/'experiments/qcal_hed_occa_sabr_20261007'
THREE = BASE/'experiments/qcal_hed_occa_sabr_three_seeds_20261007'
ABLATION = BASE/'experiments/qcal_hed_ablation_10shot_20261008'
PY = BASE/'software/envs/qcal_hed/bin/python'
DOMAINS = ['ArTaxOr', 'clipart1k', 'DIOR', 'FISH', 'NEU-DET', 'UODD']
CODE = ['PLAN.json','control_common.py','control_config.py','control_runtime.py',
        'train_control.py','evaluate_control.py','driver_control.py']

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def reference(domain,seed):
    return next(r for r in read(ABLATION/'RESULTS.json')['results']
                if (r['mask'],r['domain'],r['seed'])==('1000',domain,seed))

def work_for(variant,domain,shot,seed,engineering=False):
    assert variant in ('hed100','hed200') and domain in DOMAINS and shot in (1,5,10) and seed in (0,1,2)
    return ROOT/('engineering' if engineering else 'runs')/variant/f'{domain}_{shot}shot_seed{seed}'

def verify_frozen():
    for p in (SOURCE,EXTENSION,THREE,ABLATION):
        for n,v in read(p/'FROZEN_MANIFEST.json').items():assert sha(p/n)==v,(str(p),n)
    plan=read(ROOT/'PLAN.json')
    for p,key in ((THREE,'main_results_sha256'),(ABLATION,'ablation_results_sha256')):
        assert sha(p/'RESULTS.json')==read(p/'ALL_COMPLETE.json')['results_sha256']==plan['references'][key]
    if (ROOT/'FROZEN_MANIFEST.json').exists():
        for n,v in read(ROOT/'FROZEN_MANIFEST.json').items():assert sha(ROOT/n)==v,n

def jobs():
    # Scope and ordering are preregistered, independent of measured AP.
    for seed in (0,1,2):
        for shot in (1,5):
            for domain in DOMAINS:yield 'hed100',domain,shot,seed
    for seed in (0,1,2):
        for domain in DOMAINS:yield 'hed200',domain,10,seed
