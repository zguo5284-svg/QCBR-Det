"""16 factorial rows, using exactly three seeds per mean, never best cells."""
import statistics
from common_ablation import ROOT,THREE,MASKS,DOMAINS,read,write,sha,result_work

def collect():
    marker=read(THREE/'ALL_COMPLETE.json');assert sha(THREE/'RESULTS.json')==marker['results_sha256']
    results=[dict(r,mask='1111',reused_verified=True) for r in read(THREE/'RESULTS.json')['results'] if r['shot']==10]
    assert len(results)==18
    for mask in MASKS[:-1]:
        for seed in (0,1,2):
            for domain in DOMAINS:
                w=result_work(mask,domain,seed)
                if not (w/'COMPLETE.json').exists():continue
                assert read(w/'COMPLETE.json')['result_sha256']==sha(w/'RESULT.json')
                r=read(w/'RESULT.json');assert (r['mask'],r['domain'],r['seed'],r['shot'])==(mask,domain,seed,10)
                assert r['four_rank_inference_weights_verified'] and r['plan_sha256']==sha(ROOT/'PLAN.json')
                results.append(r)
    assert len({(r['mask'],r['domain'],r['seed']) for r in results})==len(results)
    rows=[]
    for mask in MASKS:
        values={};std={};available={};seed_averages={}
        for d in DOMAINS:
            group=sorted([r for r in results if r['mask']==mask and r['domain']==d],key=lambda r:r['seed'])
            available[d]=[r['seed'] for r in group]
            aps=[r['metrics']['AP'] for r in group]
            values[d]=statistics.mean(aps) if available[d]==[0,1,2] else None
            std[d]=statistics.stdev(aps) if len(aps)==3 else None
        for seed in (0,1,2):
            group=[r for r in results if r['mask']==mask and r['seed']==seed]
            seed_averages[str(seed)]=statistics.mean([r['metrics']['AP'] for r in group]) if len(group)==6 else None
        av=list(seed_averages.values());values['Average']=statistics.mean(av) if all(x is not None for x in av) else None
        std['Average']=statistics.stdev(av) if all(x is not None for x in av) else None
        rows.append(dict(mask=mask,module_count=mask.count('1'),AP=values,std_ddof1=std,available_seeds=available,seed_averages=seed_averages))
    table=dict(completed=len(results),planned=288,new_completed=len(results)-18,new_planned=270,results=results,rows=rows,
        shot=10,seeds=[0,1,2],module_order=['HED','QCAL','OCCA','SABR'],metric='COCO bbox AP@[0.50:0.95] (%)',
        missing_values_estimated=False,full_method_reused=True,source_only_rows_have_no_adapter_training=True)
    write(ROOT/'RESULTS.json',table)
    text=['10-shot ablation: three optimization-seed means; incomplete cells remain —.','',
        '| HED | QCAL | OCCA | SABR | ArTaxOr | Clipart1k | DIOR | DeepFish | NEU-DET | UODD | Average |',
        '|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for row in rows:
        text.append('| '+' | '.join(['✓' if x=='1' else '—' for x in row['mask']]+[f'{row["AP"][d]:.2f}' if row['AP'][d] is not None else '—' for d in DOMAINS+['Average']])+' |')
    (ROOT/'RESULTS.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    return table

if __name__=='__main__':print('COLLECTED',collect()['completed'])

