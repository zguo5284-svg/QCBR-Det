"""All data, optimizer, augmentation and epoch budgets inherited unchanged."""
from common_ablation import ROOT,source_checkpoint
from qcal_config import make_config as fixed_config

def make_config(mask,domain,seed,phase,work_dir,engineering=False):
    cfg=fixed_config(domain,10,work_dir,False)
    cfg.custom_imports=dict(imports=['ablation_model','ablation_runtime'],allow_failed_imports=False)
    cfg.randomness.seed=seed
    cfg.model.update(type='AblationSourceDetector',hed=mask[0]=='1')
    cfg.model.bbox_head.update(type='AblationSourceHead',hed=mask[0]=='1',qcal=mask[1]=='1')
    epochs=2 if engineering else 100
    cfg.train_cfg.max_epochs=epochs
    if phase=='source':
        cfg.custom_hooks=[dict(type='AblationStageHook',root=str(ROOT),stage2_epoch=1 if engineering else 50,total_epochs=epochs),
            dict(type='AblationSourceHook',root=str(ROOT),engineering=engineering,seed=seed,mask=mask)]
    else:
        assert mask[2:]!='00'
        cfg.model.update(type='AblationAdapterDetector',reference_checkpoint=str(source_checkpoint(mask[:2],domain,seed,engineering)))
        cfg.model.bbox_head.update(type='AblationAdapterHead',occa=mask[2]=='1',sabr=mask[3]=='1')
        cfg.load_from=None
        cfg.optim_wrapper=dict(type='AdapterOptimWrapper',optimizer=dict(type='AdamW',lr=1e-4,weight_decay=.05),
                               clip_grad=dict(max_norm=.1,norm_type=2))
        cfg.custom_hooks=[dict(type='AblationAdapterHook',root=str(ROOT),total_epochs=epochs,engineering=engineering,seed=seed,mask=mask)]
        cfg.model_wrapper_cfg.find_unused_parameters=False
    return cfg
