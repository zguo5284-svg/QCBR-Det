"""True component removals, with the frozen all-on implementation unchanged.

HED-off restores the upstream six-layer serial decoder and last-layer output.
QCAL-off removes its parameters/loss/calibration and supplies neutral evidence.
Disabled residual adapters have neither parameters nor losses.
"""
import torch
from torch import nn
from torch.nn import functional as F
from mmengine.structures import InstanceData
from mmdet.registry import MODELS
from mmdet.models.detectors.grounding_dino import GroundingDINO
from mmdet.models.detectors.dino import DINO
from mmdet.models.dense_heads.grounding_dino_head_HED import GroundingDINOHead_ParallelDecoder_DN
from mmdet.models.dense_heads.atss_vlfusion_head import convert_grounding_to_cls_scores
from mmdet.structures.bbox import bbox_cxcywh_to_xyxy,bbox_overlaps
from qcal_model import QCalHEDDetector,QCalHEDHead
from extension_model import FourModuleHead,FourModuleDetector,is_adapter,global_count

@MODELS.register_module()
class AblationSourceDetector(QCalHEDDetector):
    def __init__(self,hed=True,**kwargs):
        self.hed_enabled=hed
        super().__init__(**kwargs)

    def _init_layers(self):
        if self.hed_enabled:super()._init_layers()
        else:GroundingDINO._init_layers(self)

    def pre_decoder(self,*args,**kwargs):
        if self.hed_enabled:return super().pre_decoder(*args,**kwargs)
        return GroundingDINO.pre_decoder(self,*args,**kwargs)

    def forward_decoder(self,query,memory,memory_mask,reference_points,spatial_shapes,
                        level_start_index,valid_ratios,dn_mask=None,**kwargs):
        inputs=dict(query=query,memory=memory,memory_mask=memory_mask,
                    reference_points=reference_points,spatial_shapes=spatial_shapes,
                    level_start_index=level_start_index,valid_ratios=valid_ratios,dn_mask=dn_mask)
        if self.hed_enabled:return super().forward_decoder(**inputs,**kwargs)
        output=DINO.forward_decoder(self,**inputs,**kwargs)
        output.update(quality_memory=memory.detach(),quality_shapes=spatial_shapes,
                      quality_ratios=valid_ratios,quality_mask=memory_mask)
        return output

@MODELS.register_module()
class AblationSourceHead(QCalHEDHead):
    def __init__(self,hed=True,qcal=True,**kwargs):
        self.hed_enabled=hed;self.qcal_enabled=qcal
        super().__init__(**kwargs)
        if not qcal:del self.quality_net

    def reset_quality_output(self):
        if hasattr(self,'quality_net'):super().reset_quality_output()

    def quality_logits(self,hidden_states,boxes,*args):
        if not self.qcal_enabled:return boxes.new_zeros(boxes.shape[:2])
        states=hidden_states if self.hed_enabled else hidden_states[-1:]
        return super().quality_logits(states,boxes,*args)

    def multiplier(self,logits):
        return super().multiplier(logits) if self.qcal_enabled else torch.ones_like(logits)

    def loss(self,hidden_states,references,memory_text,text_token_mask,enc_outputs_class,
             enc_outputs_coord,batch_data_samples,dn_meta,quality_memory,quality_shapes,
             quality_ratios,quality_mask):
        arguments=dict(hidden_states=hidden_states,references=references,memory_text=memory_text,
            text_token_mask=text_token_mask,enc_outputs_class=enc_outputs_class,
            enc_outputs_coord=enc_outputs_coord,batch_data_samples=batch_data_samples,dn_meta=dn_meta)
        if not self.qcal_enabled:
            return GroundingDINOHead_ParallelDecoder_DN.loss(self,**arguments)
        if self.hed_enabled:
            return QCalHEDHead.loss(self,**arguments,quality_memory=quality_memory,
                quality_shapes=quality_shapes,quality_ratios=quality_ratios,quality_mask=quality_mask)
        classes,coordinates=self(hidden_states,references,memory_text,text_token_mask)
        gt=[s.gt_instances for s in batch_data_samples];metas=[s.metainfo for s in batch_data_samples]
        self.text_masks=text_token_mask
        losses=self.loss_by_feat(classes,coordinates,enc_outputs_class,enc_outputs_coord,gt,metas,dn_meta)
        boxes=coordinates[-1,:,-self.matching_queries:].detach()
        logits=self.quality_logits(hidden_states,boxes,quality_memory,quality_shapes,quality_ratios,quality_mask)
        raw=classes[-1,:,-self.matching_queries:].detach()
        terms=[];count=0
        for i,(instances,meta) in enumerate(zip(gt,metas)):
            with torch.no_grad():
                h,w=meta['img_shape'][:2]
                pixel=bbox_cxcywh_to_xyxy(boxes[i])*boxes.new_tensor([w,h,w,h])
                assigned=self.assigner.assign(InstanceData(scores=raw[i],bboxes=pixel),instances,meta)
                pos=torch.where(assigned.gt_inds>0)[0]
                targets=bbox_overlaps(pixel[pos],instances.bboxes[assigned.gt_inds[pos]-1],
                                      is_aligned=True).clamp(0,1)
            if len(pos):terms.append(F.binary_cross_entropy_with_logits(logits[i,pos],targets,reduction='sum'))
            count+=len(pos)
        losses['loss_quality']=self.quality_weight*sum(terms,logits.sum()*0)/global_count(logits.new_tensor(float(count)))
        self.last_quality_diagnostics=dict(positives=count,finite=bool(torch.isfinite(logits).all()),
                                           mean_quality=float(logits.detach().sigmoid().mean()))
        return losses

    def predict(self,hidden_states,references,memory_text,text_token_mask,batch_data_samples,
                quality_memory,quality_shapes,quality_ratios,quality_mask,rescale=True):
        if self.hed_enabled and self.qcal_enabled:
            return QCalHEDHead.predict(self,hidden_states,references,memory_text,text_token_mask,
                batch_data_samples,quality_memory,quality_shapes,quality_ratios,quality_mask,rescale)
        classes,coords=self(hidden_states,references,memory_text,text_token_mask)
        if not self.hed_enabled:classes=classes[-1:];coords=coords[-1:]
        boxes=coords.mean(0)
        factors=self.multiplier(self.quality_logits(hidden_states,boxes,quality_memory,
                                                   quality_shapes,quality_ratios,quality_mask))
        result=[]
        for i,sample in enumerate(batch_data_samples):
            mapping=sample.token_positive_map
            scores=torch.stack([layer[i].sigmoid() if mapping is None else
                convert_grounding_to_cls_scores(layer[i].sigmoid()[None],[mapping])[0]
                for layer in classes]).mean(0)*factors[i,:,None]
            result.append(self._predict_by_feat_single(scores,boxes[i],mapping,sample.metainfo,rescale))
        return result

@MODELS.register_module()
class AblationAdapterDetector(AblationSourceDetector):
    def __init__(self,reference_checkpoint,**kwargs):
        self.reference_checkpoint=reference_checkpoint
        super().__init__(**kwargs)
        for name,p in self.named_parameters():p.requires_grad_(is_adapter(name))
        self.train(False)

    def init_weights(self):
        super().init_weights()
        raw=torch.load(self.reference_checkpoint,map_location='cpu');source=raw['state_dict']
        current=self.state_dict();original=[n for n in current if not is_adapter(n)]
        assert all(n in source and source[n].shape==current[n].shape for n in original)
        missing,unexpected=self.load_state_dict(source,strict=False)
        assert all(is_adapter(n) for n in missing) and not unexpected
        self.bbox_head.reset_adapters()
        self._reference_loaded_exact=all(torch.equal(current[n].cpu(),source[n]) for n in original)
        assert self._reference_loaded_exact
    loss=FourModuleDetector.loss

    def train(self,mode=True):
        super().train(False)
        for name in ('occa','sabr'):
            if hasattr(self.bbox_head,name):getattr(self.bbox_head,name).train(mode)
        return self

@MODELS.register_module()
class AblationAdapterHead(FourModuleHead,AblationSourceHead):
    def __init__(self,occa=True,sabr=True,**kwargs):
        self.occa_enabled=occa;self.sabr_enabled=sabr
        assert occa or sabr
        super().__init__(**kwargs)
        if not occa:del self.occa
        if not sabr:del self.sabr

    def reset_adapters(self):
        for name in ('occa','sabr'):
            if hasattr(self,name):
                nn.init.zeros_(getattr(self,name)[-1].weight)
                nn.init.zeros_(getattr(self,name)[-1].bias)

    def _base(self,hidden_states,references,memory_text,text_token_mask,samples,
              quality_memory,quality_shapes,quality_ratios,quality_mask):
        if self.hed_enabled and self.qcal_enabled:
            return FourModuleHead._base(self,hidden_states,references,memory_text,text_token_mask,samples,
                quality_memory,quality_shapes,quality_ratios,quality_mask)
        with torch.no_grad():
            token_logits,coords=self(hidden_states,references,memory_text,text_token_mask)
            assert coords.shape[2]==self.matching_queries
            if not self.hed_enabled:
                token_logits=token_logits[-1:];coords=coords[-1:];hidden_states=hidden_states[-1:]
            boxes=coords.mean(0)
            scores=torch.stack([torch.stack([convert_grounding_to_cls_scores(
                layer[i].sigmoid()[None],[sample.token_positive_map])[0]
                for layer in token_logits]).mean(0) for i,sample in enumerate(samples)])
            quality_logits=self.quality_logits(hidden_states,boxes,quality_memory,quality_shapes,quality_ratios,quality_mask)
            quality=quality_logits.sigmoid() if self.qcal_enabled else torch.ones_like(quality_logits)
            widths=torch.stack([boxes[...,2],boxes[...,3],boxes[...,2],boxes[...,3]],-1)
            disagreement=coords.std(0,unbiased=False)/widths.clamp_min(1e-3) if self.hed_enabled else torch.zeros_like(boxes)
            agreement=torch.exp(-disagreement.mean(-1).clamp(max=20)) if self.hed_enabled else torch.ones_like(quality)
            inner_levels,context_levels,boundary_levels,level_logits=[],[],[],[]
            start=0
            for level,(height,width) in enumerate(quality_shapes[:3].tolist()):
                size=height*width
                feature=quality_memory[:,start:start+size].float().transpose(1,2).reshape(boxes.shape[0],self.embed_dims,height,width)
                valid=feature.new_ones(boxes.shape[0],1,height,width) if quality_mask is None else (~quality_mask[:,start:start+size]).float().reshape(boxes.shape[0],1,height,width)
                start+=size;ratio=quality_ratios[:,level]
                grid=self._pool(feature,valid,boxes,ratio)
                cx,cy,bw,bh=boxes.unbind(-1)
                rings=[torch.stack([cx,cy-.625*bh,1.5*bw,.25*bh],-1),torch.stack([cx,cy+.625*bh,1.5*bw,.25*bh],-1),
                       torch.stack([cx-.625*bw,cy,.25*bw,bh],-1),torch.stack([cx+.625*bw,cy,.25*bw,bh],-1)]
                context=torch.stack([self._pool(feature,valid,b,ratio).mean((-2,-1)) for b in rings]).mean(0)
                inner=grid.mean((-2,-1))
                edges=torch.cat([grid[:,:,:,0,:].mean(-1),grid[:,:,:,-1,:].mean(-1),grid[:,:,:,:,0].mean(-1),grid[:,:,:,:,-1].mean(-1)],-1)
                inner_levels.append(inner);context_levels.append(inner-context);boundary_levels.append(edges)
                diameter=(bw*bh*ratio[:,None,0]*ratio[:,None,1]*height*width).clamp_min(1e-6).sqrt()
                level_logits.append(-(diameter/4).log2().abs())
            weights=torch.stack(level_logits,-1).softmax(-1)
            def weighted(features):return (torch.stack(features,2)*weights[:,:,:,None]).sum(2)
            query=hidden_states.mean(0).float()
            geometry=torch.cat([boxes,quality[...,None],disagreement],-1)
            return dict(boxes=boxes,scores=scores,quality_logits=quality_logits,gate=(quality*agreement).detach(),
                token_scores=token_logits.sigmoid().mean(0),
                occa_features=torch.cat([query,weighted(inner_levels),weighted(context_levels),geometry],-1),
                sabr_features=torch.cat([query,weighted(boundary_levels),geometry],-1))

    def _extend(self,base):
        if self.occa_enabled and self.sabr_enabled:return FourModuleHead._extend(self,base)
        residual=self.occa(base['occa_features']).tanh() if self.occa_enabled else base['scores'].new_zeros(base['scores'].shape)
        correction=self.sabr(base['sabr_features']).tanh() if self.sabr_enabled else torch.zeros_like(base['boxes'])
        evidence=self.shot/(self.shot+2)*base['gate'][...,None]
        residual=.25*evidence*residual;correction=.10*evidence*correction
        boxes=base['boxes'];scale=torch.stack([boxes[...,2],boxes[...,3],boxes[...,2],boxes[...,3]],-1)
        refined=boxes+correction*scale
        if not self.adapters_enabled:residual=residual*0;refined=boxes
        return refined,residual,correction

    def adapter_loss(self,**kwargs):
        # FourModuleHead's initial identity calls QCalHEDHead.predict directly.
        # In removed-component cases validate identity with the actual source head.
        if not self.identity_checked and not (self.hed_enabled and self.qcal_enabled):
            args={k:v for k,v in kwargs.items() if k in ('hidden_states','references','memory_text','text_token_mask',
                 'batch_data_samples','quality_memory','quality_shapes','quality_ratios','quality_mask')}
            with torch.no_grad():
                a=AblationSourceHead.predict(self,**args);b=self.predict(**args)
                assert all(torch.equal(getattr(x,k),getattr(y,k)) for x,y in zip(a,b) for k in ('scores','labels','bboxes'))
            self.zero_prediction_identity_pass=True;self.identity_checked=True
        losses=FourModuleHead.adapter_loss(self,**kwargs)
        if not self.occa_enabled:losses.pop('loss_occa')
        if not self.sabr_enabled:losses.pop('loss_sabr_l1');losses.pop('loss_sabr_giou')
        return losses
