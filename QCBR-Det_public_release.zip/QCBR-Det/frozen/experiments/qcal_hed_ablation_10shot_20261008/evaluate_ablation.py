"""Same COCO metric as the frozen main experiment; absent results stay absent."""
import argparse
import math
from pathlib import Path
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from common_ablation import ROOT,SOURCE,read,write,sha,source_checkpoint,work_for,result_work

def main():
    p=argparse.ArgumentParser();p.add_argument('--mask',required=True)
    p.add_argument('--domain',required=True);p.add_argument('--seed',required=True,type=int)
    a=p.parse_args();w=result_work(a.mask,a.domain,a.seed)
    audit=read(SOURCE/'DATA_AUDIT.json')['domains'][a.domain]
    ann=Path(audit['splits']['test']['view']);pred=w/'predictions.bbox.json'
    inference=read(w/'INFERENCE_COMPLETE.json');model_audit=read(w/'INFERENCE_MODEL_AUDIT_PASS.json')
    assert inference['status']=='PASS' and not inference['support_smoke'] and model_audit['four_ranks_verified']
    assert inference['predictions_sha256']==sha(pred) and inference['model_audit_sha256']==sha(w/'INFERENCE_MODEL_AUDIT_PASS.json')
    source=source_checkpoint(a.mask[:2],a.domain,a.seed)
    phase='source' if a.mask[2:]=='00' else 'adapter'
    if phase=='adapter':
        trained=work_for(a.mask,a.domain,a.seed,phase)
        last=read(trained/'LAST_CHECKPOINT.json');complete=read(trained/'TRAIN_COMPLETE.json')
        assert last['reference_checkpoint']==str(source) and last['reference_sha256']==sha(source)
    elif a.mask[:2]!='11':
        trained=source.parent;last=read(trained/'LAST_CHECKPOINT.json');complete=read(trained/'TRAIN_COMPLETE.json')
    else:
        last=read(source.parent/'LAST_CHECKPOINT.json');complete=read(source.parent/'TRAIN_COMPLETE.json')
    assert last['completed_epoch']==100 and last['readback_exact'] and last['sha256']==sha(last['path'])
    assert complete.get('completed_epochs',complete.get('completed_epoch',100))==100 and complete['seed']==a.seed
    if phase=='adapter' or a.mask[:2]!='11':assert complete['plan_sha256']==sha(ROOT/'PLAN.json')
    expected=last['sha256']
    assert all(r['mask']==a.mask and r['seed']==a.seed and r['checkpoint_sha256']==expected and r['source_sha256']==sha(source) for r in model_audit['ranks'])
    raw=read(ann);predictions=read(pred);ids={x['id'] for x in raw['images']};cats={x['id'] for x in raw['categories']}
    assert len(predictions)==300*len(ids)
    assert all(x['image_id'] in ids and x['category_id'] in cats and math.isfinite(x['score']) and all(math.isfinite(v) for v in x['bbox']) for x in predictions)
    gt=COCO(str(ann));gt.dataset.setdefault('info',{})
    ev=COCOeval(gt,gt.loadRes(predictions),'bbox');ev.params.imgIds=sorted(ids);ev.params.catIds=sorted(cats)
    ev.params.maxDets=[1,10,100];ev.evaluate();ev.accumulate();ev.summarize()
    names=['AP','AP50','AP75','APs','APm','APl','AR1','AR10','AR100','ARs','ARm','ARl']
    metrics={k:float(v)*100 for k,v in zip(names,ev.stats)};assert all(math.isfinite(v) for v in metrics.values())
    result=dict(mask=a.mask,domain=a.domain,seed=a.seed,shot=10,metrics=metrics,
        metric='COCO bbox AP@[0.50:0.95] (%)',maxDets=[1,10,100],backbone='Swin-B',support_resampled=False,
        source_checkpoint=str(source),source_sha256=sha(source),checkpoint=last,
        source_epochs=100,adapter_epochs=100 if phase=='adapter' else 0,
        annotation_sha256=sha(ann),support_annotation_sha256=sha(audit['splits']['10_shot']['view']),
        predictions_sha256=sha(pred),inference_model_audit_sha256=sha(w/'INFERENCE_MODEL_AUDIT_PASS.json'),
        four_rank_inference_weights_verified=True,plan_sha256=sha(ROOT/'PLAN.json'),
        model_selection='fixed final epoch100 per applicable phase; no AP selection')
    write(w/'RESULT.json',result);write(w/'COMPLETE.json',dict(status='COMPLETE',result_sha256=sha(w/'RESULT.json')))

if __name__=='__main__':main()

