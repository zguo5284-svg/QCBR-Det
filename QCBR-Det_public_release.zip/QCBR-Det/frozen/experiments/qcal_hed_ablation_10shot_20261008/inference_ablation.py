"""Readback of all source/adapter tensors on every rank before inference."""
from pathlib import Path
import torch
from qcal_runtime import model_of,rank,barrier
from extension_model import is_adapter
from common_ablation import ROOT,read,write,sha

def restore_and_audit(runner,checkpoint,seed,mask,phase,epoch):
    model=model_of(runner);model.init_weights();runner.load_or_resume()
    current=model.state_dict();saved=torch.load(checkpoint,map_location='cpu')
    assert saved['meta']['seed']==seed==runner.seed and saved['meta']['epoch']==epoch
    # Original reused 11-family source files predate factorial-mask metadata.
    if 'ablation_mask' in saved:
        assert saved['ablation_mask'][:2]==mask[:2] and saved['ablation_phase']==phase
        assert saved['ablation_plan_sha256']==sha(ROOT/'PLAN.json')
    else:assert phase=='source' and mask[:2]=='11'
    if phase=='adapter':
        assert saved['ablation_mask']==mask and model._reference_loaded_exact
        adapters={n for n in current if is_adapter(n)}
        assert set(saved['state_dict'])==adapters
        assert all(torch.equal(current[n].cpu(),saved['state_dict'][n]) for n in adapters)
        source_hash=sha(model.reference_checkpoint);assert saved['reference_sha256']==source_hash
        full=torch.load(model.reference_checkpoint,map_location='cpu')
        assert full['meta']['seed']==seed and full['meta']['epoch']==epoch
        assert all(n in full['state_dict'] and torch.equal(current[n].cpu(),full['state_dict'][n]) for n in current if not is_adapter(n))
        del full
    else:
        assert set(saved['state_dict'])==set(current)
        assert all(torch.equal(current[n].cpu(),saved['state_dict'][n]) for n in current)
        source_hash=sha(checkpoint)
    evidence=dict(status='PASS',rank=rank(),seed=seed,mask=mask,phase=phase,
        source_epoch=epoch,checkpoint_sha256=sha(checkpoint),source_sha256=source_hash,
        all_inference_state_keys_verified=len(current))
    del saved,current
    gathered=[None]*4;torch.distributed.all_gather_object(gathered,evidence)
    assert {r['rank'] for r in gathered}==set(range(4))
    assert len({r['checkpoint_sha256'] for r in gathered})==len({r['source_sha256'] for r in gathered})==1
    if rank()==0:write(Path(runner.work_dir)/'INFERENCE_MODEL_AUDIT_PASS.json',dict(status='PASS',four_ranks_verified=True,ranks=gathered))
    barrier()

def record_predictions(runner,support):
    if rank()==0:
        w=Path(runner.work_dir);pred=w/('support_smoke.bbox.json' if support else 'predictions.bbox.json')
        write(w/'INFERENCE_COMPLETE.json',dict(status='PASS',support_smoke=support,
            predictions_sha256=sha(pred),model_audit_sha256=sha(w/'INFERENCE_MODEL_AUDIT_PASS.json')))
    barrier()
