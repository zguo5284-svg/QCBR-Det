"""Isolated factorial paths and immutable original-method provenance."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path('/root/autodl-tmp/vfmdetr_repro')
SOURCE = BASE/'experiments/qcal_hed_20261006'
EXTENSION = BASE/'experiments/qcal_hed_occa_sabr_20261007'
THREE = BASE/'experiments/qcal_hed_occa_sabr_three_seeds_20261007'
PY = BASE/'software/envs/qcal_hed/bin/python'
DOMAINS = ['ArTaxOr','clipart1k','DIOR','FISH','NEU-DET','UODD']
MASKS = ['0000','1000','0100','0010','0001','1100','1010','1001',
         '0110','0101','0011','1110','1101','1011','0111','1111']
CODE = ['PLAN.json','common_ablation.py','ablation_model.py','ablation_config.py',
        'ablation_runtime.py','train_ablation.py','inference_ablation.py',
        'evaluate_ablation.py','aggregate_ablation.py','preflight_ablation.py',
        'engineering_ablation.py','driver_ablation.py']

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(path)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()

def original_record(domain,seed):
    records=read(THREE/'RESULTS.json')['results']
    return next(r for r in records if (r['domain'],r['shot'],r['seed'])==(domain,10,seed))

def source_checkpoint(family,domain,seed,engineering=False):
    if engineering:
        return work_for(family+'00',domain,seed,'source',True)/'checkpoint_latest.pth'
    if family=='11':
        return Path(original_record(domain,seed)['adapter_checkpoint']['reference_checkpoint'])
    return work_for(family+'00',domain,seed,'source')/'checkpoint_latest.pth'

def work_for(mask,domain,seed,phase,engineering=False):
    assert mask in MASKS and domain in DOMAINS and seed in (0,1,2)
    part=('sources/'+mask[:2]) if phase=='source' else ('adapters/'+mask)
    prefix=ROOT/'engineering' if engineering else ROOT
    return prefix/part/f'{domain}_10shot_seed{seed}'

def result_work(mask,domain,seed):
    return ROOT/'evaluations'/mask/f'{domain}_10shot_seed{seed}'

def verify_frozen():
    for root in (SOURCE,EXTENSION,THREE,ROOT):
        manifest=read(root/'FROZEN_MANIFEST.json')
        assert all(sha(root/n)==v for n,v in manifest.items()),str(root)
    marker=read(THREE/'ALL_COMPLETE.json')
    assert sha(THREE/'RESULTS.json')==marker['results_sha256']==read(ROOT/'PLAN.json')['reference']['results_sha256']

