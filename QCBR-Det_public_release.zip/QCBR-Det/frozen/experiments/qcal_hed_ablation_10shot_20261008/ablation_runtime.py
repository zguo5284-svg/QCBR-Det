"""Audited full/adapter checkpoints including per-rank RNG and MixUp caches."""
import math
import random
import shutil
import time
from pathlib import Path
import numpy as np
import torch
from mmengine.hooks import Hook
from mmengine.registry import HOOKS
from qcal_runtime import (FixedTwoStageHook,FixedStageOptimWrapper,model_of,rank,
                          barrier,mixup_transforms,ControlledPause)
from extension_runtime import AdapterOptimWrapper
from extension_model import is_adapter
from common_ablation import read,write,sha

@HOOKS.register_module()
class AblationStageHook(FixedTwoStageHook):
    def __init__(self,root,**kwargs):
        super().__init__(**kwargs);self.root=Path(root)

    def before_train_epoch(self,runner):
        if rank()==0 and shutil.disk_usage(self.root).free<80*1024**3:
            write(self.root/'PAUSE_REQUESTED',dict(reason='disk free guard',at=time.time()))
        epoch=runner.epoch
        cosine=(1+math.cos(math.pi*epoch/max(self.total_epochs-1,1)))/2
        prefixes=('backbone.','language_model.','encoder.')
        for name,group in zip(self.group_names,runner.optim_wrapper.optimizer.param_groups):
            frozen=epoch<self.stage2_epoch and name.startswith(prefixes)
            initial=2e-5 if name.startswith(('backbone.','language_model.')) else 1e-4
            group['_stage_frozen']=frozen
            group['lr']=0 if frozen else 1e-6+(initial-1e-6)*cosine
        if rank()==0 and epoch in (0,self.stage2_epoch):
            write(Path(runner.work_dir)/f'STAGE_{1 if epoch<self.stage2_epoch else 2}.json',
                  dict(epoch=epoch,frozen_prefixes=list(prefixes) if epoch<self.stage2_epoch else [],
                       fixed_epoch_policy=True))

class AblationCheckpointHook(Hook):
    priority='LOWEST'
    phase='source'

    def __init__(self,root,seed,mask,engineering=False,total_epochs=100):
        self.root=Path(root);self.seed=seed;self.mask=mask
        self.engineering=engineering;self.total_epochs=total_epochs

    def after_load_checkpoint(self,runner,checkpoint):
        if getattr(runner,'_resume',False):
            assert checkpoint['validation_seed']==checkpoint['meta']['seed']==self.seed
            assert checkpoint['ablation_mask']==self.mask and checkpoint['ablation_phase']==self.phase
            assert checkpoint['ablation_plan_sha256']==sha(self.root/'PLAN.json')
            self.resume_states=checkpoint['ablation_rank_states']
            self.resume_reference_hash=checkpoint.get('reference_sha256')

    def before_train(self,runner):
        assert runner.seed==self.seed
        model=model_of(runner);head=model.bbox_head
        trainable=[n for n,p in model.named_parameters() if p.requires_grad]
        assert not any(n.startswith('bbox_head.quality_net.') for n in trainable) if self.mask[1]=='0' else hasattr(head,'quality_net')
        for bit,name in zip(self.mask[2:],('occa','sabr')):
            assert hasattr(head,name)==(self.phase=='adapter' and bit=='1')
        if self.phase=='adapter':
            assert model._reference_loaded_exact and trainable and all(is_adapter(n) for n in trainable)
            hashes=[sha(model.reference_checkpoint) if rank()==0 else None]
            torch.distributed.broadcast_object_list(hashes,src=0);self.reference_hash=hashes[0]
        if getattr(runner,'_resume',False):
            assert len(self.resume_states)==4
            info=self.resume_states[rank()];assert sha(info['path'])==info['sha256']
            state=torch.load(info['path'],map_location='cpu')
            for index,transform in mixup_transforms(runner):transform.results_cache=state['augmentation_caches'][index]
            random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
            torch.set_rng_state(state['torch_rng']);torch.cuda.set_rng_state(state['cuda_rng'])
            if self.phase=='adapter':
                assert self.reference_hash==self.resume_reference_hash
                head.identity_checked=True
            if rank()==0:write(Path(runner.work_dir)/'RESUME_PASS.json',dict(
                epoch=runner.epoch,iter=runner.iter,all_rank_rng_and_cached_mixup_restored=True))
        elif rank()==0:
            if self.phase=='source':
                raw=torch.load(runner.cfg.load_from,map_location='cpu');state=raw.get('state_dict',raw.get('model',raw))
                own=model.state_dict();target='dn_query_generator.label_embedding.weight'
                original=[n for n in own if not n.startswith('bbox_head.quality_net.') and n!=target]
                assert all(n in state and state[n].shape==own[n].shape and torch.equal(own[n].cpu(),state[n]) for n in original)
                if self.mask[1]=='1':assert not torch.count_nonzero(head.quality_net[-1].weight)
                write(Path(runner.work_dir)/'SOURCE_COVERAGE_PASS.json',dict(status='PASS',
                    covered_original_keys=len(original),expected_target_DN_reinitialization=target,
                    source_sha256=sha(runner.cfg.load_from),enabled_modules=self.mask))
                del raw,state,own
            else:
                write(Path(runner.work_dir)/'SOURCE_COVERAGE_PASS.json',dict(status='PASS',
                    source=model.reference_checkpoint,source_sha256=self.reference_hash,
                    trainable_names=trainable,all_existing_keys_loaded_exactly=True))
        if self.engineering and not getattr(runner,'_resume',False):
            if self.phase=='source':
                self.frozen={n:p.detach().cpu().clone() for n,p in model.named_parameters()
                             if n.startswith(('backbone.','language_model.','encoder.'))}
                self.outputs={n:p.detach().cpu().clone() for n,p in model.named_parameters()
                              if n.startswith('bbox_head.quality_net.3.')}
            else:
                self.outputs={n:p.detach().cpu().clone() for n,p in model.named_parameters() if is_adapter(n) and '.3.' in n}
        barrier()

    def before_train_epoch(self,runner):
        if rank()==0 and shutil.disk_usage(self.root).free<80*1024**3:
            write(self.root/'PAUSE_REQUESTED',dict(reason='disk free guard',at=time.time()))
        if self.phase=='adapter':
            model=model_of(runner)
            assert not model.training and not model.encoder.training and not model.backbone.training and not model.language_model.training
            if hasattr(model.bbox_head,'quality_net'):assert not model.bbox_head.quality_net.training
            cosine=(1+math.cos(math.pi*runner.epoch/max(self.total_epochs-1,1)))/2
            for group in runner.optim_wrapper.optimizer.param_groups:group['lr']=1e-6+(1e-4-1e-6)*cosine

    def after_train_iter(self,runner,batch_idx,data_batch=None,outputs=None):
        model=model_of(runner)
        if self.phase=='adapter':assert all(p.grad is None for n,p in model.named_parameters() if not is_adapter(n))
        if rank()==0:
            losses={k:float(v) for k,v in (outputs or {}).items()}
            assert all(math.isfinite(v) for v in losses.values())
            if self.phase=='source' and self.mask[1]=='0':assert 'loss_quality' not in losses
            if self.phase=='adapter':
                if self.mask[2]=='0':assert 'loss_occa' not in losses
                if self.mask[3]=='0':assert 'loss_sabr_l1' not in losses and 'loss_sabr_giou' not in losses
            write(Path(runner.work_dir)/'PROGRESS.json',dict(status='TRAINING',phase=self.phase,mask=self.mask,seed=self.seed,
                epoch=runner.epoch,completed_iter=runner.iter+1,epoch_batch=batch_idx+1,
                batches_per_epoch=len(runner.train_dataloader),time=time.time(),losses=losses))
            if getattr(model.bbox_head,'zero_prediction_identity_pass',False):
                write(Path(runner.work_dir)/'ZERO_IDENTITY_PASS.json',dict(status='PASS',bboxes_scores_labels_bitwise_equal=True))

    def after_train_epoch(self,runner):
        work=Path(runner.work_dir);completed=runner.epoch+1;model=model_of(runner)
        pause=(self.root/'PAUSE_REQUESTED').exists();final=completed==runner.max_epochs
        if self.engineering and hasattr(self,'frozen'):
            params=dict(model.named_parameters())
            if completed==1:
                assert all(torch.equal(params[n].cpu(),value) for n,value in self.frozen.items())
                write(work/'STAGE1_FREEZE_PASS.json',dict(status='PASS',all_frozen_parameters_unchanged=True))
            if final:
                changed={prefix:any(not torch.equal(params[n].cpu(),value) for n,value in self.frozen.items() if n.startswith(prefix))
                         for prefix in ('backbone.','language_model.','encoder.')}
                assert all(changed.values());write(work/'STAGE2_UNFREEZE_PASS.json',changed)
        if not (self.engineering or completed%10==0 or pause or final):return
        payload=dict(epoch=completed,iter=runner.iter,python_rng=random.getstate(),numpy_rng=np.random.get_state(),
            torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state(),
            augmentation_caches={i:t.results_cache for i,t in mixup_transforms(runner)})
        path=work/f'rank_state_epoch{completed:03d}_rank{rank()}.pth';temp=path.with_suffix('.tmp')
        torch.save(payload,temp);temp.replace(path)
        states=[None]*4;torch.distributed.all_gather_object(states,dict(path=str(path),sha256=sha(path)))
        self.rank_states=states
        if rank()==0:
            runner.save_checkpoint(str(work),'checkpoint_pending.pth',save_optimizer=True,save_param_scheduler=False,by_epoch=True)
            pending=work/'checkpoint_pending.pth';saved=torch.load(pending,map_location='cpu')
            own={n:t for n,t in model.state_dict().items() if self.phase=='source' or is_adapter(n)}
            assert saved['meta']['epoch']==completed and 'optimizer' in saved and set(saved['state_dict'])==set(own)
            assert all(torch.equal(t.cpu(),saved['state_dict'][n]) for n,t in own.items())
            del saved,own
            latest=work/'checkpoint_latest.pth'
            if latest.exists():latest.replace(work/'checkpoint_previous.pth')
            pending.replace(latest)
            record=dict(path=str(latest),sha256=sha(latest),completed_epoch=completed,completed_iter=runner.iter,
                        readback_exact=True,head_only=self.phase=='adapter',rank_states=states,seed=self.seed,mask=self.mask)
            if self.phase=='adapter':
                record.update(reference_checkpoint=model.reference_checkpoint,reference_sha256=self.reference_hash)
                if final or self.engineering:
                    original=torch.load(model.reference_checkpoint,map_location='cpu')['state_dict'];current=model.state_dict()
                    assert all(torch.equal(current[n].cpu(),original[n]) for n in current if not is_adapter(n))
                    write(work/'FROZEN_BASE_PASS.json',dict(status='PASS',reference_sha256=self.reference_hash))
            write(work/'LAST_CHECKPOINT.json',record)
            if self.engineering and hasattr(self,'outputs'):
                params=dict(model.named_parameters())
                prefixes=(['bbox_head.quality_net.'] if self.phase=='source' and self.mask[1]=='1' else
                    [f'bbox_head.{name}.' for bit,name in zip(self.mask[2:],('occa','sabr')) if bit=='1'] if self.phase=='adapter' else [])
                changed={prefix:any(not torch.equal(params[n].cpu(),value) for n,value in self.outputs.items() if n.startswith(prefix)) for prefix in prefixes}
                assert all(changed.values());write(work/'ENABLED_UPDATE_PASS.json',dict(status='PASS',updated=changed))
            if pause:write(work/'PAUSED.json',dict(completed_epoch=completed,at=time.time()))
        barrier()
        if pause:raise ControlledPause('User/guard pause; epoch-boundary all-rank state saved')

    def before_save_checkpoint(self,runner,checkpoint):
        if self.phase=='adapter':
            checkpoint['state_dict']={n:t for n,t in checkpoint['state_dict'].items() if is_adapter(n)}
            checkpoint['reference_sha256']=self.reference_hash
        checkpoint.update(ablation_rank_states=self.rank_states,ablation_plan_sha256=sha(self.root/'PLAN.json'),
            validation_seed=self.seed,ablation_mask=self.mask,ablation_phase=self.phase)

@HOOKS.register_module()
class AblationSourceHook(AblationCheckpointHook):pass

@HOOKS.register_module()
class AblationAdapterHook(AblationCheckpointHook):phase='adapter'
