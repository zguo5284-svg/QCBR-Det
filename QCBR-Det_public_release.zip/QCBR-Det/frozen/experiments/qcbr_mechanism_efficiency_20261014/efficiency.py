"""Same-instance sequential inference benchmark. No optimization or checkpoint writes."""
import argparse
import os
import statistics
import subprocess
import time
from pathlib import Path
from validation_common import ROOT, build, empty_gt_input, guard, read, sha, state_digest, verify, write


def visible_processes():
    output = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
                                      '--format=csv,noheader,nounits'], text=True)
    return {int(s.strip()) for s in output.splitlines() if s.strip().isdigit()}


def run(variant):
    import numpy as np
    import torch
    verify()
    guard()
    assert visible_processes() <= {os.getpid()}, 'Other visible GPU workload; timing not admissible'
    work = ROOT / 'efficiency' / variant
    assert not (work / 'COMPLETE.json').exists(), 'Do not overwrite a completed benchmark'
    runner, reference, audit = build(variant, 'DIOR', 10, 0, work)
    model = runner.model
    before = state_digest(model)
    batches, image_ids = [], []
    for batch in runner.test_dataloader:
        empty_gt_input(batch)
        batches.append(batch)
        image_ids.append(str(batch['data_samples'][0].img_id))
        if len(batches) == 32:
            break
    assert len(batches) == 32 and len(set(image_ids)) == 32
    declared = ROOT / 'EFFICIENCY_IMAGE_IDS.json'
    if declared.exists():
        assert image_ids == read(declared)
    else:
        write(declared, image_ids)
    parameter_counts = dict(total=sum(p.numel() for p in model.parameters()))
    for name, prefix in [('QCAL', 'bbox_head.quality_net.'), ('OCCA', 'bbox_head.occa.'),
                         ('SABR', 'bbox_head.sabr.')]:
        parameter_counts[name] = sum(p.numel() for n, p in model.named_parameters() if n.startswith(prefix))
    environment = dict(torch=torch.__version__, cuda=torch.version.cuda,
        cudnn=torch.backends.cudnn.version(), logical_gpu=torch.cuda.get_device_name(0),
        device_properties=str(torch.cuda.get_device_properties(0)),
        nvidia_smi=subprocess.check_output(['nvidia-smi'], text=True),
        CPU=os.cpu_count(), TF32_matmul=torch.backends.cuda.matmul.allow_tf32,
        TF32_cudnn=torch.backends.cudnn.allow_tf32, cudnn_benchmark=torch.backends.cudnn.benchmark,
        backbone_autocast='Inherited unchanged from published/configured model; no new AMP wrapper')
    rounds = []
    with torch.no_grad():
        for repetition in range(3):
            guard()
            assert visible_processes() <= {os.getpid()}, 'Concurrent GPU work invalidates efficiency measurement'
            for i in range(20):
                model.test_step(batches[i % 32])
            torch.cuda.synchronize()
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            baseline = torch.cuda.memory_allocated()
            latency = []
            for i in range(100):
                if i % 10 == 0:
                    guard()
                torch.cuda.synchronize()
                started = time.perf_counter()
                model.test_step(batches[i % 32])
                torch.cuda.synchronize()
                latency.append(time.perf_counter() - started)
            assert visible_processes() <= {os.getpid()}, 'Concurrent GPU workload observed; do not report contaminated round'
            rounds.append(dict(round=repetition, seconds=latency,
                aggregate_FPS=len(latency)/sum(latency), median_ms=1000*float(np.median(latency)),
                p90_ms=1000*float(np.percentile(latency, 90)),
                model_allocated_MiB=baseline/1024**2,
                peak_allocated_MiB=torch.cuda.max_memory_allocated()/1024**2,
                peak_reserved_MiB=torch.cuda.max_memory_reserved()/1024**2))
            write(work / f'ROUND_{repetition}.json', rounds[-1])
    assert before == state_digest(model), 'State changed during inference benchmark'
    values = [r['aggregate_FPS'] for r in rounds]
    result = dict(variant=variant, domain='DIOR', shot=10, training_seed=0,
        timing_repeat_count=3, batch_size=1, image_ids=image_ids, parameters=parameter_counts,
        FPS_mean=statistics.mean(values), FPS_sd_ddof1=statistics.stdev(values),
        peak_allocated_MiB=max(r['peak_allocated_MiB'] for r in rounds), rounds=rounds,
        environment=environment, FLOPs=None, FLOPs_reason='No unsupported custom-operator estimate',
        no_training=True, unchanged_model_state=True, plan_sha256=sha(ROOT / 'PLAN.json'),
        excludes='Image disk decoding, initialization and checkpoint loading',
        includes='CPU-to-GPU preprocessing transfer, text and vision encoding, decoding/refinement/postprocessing')
    write(work / 'RESULT.json', result)
    write(work / 'COMPLETE.json', dict(result_sha256=sha(work / 'RESULT.json'), at=time.time()))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--variant', choices=['serial', 'hed', 'full'], required=True)
    run(p.parse_args().variant)
