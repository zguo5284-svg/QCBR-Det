"""Read frozen artifacts; write only isolated validation evidence."""
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path('/root/autodl-tmp/vfmdetr_repro')
EXPS = BASE / 'experiments'
SOURCE = EXPS / 'qcal_hed_20261006'
EXT = EXPS / 'qcal_hed_occa_sabr_20261007'
THREE = EXPS / 'qcal_hed_occa_sabr_three_seeds_20261007'
ABL = EXPS / 'qcal_hed_ablation_10shot_20261008'
CONTROLS = EXPS / 'qcbr_baseline_budget_20261013'
STRATEGY = EXPS / 'qcbr_strategy_ablation_20261014'
PY = BASE / 'software/envs/qcal_hed/bin/python'
FILES = ['PLAN.json', 'validation_common.py', 'mechanism.py', 'efficiency.py', 'driver.py']


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))
    temporary.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def guard():
    assert not (ROOT / 'PAUSE_REQUESTED').exists(), 'USER_PAUSE_VALIDATION'
    assert not (STRATEGY / 'PAUSE_REQUESTED').exists(), 'USER_PAUSE_PREREQUISITE'
    assert shutil.disk_usage(ROOT).free > 80 * 1024**3, 'LOW_SPACE_SAFE_STOP'


def verify():
    for root in [SOURCE, EXT, THREE, ABL, CONTROLS, STRATEGY, ROOT]:
        for name, expected in read(root / 'FROZEN_MANIFEST.json').items():
            assert sha(root / name) == expected, ('FROZEN_FILE_CHANGED', str(root / name))
    for root in [THREE, ABL, CONTROLS]:
        assert sha(root / 'RESULTS.json') == read(root / 'ALL_COMPLETE.json')['results_sha256']


def setup():
    os.environ.update(OMP_NUM_THREADS='4', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
                      TOKENIZERS_PARALLELISM='false', CUBLAS_WORKSPACE_CONFIG=':4096:8')
    sys.path[:0] = list(map(str, [ROOT, EXT, SOURCE, SOURCE / 'FT-FSOD', ABL]))


def main_record(domain, shot, seed):
    return next(r for r in read(THREE / 'RESULTS.json')['results']
                if (r['domain'], r['shot'], r['seed']) == (domain, shot, seed))


def build(variant, domain, shot, seed, work, support=False):
    """Use upstream configs/model classes, exactly restore every tensor."""
    setup()
    import torch
    from mmengine.runner import Runner
    from mmengine.utils import import_modules_from_strings
    from mmdet.utils import register_all_modules
    from extension_model import is_adapter
    register_all_modules(init_default_scope=True)
    if variant == 'full':
        from extension_config import make_config
        reference = main_record(domain, shot, seed)
        cp = reference['adapter_checkpoint']
        cfg = make_config(domain, shot, work, False)
        cfg.model.reference_checkpoint = cp['reference_checkpoint']
    else:
        assert shot == 10
        from ablation_config import make_config
        mask = {'serial': '0000', 'hed': '1000'}[variant]
        reference = next(r for r in read(ABL / 'RESULTS.json')['results']
                         if (r['mask'], r['domain'], r['seed']) == (mask, domain, seed))
        cp = reference['checkpoint']
        cfg = make_config(mask, domain, seed, 'source', work, False)
    assert sha(cp['path']) == cp['sha256']
    cfg.launcher = 'none'
    cfg.load_from = None
    cfg.resume = False
    cfg.train_dataloader = cfg.train_cfg = cfg.optim_wrapper = None
    cfg.param_scheduler = None
    cfg.custom_hooks = []
    cfg.randomness.seed = seed
    audit = read(SOURCE / 'DATA_AUDIT.json')['domains'][domain]
    if support:
        cfg.test_dataloader.dataset.ann_file = audit['splits'][f'{shot}_shot']['view']
        cfg.test_dataloader.dataset.data_prefix.img = str(BASE / 'datasets' / domain / 'train')
    import_modules_from_strings(**cfg.custom_imports)
    runner = Runner.from_cfg(cfg)
    model = runner.model
    model.init_weights()
    saved = torch.load(cp['path'], map_location='cpu')['state_dict']
    if variant == 'full':
        expected_adapters = {n for n in model.state_dict() if is_adapter(n)}
        assert set(saved) == expected_adapters
        source = torch.load(cp['reference_checkpoint'], map_location='cpu')['state_dict']
        assert sha(cp['reference_checkpoint']) == cp['reference_sha256']
        expected = dict(source, **saved)
    else:
        expected = saved
    missing, unexpected = model.load_state_dict(saved, strict=False)
    assert not unexpected
    if variant != 'full':
        assert not missing
    current = model.state_dict()
    assert set(expected) == set(current)
    assert all(torch.equal(current[n].cpu(), expected[n]) for n in current)
    model.eval()
    write(Path(work) / 'MODEL_AUDIT.json', dict(status='PASS', variant=variant,
          domain=domain, shot=shot, seed=seed, checkpoint=cp, state_keys=len(current),
          exact_all_state_tensors=True, plan_sha256=sha(ROOT / 'PLAN.json')))
    del current, saved, expected
    if variant == 'full':
        del source
    return runner, reference, audit


def state_digest(model):
    h = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        h.update(name.encode())
        t = tensor.detach().cpu().contiguous()
        h.update(str((tuple(t.shape), t.dtype)).encode())
        h.update(t.view(-1).view(__import__('torch').uint8).numpy().tobytes())
    return h.hexdigest()


def empty_gt_input(batch):
    # Evaluation annotations are loaded separately only AFTER the forward.
    assert all(len(s.gt_instances) == 0 for s in batch['data_samples'])


def predictions_equal(left, right):
    import torch
    assert len(left) == len(right)
    return all(torch.equal(getattr(a.pred_instances, name), getattr(b.pred_instances, name))
               for a, b in zip(left, right) for name in ('bboxes', 'scores', 'labels'))
