"""Offline tables from frozen cloud evidence; never changes the method or source files."""
import hashlib
import itertools
import json
import statistics as st
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
OUT = ROOT / 'table_export_20261015'
OUT.mkdir(exist_ok=True)


def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def stats(values):
    assert len(values) == 3 and all(v is not None for v in values)
    return dict(values=values, mean=st.mean(values), sd=st.stdev(values))


strategy_root = REPRO / 'qcbr_strategy_ablation_20261014' / 'evidence'
mechanism_root = ROOT / 'evidence'
strategy = load(strategy_root / 'RESULTS.json')
mechanism = load(mechanism_root / 'MECHANISM_SUMMARY.json')
efficiency = load(mechanism_root / 'EFFICIENCY_RESULTS.json')
main_path = REPRO / 'qcbr_baseline_budget_20261013/table_export_20261014/MAIN_RESULTS.json'
controls_path = REPRO / 'qcbr_baseline_budget_20261013/table_export_20261014/CONTROLS_RESULTS.json'
ablation_path = REPRO / 'qcal_hed_ablation_10shot_20261008/table_export_20261013/RESULTS.json'
main, controls, ablation = map(load, [main_path, controls_path, ablation_path])
assert strategy['completed'] == 60 and strategy['new_completed'] == 48
assert len(strategy['results']) == 60 and len(mechanism['records']) == 12 and len(efficiency['records']) == 3
assert not strategy['missing_values_estimated'] and not mechanism['standard_COCO_AP']
assert digest(strategy_root / 'RESULTS.json') == load(strategy_root / 'ALL_COMPLETE.json')['results_sha256']
complete = load(mechanism_root / 'ALL_COMPLETE.json')
assert digest(mechanism_root / 'MECHANISM_SUMMARY.json') == complete['mechanism_sha256']
assert digest(mechanism_root / 'EFFICIENCY_RESULTS.json') == complete['efficiency_sha256']
assert complete['fixed_paper_method_unchanged']
plan = load(strategy_root / 'PLAN.json')
assert digest(main_path) == plan['references']['main_results_sha256']
assert digest(controls_path) == plan['references']['controls_results_sha256']
assert digest(ablation_path) == plan['references']['ablation_results_sha256']

variants = ['full', 'no_gate', 'nonzero_init', 'no_reg', 'joint_stage2']
domains = ['NEU-DET', 'DIOR']
seeds = [0, 1, 2]
shots = [1, 10]
sm = {(r['variant'], r['domain'], r['shot'], r['seed']): r for r in strategy['results']}
assert set(sm) == set(itertools.product(variants, domains, shots, seeds))
mm = {(r['domain'], r['shot'], r['seed']): r for r in main['results']}
for d, k, s in itertools.product(domains, shots, seeds):
    a, b = sm['full', d, k, s], mm[d, k, s]
    assert a['metrics'] == b['metrics']
for r in strategy['results']:
    ref = sm['full', r['domain'], r['shot'], r['seed']]
    assert r['annotation_sha256'] == ref['annotation_sha256']
    assert r['metrics']['AP'] >= 0

strategy_rows = []
for v, k in itertools.product(variants, shots):
    row = dict(variant=v, shot=k, domains={})
    for d in domains:
        vals = [sm[v, d, k, s]['metrics']['AP'] for s in seeds]
        paired = [sm[v, d, k, s]['metrics']['AP'] - sm['full', d, k, s]['metrics']['AP'] for s in seeds]
        row['domains'][d] = dict(AP=stats(vals), difference_from_full=stats(paired))
    vals = [st.mean(sm[v, d, k, s]['metrics']['AP'] for d in domains) for s in seeds]
    paired = [st.mean(sm[v, d, k, s]['metrics']['AP'] - sm['full', d, k, s]['metrics']['AP'] for d in domains) for s in seeds]
    row['two_domain_AP'] = stats(vals)
    row['two_domain_difference_from_full'] = stats(paired)
    cloud = next(r for r in strategy['rows'] if (r['variant'], r['shot']) == (v, k))
    assert abs(cloud['AP']['TwoDomainAverage'] - row['two_domain_AP']['mean']) < 1e-10
    assert abs(cloud['std_ddof1']['TwoDomainAverage'] - row['two_domain_AP']['sd']) < 1e-10
    strategy_rows.append(row)

mech_map = {(r['domain'], r['shot'], r['seed']): r for r in mechanism['records']}
assert set(mech_map) == set(itertools.product(domains, shots, seeds))
mechanism_rows = []
for d, k in itertools.product(domains, shots):
    recs = [mech_map[d, k, s] for s in seeds]
    metrics = {}
    for key in ['quality_spearman_best_geometric_iou', 'quality_spearman_sameclass_iou',
                'quality_spearman_positive_cohort', 'final_quality_spearman_same_fixed_target']:
        metrics[key] = stats([r[key] for r in recs])
    for label, key in [('raw_P100_percent', 'raw_P100_proxy'), ('quality_P100_percent', 'quality_P100_proxy')]:
        metrics[label] = stats([100 * r[key] for r in recs])
    metrics['P100_delta_pp'] = stats([100 * (r['quality_P100_proxy'] - r['raw_P100_proxy']) for r in recs])
    metrics['context_acc_before_percent'] = stats([100 * r['context_correct_before'] / r['context_matched_n'] for r in recs])
    metrics['context_acc_after_percent'] = stats([100 * r['context_correct_after'] / r['context_matched_n'] for r in recs])
    metrics['context_acc_delta_pp'] = stats([100 * (r['context_correct_after'] - r['context_correct_before']) / r['context_matched_n'] for r in recs])
    for size in ['all', 'small', 'medium', 'large']:
        for name, key in [('before_percent', 'mean_iou_before'), ('after_percent', 'mean_iou_after'), ('delta_pp', 'mean_delta')]:
            metrics[f'boundary_{size}_{name}'] = stats([100 * r['boundary'][size][key] for r in recs])
    mechanism_rows.append(dict(domain=d, shot=k, metrics=metrics))

efficiency_rows = []
for r in efficiency['records']:
    assert len(r['rounds']) == 3 and r['unchanged_model_state'] and len(set(r['image_ids'])) == 32
    assert all(len(t['seconds']) == 100 for t in r['rounds'])
    fps = stats([100 / sum(t['seconds']) for t in r['rounds']])
    assert abs(fps['mean'] - r['FPS_mean']) < 1e-10
    latencies = [x for t in r['rounds'] for x in t['seconds']]
    params = r['parameters']
    added = sum(params[n] for n in ['QCAL', 'OCCA', 'SABR'])
    efficiency_rows.append(dict(variant=r['variant'], parameters=params, added_parameters=added,
        FPS=fps, mean_latency_ms=1000 * st.mean(latencies),
        round_median_ms=stats([t['median_ms'] for t in r['rounds']]),
        round_p90_ms=stats([t['p90_ms'] for t in r['rounds']]),
        peak_allocated_MiB=r['peak_allocated_MiB']))
hed, full = [next(r for r in efficiency_rows if r['variant'] == v) for v in ['hed', 'full']]
efficiency_effect = dict(added_parameters=full['parameters']['total'] - hed['parameters']['total'],
    parameter_increase_percent=100 * (full['parameters']['total'] / hed['parameters']['total'] - 1),
    mean_latency_increase_percent=100 * (full['mean_latency_ms'] / hed['mean_latency_ms'] - 1),
    throughput_change_percent=100 * (full['FPS']['mean'] / hed['FPS']['mean'] - 1),
    peak_allocated_increase_MiB=full['peak_allocated_MiB'] - hed['peak_allocated_MiB'])

paper_domains = ['ArTaxOr', 'clipart1k', 'DIOR', 'FISH', 'NEU-DET', 'UODD']
cm = {(r['variant'], r['domain'], r['shot'], r['seed']): r for r in controls['results']}
prior_controls = []
for v, k in [('hed100', 1), ('hed100', 5), ('hed100', 10), ('hed200', 10)]:
    vals = [st.mean(mm[d, k, s]['metrics']['AP'] - cm[v, d, k, s]['metrics']['AP'] for d in paper_domains) for s in seeds]
    wins = sum(st.mean(mm[d, k, s]['metrics']['AP'] - cm[v, d, k, s]['metrics']['AP'] for s in seeds) > 0 for d in paper_domains)
    prior_controls.append(dict(reference=v, shot=k, six_domain_paired_difference=stats(vals), positive_domain_means=wins))
am = {(r['mask'], r['domain'], r['seed']): r for r in ablation['results']}
assert len(am) == 288
prior_module = []
for mask in ['0000', '1000', '1100', '1101', '1110', '1111']:
    vals = [st.mean(am[mask, d, s]['metrics']['AP'] for d in paper_domains) for s in seeds]
    delta = [st.mean(am['1111', d, s]['metrics']['AP'] - am[mask, d, s]['metrics']['AP'] for d in paper_domains) for s in seeds]
    prior_module.append(dict(mask=mask, AP=stats(vals), full_minus_mask=stats(delta)))

audit = dict(strategy_records=60, new_strategy_records=48, mechanism_records=12, efficiency_records=3,
    fixed_method_unchanged=True, no_missing_values_estimated=True,
    source_files=[dict(path=str(p), sha256=digest(p)) for p in [strategy_root/'RESULTS.json',
        mechanism_root/'MECHANISM_SUMMARY.json', mechanism_root/'EFFICIENCY_RESULTS.json', main_path, controls_path, ablation_path]])
summary = dict(strategy_rows=strategy_rows, mechanism_rows=mechanism_rows, efficiency_rows=efficiency_rows,
    efficiency_effect=efficiency_effect, prior_controls=prior_controls, prior_module=prior_module, audit=audit)
(OUT / 'ANALYSIS.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
for name in ['strategy_rows', 'mechanism_rows', 'efficiency_rows', 'efficiency_effect', 'prior_controls', 'prior_module']:
    print(name, json.dumps(summary[name], ensure_ascii=False))
print('AUDIT', json.dumps(audit, ensure_ascii=False))
