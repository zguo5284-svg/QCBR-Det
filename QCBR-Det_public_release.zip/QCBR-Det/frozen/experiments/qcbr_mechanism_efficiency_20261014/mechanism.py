"""Observe unchanged inference. GT is used only in offline descriptive diagnostics."""
import argparse
import collections
import json
import math
import time
from pathlib import Path
import numpy as np
from validation_common import ROOT, build, empty_gt_input, guard, read, sha, state_digest, verify, write


class Observer:
    def __init__(self, head):
        self.head = head
        self.original = {n: getattr(head, n) for n in ('_base', '_extend', 'quality_logits')}
        self.data = {}

    def install(self):
        def base(*args, **kwargs):
            result = self.original['_base'](*args, **kwargs)
            self.data['base'] = result
            return result
        def extend(*args, **kwargs):
            result = self.original['_extend'](*args, **kwargs)
            self.data['extended'] = result
            return result
        def quality(*args, **kwargs):
            result = self.original['quality_logits'](*args, **kwargs)
            self.data.setdefault('qualities', []).append(result.detach())
            return result
        self.head._base, self.head._extend, self.head.quality_logits = base, extend, quality

    def remove(self):
        for name, original in self.original.items():
            setattr(self.head, name, original)

    def clear(self):
        self.data = {}


def overlaps(boxes, targets):
    boxes, targets = np.asarray(boxes), np.asarray(targets)
    if not len(targets):
        return np.zeros((len(boxes), 0), dtype=np.float64)
    low = np.maximum(boxes[:, None, :2], targets[None, :, :2])
    high = np.minimum(boxes[:, None, 2:], targets[None, :, 2:])
    inter = np.prod(np.maximum(high - low, 0), axis=-1)
    a = np.prod(np.maximum(boxes[:, 2:] - boxes[:, :2], 0), axis=-1)
    b = np.prod(np.maximum(targets[:, 2:] - targets[:, :2], 0), axis=-1)
    return inter / np.maximum(a[:, None] + b[None] - inter, 1e-12)


def greedy_precision(confidence, labels, ious, gt_labels, k=100):
    """One label per unique query; fixed raw300 cohort, not COCO AP."""
    order = np.argsort(-confidence, kind='stable')[:k]
    used = set()
    correct = 0
    for index in order:
        allowed = [j for j in range(len(gt_labels))
                   if j not in used and gt_labels[j] == labels[index] and ious[index, j] >= .5]
        if allowed:
            target = max(allowed, key=lambda j: ious[index, j])
            used.add(target)
            correct += 1
    return dict(tp=correct, predictions=len(order), annotated_objects=len(gt_labels))


def pixels(boxes, meta):
    b = np.asarray(boxes, dtype=np.float64)
    xyxy = np.concatenate([b[:, :2] - b[:, 2:] / 2, b[:, :2] + b[:, 2:] / 2], -1)
    h, w = meta['img_shape'][:2]
    xyxy *= np.array([w, h, w, h])
    xyxy[:, [0, 2]] = np.clip(xyxy[:, [0, 2]], 0, w)
    xyxy[:, [1, 3]] = np.clip(xyxy[:, [1, 3]], 0, h)
    sf = np.asarray(meta['scale_factor']).reshape(-1)
    assert len(sf) in (2, 4)
    return xyxy / (np.tile(sf, 2) if len(sf) == 2 else sf)


def annotation_index(path, classes):
    data = read(path)
    names = {c['id']: c['name'] for c in data['categories']}
    labels = {cat: classes.index(name) for cat, name in names.items() if name in classes}
    groups = collections.defaultdict(list)
    for ann in data['annotations']:
        if ann['category_id'] in labels:
            groups[str(ann['image_id'])].append(dict(ann, label=labels[ann['category_id']]))
    return groups


FIELDS = ['q0', 'q_final', 'base_geometric_iou', 'refined_iou_same_gt',
          'base_sameclass_iou', 'raw_confidence', 'qcal_confidence_same_query',
          'base_class', 'context_class', 'matched_gt_class', 'matched_gt_area',
          'context_relative_feature_norm', 'context_residual_at_base_class', 'box_relative_l1']


def inspect_image(observer, sample, annotations, ordinal):
    import torch
    base = observer.data['base']
    refined, residual, correction = observer.data['extended']
    assert len(observer.data['qualities']) == 2
    def cpu(value):
        return value.detach().cpu().numpy()[0]
    scores, boxes = cpu(base['scores']), cpu(base['boxes'])
    qb, qf = [cpu(v.sigmoid()) for v in observer.data['qualities']]
    res, corr = cpu(residual), cpu(correction)
    new_boxes = cpu(refined)
    labels = scores.argmax(-1)
    confidence = scores.max(-1)
    selected = np.argsort(-confidence, kind='stable')[:300]
    xy, refined_xy = pixels(boxes[selected], sample.metainfo), pixels(new_boxes[selected], sample.metainfo)
    valid, ignored = [], []
    for a in annotations:
        x, y, w, h = a['bbox']
        if w <= 0 or h <= 0:
            continue
        item = (np.array([x, y, x + w, y + h]), a['label'], a.get('area', w*h))
        (ignored if a.get('ignore', 0) or a.get('iscrowd', 0) else valid).append(item)
    if ignored:
        keep = overlaps(xy, np.stack([a[0] for a in ignored])).max(1) < .5
        selected, xy, refined_xy = selected[keep], xy[keep], refined_xy[keep]
    gt_boxes = np.stack([a[0] for a in valid]) if valid else np.empty((0, 4))
    gt_labels = np.array([a[1] for a in valid], dtype=np.int64)
    gt_areas = np.array([a[2] for a in valid])
    ious, after = overlaps(xy, gt_boxes), overlaps(refined_xy, gt_boxes)
    if valid:
        target = ious.argmax(1)
        before_iou = ious[np.arange(len(selected)), target]
        after_iou = after[np.arange(len(selected)), target]
        target_labels, areas = gt_labels[target], gt_areas[target]
        sameclass = np.where(gt_labels[None] == labels[selected, None], ious, 0).max(1)
    else:
        before_iou = after_iou = sameclass = np.zeros(len(selected))
        target_labels, areas = np.full(len(selected), -1), np.full(len(selected), -1)
    context_scores = scores[selected] * np.exp(res[selected])
    context_labels = context_scores.argmax(-1)
    dim = observer.head.embed_dims
    features = cpu(base['occa_features'])[selected]
    feature_norm = np.linalg.norm(features[:, 2*dim:3*dim], axis=1) / np.maximum(
        np.linalg.norm(features[:, dim:2*dim], axis=1), 1e-12)
    quality_confidence = confidence[selected] * (1 + observer.head.quality_strength * (2*qb[selected]-1))
    rows = np.column_stack([qb[selected], qf[selected], before_iou, after_iou, sameclass,
        confidence[selected], quality_confidence, labels[selected], context_labels, target_labels,
        areas, feature_norm, res[selected, labels[selected]], np.abs(corr[selected]).sum(-1)]).astype(np.float32)
    ranks = dict(raw=greedy_precision(confidence[selected], labels[selected], ious, gt_labels),
                 quality=greedy_precision(quality_confidence, labels[selected], ious, gt_labels))
    record = dict(image_id=str(sample.img_id), ordinal=ordinal, candidate_count=len(rows),
        valid_annotated_objects=len(valid), ignored_annotated_objects=len(ignored), ranking=ranks)
    if ordinal < 4:
        count = min(10, len(selected))
        record['example'] = dict(img_path=sample.img_path, raw_boxes=xy[:count].tolist(),
            refined_boxes=refined_xy[:count].tolist(), raw_labels=labels[selected[:count]].tolist(),
            context_labels=context_labels[:count].tolist(), raw_scores=confidence[selected[:count]].tolist(),
            refined_scores=(context_scores.max(-1)[:count]*(1+observer.head.quality_strength*(2*qf[selected[:count]]-1))).tolist(),
            GT_boxes=gt_boxes.tolist(), GT_labels=gt_labels.tolist(),
            query_selection='Same first10 raw-confidence queries; not a COCO result visualization')
    return rows, record


def finite_summary(rows):
    from scipy.stats import spearmanr
    assert rows.shape[1] == len(FIELDS) and np.isfinite(rows).all()
    def corr(x, y):
        if len(x) < 2 or np.ptp(x) == 0 or np.ptp(y) == 0:
            return None
        value = float(spearmanr(x, y)[0])
        return value if math.isfinite(value) else None
    matched = rows[:, 2] >= .5
    before_correct = rows[:, 7] == rows[:, 9]
    after_correct = rows[:, 8] == rows[:, 9]
    boundary = rows[:, 2] >= .1
    groups = {}
    for name, size in [('all', np.ones(len(rows), bool)), ('small', rows[:, 10] < 32**2),
                       ('medium', (rows[:, 10] >= 32**2) & (rows[:, 10] < 96**2)),
                       ('large', rows[:, 10] >= 96**2)]:
        chosen = boundary & size
        delta = rows[chosen, 3] - rows[chosen, 2]
        groups[name] = dict(n=int(chosen.sum()), mean_iou_before=float(rows[chosen, 2].mean()) if len(delta) else None,
            mean_iou_after=float(rows[chosen, 3].mean()) if len(delta) else None,
            mean_delta=float(delta.mean()) if len(delta) else None,
            improved=int((delta > 1e-6).sum()), worsened=int((delta < -1e-6).sum()))
    positive = rows[:, 2] >= .1
    bins = []
    for index in range(10):
        selected = (rows[:, 0] >= index/10) & (rows[:, 0] < (index+1)/10)
        bins.append(dict(low=index/10, high=(index+1)/10, n=int(selected.sum()),
            mean_quality=float(rows[selected, 0].mean()) if selected.any() else None,
            mean_geometric_iou=float(rows[selected, 2].mean()) if selected.any() else None))
    return dict(candidates=len(rows), quality_bins_descriptive= bins,
        quality_positive_cohort_n=int(positive.sum()),
        quality_spearman_positive_cohort=corr(rows[positive, 0], rows[positive, 2]),
        final_quality_spearman_same_fixed_target=corr(rows[positive, 1], rows[positive, 3]),
        quality_spearman_best_geometric_iou=corr(rows[:, 0], rows[:, 2]),
        quality_spearman_sameclass_iou=corr(rows[:, 0], rows[:, 4]),
        context_matched_n=int(matched.sum()), context_correct_before=int((matched & before_correct).sum()),
        context_correct_after=int((matched & after_correct).sum()),
        context_wrong_to_correct=int((matched & ~before_correct & after_correct).sum()),
        context_correct_to_wrong=int((matched & before_correct & ~after_correct).sum()),
        boundary=groups)


def engineering():
    import torch
    work = ROOT / 'engineering'
    runner, reference, audit = build('full', 'NEU-DET', 1, 0, work, support=True)
    batch = next(iter(runner.test_dataloader))
    empty_gt_input(batch)
    model = runner.model
    before = state_digest(model)
    with torch.no_grad():
        original = [{k: getattr(s.pred_instances, k).detach().clone() for k in ('bboxes', 'scores', 'labels')}
                    for s in model.test_step(batch)]
        observer = Observer(model.bbox_head)
        observer.install()
        observed = model.test_step(batch)
    assert all(torch.equal(original[i][k], getattr(s.pred_instances, k))
               for i, s in enumerate(observed) for k in original[i])
    assert len(observer.data['qualities']) == 2
    index = annotation_index(audit['splits']['1_shot']['view'], audit['classes'])
    rows, record = inspect_image(observer, batch['data_samples'][0], index[str(batch['data_samples'][0].img_id)], 0)
    assert np.isfinite(rows).all()
    finite_summary(rows)
    observer.remove()
    assert before == state_digest(model)
    write(ROOT / 'ENGINEERING_PASS.json', dict(status='PASS', support_only=True,
        observers_prediction_bitwise_identity=True, unchanged_model_state=True,
        no_gt_input=True, diagnostics_finite=True, plan_sha256=sha(ROOT / 'PLAN.json')))


def run(domain, shot, seed):
    import torch
    verify()
    guard()
    work = ROOT / 'mechanism' / f'{domain}_{shot}shot_seed{seed}'
    assert not (work / 'COMPLETE.json').exists(), 'Do not overwrite completed diagnostics'
    runner, reference, audit = build('full', domain, shot, seed, work)
    model = runner.model
    before = state_digest(model)
    observer = Observer(model.bbox_head)
    observer.install()
    index = annotation_index(audit['splits']['test']['view'], audit['classes'])
    traces, records, identifiers = [], [], set()
    with torch.no_grad():
        for ordinal, batch in enumerate(runner.test_dataloader):
            guard()
            empty_gt_input(batch)
            observer.clear()
            model.test_step(batch)
            sample = batch['data_samples'][0]
            key = str(sample.img_id)
            assert key not in identifiers, 'Duplicate image in single-device test loader'
            identifiers.add(key)
            rows, record = inspect_image(observer, sample, index[key], ordinal)
            traces.append(rows)
            records.append(record)
            if ordinal % 25 == 0:
                write(work / 'PROGRESS.json', dict(images=ordinal+1, expected=reference['evaluation_images'], at=time.time()))
    assert len(identifiers) == reference['evaluation_images']
    observer.remove()
    assert before == state_digest(model), 'Model state changed during observation'
    rows = np.concatenate(traces)
    np.savez_compressed(work / 'QUERY_TRACES.npz', rows=rows,
        image_ordinal=np.concatenate([np.full(len(t), i, dtype=np.int32) for i, t in enumerate(traces)]),
        fields=np.asarray(FIELDS))
    summary = finite_summary(rows)
    summary.update(domain=domain, shot=shot, seed=seed, image_count=len(records),
        raw_P100_proxy=sum(x['ranking']['raw']['tp'] for x in records)/sum(x['ranking']['raw']['predictions'] for x in records),
        quality_P100_proxy=sum(x['ranking']['quality']['tp'] for x in records)/sum(x['ranking']['quality']['predictions'] for x in records),
        no_training=True, original_prediction_method_unmodified=True,
        plan_sha256=sha(ROOT / 'PLAN.json'), annotations_sha256=sha(audit['splits']['test']['view']))
    write(work / 'IMAGE_RECORDS.json', records)
    write(work / 'RESULT.json', summary)
    write(work / 'COMPLETE.json', dict(result_sha256=sha(work / 'RESULT.json'),
        trace_sha256=sha(work / 'QUERY_TRACES.npz'), unchanged_model_state=True, at=time.time()))


def cpu_checks():
    from validation_common import setup, SOURCE, BASE
    setup()
    from mmdet.utils import register_all_modules
    from mmdet.registry import DATASETS
    from qcal_config import make_config
    register_all_modules(init_default_scope=True)
    boxes = np.array([[0, 0, 10, 10], [0, 0, 10, 10], [20, 20, 30, 30]])
    gt = np.array([[0, 0, 10, 10]])
    iou = overlaps(boxes, gt)
    assert np.array_equal(iou[:, 0], np.array([1., 1., 0.]))
    assert greedy_precision(np.array([.9, .8, .7]), np.array([0, 0, 0]), iou, np.array([0]))['tp'] == 1
    assert overlaps(boxes, np.empty((0, 4))).shape == (3, 0)
    synthetic = np.zeros((3, len(FIELDS)), dtype=np.float32)
    synthetic[:, 0] = [.2, .5, .8]
    synthetic[:, 1] = [.3, .6, .9]
    synthetic[:, 2] = [.1, .5, .9]
    synthetic[:, 3] = [.2, .6, .95]
    synthetic[:, 4] = [.1, .5, .9]
    synthetic[:, 10] = [500, 2000, 20000]
    summary = finite_summary(synthetic)
    assert summary['quality_spearman_best_geometric_iou'] > .99
    assert summary['boundary']['all']['mean_delta'] > 0
    pipeline_records = []
    for domain in ['NEU-DET', 'DIOR']:
        cfg = make_config(domain, 1, ROOT / 'cpu_checks', False)
        dataset = DATASETS.build(cfg.test_dataloader.dataset)
        item = dataset[0]
        empty_gt_input(dict(data_samples=[item['data_samples']]))
        sample = item['data_samples']
        value = pixels(np.array([[.5,.5,.2,.2]]), sample.metainfo)
        assert value.shape == (1,4) and np.isfinite(value).all()
        pipeline_records.append(dict(domain=domain, first_image_id=str(sample.img_id),
            image_count=len(dataset), no_ground_truth_in_packed_input=True, pixels=value.tolist()))
    write(ROOT / 'CPU_METRIC_CHECK_PASS.json', dict(status='PASS', duplicate_not_double_counted=True,
        empty_gt=True, pipelines=pipeline_records))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--engineering', action='store_true')
    p.add_argument('--cpu-checks', action='store_true')
    p.add_argument('--domain')
    p.add_argument('--shot', type=int)
    p.add_argument('--seed', type=int)
    a = p.parse_args()
    if a.cpu_checks:
        cpu_checks()
    elif a.engineering:
        engineering()
    else:
        run(a.domain, a.shot, a.seed)
