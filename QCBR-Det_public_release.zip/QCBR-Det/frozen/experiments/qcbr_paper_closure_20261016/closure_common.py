"""Isolated, finite, inference-only paper closure. No source-file edits."""
from pathlib import Path
import hashlib,json,os,shutil,sys

ROOT=Path(__file__).resolve().parent
BASE=Path('/root/autodl-tmp/vfmdetr_repro');EXPS=BASE/'experiments'
SOURCE=EXPS/'qcal_hed_20261006';EXT=EXPS/'qcal_hed_occa_sabr_20261007'
THREE=EXPS/'qcal_hed_occa_sabr_three_seeds_20261007';BUDGET=EXPS/'qcbr_hed200_lowshot_20261016'
MECH=EXPS/'qcbr_mechanism_efficiency_20261014'
PY=BASE/'software/envs/qcal_hed/bin/python'
CODE=['PLAN.json','closure_common.py','sensitivity.py','offline_analysis.py','driver.py']
DOMAINS=['ArTaxOr','clipart1k','DIOR','FISH','NEU-DET','UODD']
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
 tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False));tmp.replace(p)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def guard():
 assert not (ROOT/'PAUSE_REQUESTED').exists(),'USER_PAUSE_PAPER_CLOSURE'
 assert shutil.disk_usage(ROOT).free>80*1024**3,'LOW_DISK_SAFE_STOP'
def setup():
 os.environ.update(OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',CUBLAS_WORKSPACE_CONFIG=':4096:8')
 sys.path[:0]=list(map(str,[ROOT,MECH,EXT,SOURCE,SOURCE/'FT-FSOD',EXPS/'qcal_hed_ablation_10shot_20261008']))
def verify():
 plan=read(ROOT/'PLAN.json')
 assert sha(THREE/'RESULTS.json')==plan['main_results_sha256']
 assert sha(BUDGET/'BUDGET_ALLSHOTS.json')==plan['hed200_allshots_sha256']
 assert sha(BUDGET/'RESULTS.json')==read(BUDGET/'ALL_COMPLETE.json')['results_sha256']
 for root in [SOURCE,EXT,THREE,MECH,EXPS/'qcal_hed_ablation_10shot_20261008',EXPS/'qcbr_baseline_budget_20261013',BUDGET,ROOT]:
  for n,h in read(root/'FROZEN_MANIFEST.json').items():assert sha(root/n)==h,('FROZEN_FILE_CHANGED',str(root/n))
 return plan
def sources():
 q=read(THREE/'RESULTS.json')['results'];h=read(BUDGET/'BUDGET_ALLSHOTS.json')['results']
 key=lambda x:(x['domain'],x['shot'],x['seed'])
 qm={key(x):x for x in q};hm={key(x):x for x in h}
 expected={(d,k,s) for d in DOMAINS for k in [1,5,10] for s in [0,1,2]}
 assert set(qm)==set(hm)==expected and len(q)==len(h)==54
 return qm,hm
def prediction_path(record,kind):
 cp=record['adapter_checkpoint'] if kind=='qcbr' else record['checkpoint']
 return Path(cp['path']).parent/'predictions.bbox.json'
