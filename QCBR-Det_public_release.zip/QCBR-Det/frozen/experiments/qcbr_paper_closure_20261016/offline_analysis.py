"""Read existing predictions only. Explicit operating-point diagnostics, not new AP."""
from pathlib import Path
import collections,hashlib,math,time,traceback
import numpy as np
from closure_common import ROOT,BASE,SOURCE,DOMAINS,guard,read,write,sha,setup,verify,sources,prediction_path

ERRORS=['duplicate','classification','localization','classification_localization','background']

def overlap(boxes,targets,ioa=False):
 boxes=np.asarray(boxes,dtype=float).reshape(-1,4);targets=np.asarray(targets,dtype=float).reshape(-1,4)
 if not len(targets):return np.zeros((len(boxes),0))
 lo=np.maximum(boxes[:,None,:2],targets[None,:,:2]);hi=np.minimum(boxes[:,None,2:],targets[None,:,2:])
 inter=np.maximum(hi-lo,0).prod(-1);a=np.maximum(boxes[:,2:]-boxes[:,:2],0).prod(-1)
 if ioa:return inter/np.maximum(a[:,None],1e-12)
 b=np.maximum(targets[:,2:]-targets[:,:2],0).prod(-1)
 return inter/np.maximum(a[:,None]+b[None,:]-inter,1e-12)

def xyxy(b):x,y,w,h=b;return [x,y,x+w,y+h]

def diagnose(predictions,annotations):
 valid=[a for a in annotations if a['bbox'][2]>0 and a['bbox'][3]>0 and not a.get('ignore',0) and not a.get('iscrowd',0)]
 ignored=[a for a in annotations if a['bbox'][2]>0 and a['bbox'][3]>0 and (a.get('ignore',0) or a.get('iscrowd',0))]
 pred=sorted([p for p in predictions if p['score']>=.05],key=lambda x:-x['score'])[:100]
 boxes=[xyxy(p['bbox']) for p in pred];gt=[xyxy(a['bbox']) for a in valid];iou=overlap(boxes,gt)
 exclude=np.zeros(len(pred),bool)
 for crowd in [False,True]:
  sub=[xyxy(a['bbox']) for a in ignored if bool(a.get('iscrowd',0))==crowd]
  if sub:exclude|=overlap(boxes,sub,ioa=crowd).max(1)>=.5
 counts={x:0 for x in ERRORS};used=set();matched_annotations=[];retained=[]
 for i,p in enumerate(pred):
  if exclude[i]:continue
  retained.append(p)
  same=np.array([a['category_id']==p['category_id'] for a in valid],dtype=bool)
  eligible=[j for j in range(len(valid)) if j not in used and same[j] and iou[i,j]>=.5]
  if eligible:
   chosen=max(eligible,key=lambda j:iou[i,j]);used.add(chosen);matched_annotations.append(valid[chosen]['id']);continue
  if np.any(same & (iou[i]>=.5)):kind='duplicate'
  elif np.any(~same & (iou[i]>=.5)):kind='classification'
  elif np.any(same & (iou[i]>=.1)):kind='localization'
  elif np.any(~same & (iou[i]>=.1)):kind='classification_localization'
  else:kind='background'
  counts[kind]+=1
 n_gt=len(valid);tp=len(used);fp=sum(counts.values());assert tp+fp==len(retained)
 return dict(gt=n_gt,tp=tp,fp=fp,miss=n_gt-tp,ignored_predictions=int(exclude.sum()),**counts),set(matched_annotations),retained,valid

def engineering():
 ann=[dict(id=1,category_id=1,bbox=[0,0,10,10])]
 pred=[dict(category_id=1,bbox=[0,0,10,10],score=.9),dict(category_id=1,bbox=[0,0,10,10],score=.8),
       dict(category_id=2,bbox=[0,0,10,10],score=.7),dict(category_id=1,bbox=[5,0,10,10],score=.6),
       dict(category_id=2,bbox=[5,0,10,10],score=.5),dict(category_id=1,bbox=[50,50,10,10],score=.4)]
 got,matched,_,_=diagnose(pred,ann);assert got==dict(gt=1,tp=1,fp=5,miss=0,ignored_predictions=0,**{k:1 for k in ERRORS})
 assert matched=={1}
 got,*_=diagnose([],ann);assert got['miss']==1 and got['tp']==0
 got,*_=diagnose(pred[:1],[dict(ann[0],iscrowd=1)]);assert got['ignored_predictions']==1 and got['gt']==0
 write(ROOT/'OFFLINE_ENGINEERING_PASS.json',dict(status='PASS',toy_matching_all_error_types=True,crowd_exclusion=True,missing_objects=True))

def run():
 setup();verify();engineering();q,h=sources();audit=read(SOURCE/'DATA_AUDIT.json')['domains']
 all_records=[];image_summaries=[];best={};eligible_counts=collections.Counter();source_index=[];started=time.time()
 for k in [1,5,10]:
  for d in DOMAINS:
   raw=read(audit[d]['splits']['test']['view']);images={str(x['id']):x for x in raw['images']};anns=collections.defaultdict(list)
   cats={c['id'] for c in raw['categories']};cat_names={str(c['id']):c['name'] for c in raw['categories']}
   for a in raw['annotations']:anns[str(a['image_id'])].append(a)
   for seed in [0,1,2]:
    guard();key=(d,k,seed);bundles={};totals={}
    for kind,mapping in [('hed',h),('qcbr',q)]:
     ref=mapping[key];pp=prediction_path(ref,kind);assert pp.is_file() and sha(pp)==ref['predictions_sha256']
     pred=read(pp);assert len(pred)==300*len(images);groups=collections.defaultdict(list)
     for p in pred:
      assert str(p['image_id']) in images and p['category_id'] in cats
      assert math.isfinite(p['score']) and all(math.isfinite(v) for v in p['bbox'])
      groups[str(p['image_id'])].append(p)
     assert set(groups)==set(images) and all(len(v)==300 for v in groups.values())
     bundles[kind]=groups;totals[kind]=collections.Counter()
     source_index.append(dict(kind=kind,domain=d,shot=k,seed=seed,path=str(pp),sha256=ref['predictions_sha256']))
     del pred
    for iid,image in images.items():
     results={}
     for kind in ['hed','qcbr']:
      counts,matched,retained,valid=diagnose(bundles[kind][iid],anns[iid]);totals[kind].update(counts)
      results[kind]=dict(counts=counts,matched=matched,predictions=retained)
     assert results['hed']['counts']['gt']==results['qcbr']['counts']['gt']
     image_summaries.append(dict(domain=d,shot=k,seed=seed,image_id=image['id'],hed=results['hed']['counts'],qcbr=results['qcbr']['counts']))
     if seed==0:
      for direction,priority in [('success',[10,5,1]),('failure',[1,5,10])]:
       first,second=('qcbr','hed') if direction=='success' else ('hed','qcbr')
       changed=results[first]['matched']-results[second]['matched']
       if not changed:continue
       eligible_counts[d,k,direction]+=1
       target=min(changed);order=(priority.index(k),hashlib.sha256(f'qcbr-closure-v1|{d}|{iid}'.encode()).hexdigest(),target)
       if (d,direction) not in best or order<best[d,direction]['order']:
        best[d,direction]=dict(order=order,domain=d,shot=k,seed=0,direction=direction,image=image,target_annotation_id=target,
         ground_truth=valid,category_names=cat_names,hed=results['hed'],qcbr=results['qcbr'])
    for kind in ['hed','qcbr']:
     c=dict(totals[kind]);n=c['gt'];assert n>0 and c['tp']+c['miss']==n
     c.update(precision_percent=100*c['tp']/(c['tp']+c['fp']) if c['tp']+c['fp'] else None,
              recall_percent=100*c['tp']/n,misses_per100GT=100*c['miss']/n,false_positives_per100GT=100*c['fp']/n)
     c.update({f'{name}_per100GT':100*c[name]/n for name in ERRORS})
     all_records.append(dict(kind=kind,domain=d,shot=k,seed=seed,counts=c,metrics=(h if kind=='hed' else q)[key]['metrics']))
    del bundles
    write(ROOT/'OFFLINE_PROGRESS.json',dict(status='ANALYZING_EXISTING_PREDICTIONS',paired_cells_completed=len(all_records)//2,planned=54,elapsed_seconds=time.time()-started,at=time.time()))
 cases=[]
 from PIL import Image
 for d in DOMAINS:
  for direction in ['success','failure']:
   if (d,direction) not in best:
    cases.append(dict(domain=d,direction=direction,available=False,reason='No eligible example under the frozen rule'));continue
   item=best[d,direction];target=next(a for a in item['ground_truth'] if a['id']==item['target_annotation_id']);x,y,w,hh=target['bbox'];cx,cy=x+w/2,y+hh/2
   original=(BASE/'datasets'/d/'test'/item['image']['file_name']).resolve()
   assert str(original).startswith(str((BASE/'datasets').resolve())+'/')
   image=Image.open(original).convert('RGB');iw,ih=image.size
   cw,ch=max(3*w,256),max(3*hh,256)
   crop=[max(0,int(math.floor(cx-cw/2))),max(0,int(math.floor(cy-ch/2))),min(iw,int(math.ceil(cx+cw/2))),min(ih,int(math.ceil(cy+ch/2)))]
   assert crop[2]>crop[0] and crop[3]>crop[1]
   case_id=f'{d}_{direction}_{item["shot"]}shot_seed0';cp=ROOT/'cases'/(case_id+'.png');cp.parent.mkdir(exist_ok=True);image.crop(crop).save(cp)
   for kind in ['hed','qcbr']:item[kind]['matched']=sorted(item[kind]['matched'])
   item.pop('order');item.update(available=True,case_id=case_id,crop_xyxy=crop,crop_file=str(cp),crop_sha256=sha(cp),original_image=str(original),
      eligible_images_in_selected_cell=eligible_counts[d,item['shot'],direction])
   cases.append(item)
 write(ROOT/'CASE_MANIFEST.json',dict(cases=cases,selection_plan=read(ROOT/'PLAN.json')['qualitative'],outcome_stratified_illustration_not_representative=True))
 write(ROOT/'OFFLINE_RESULTS.json',dict(records=all_records,record_count=108,paired_cells=54,operating_point=read(ROOT/'PLAN.json')['offline']['operating_point'],
  error_order=ERRORS,source_predictions=source_index,plan_sha256=sha(ROOT/'PLAN.json'),not_COCO_AP=True,at=time.time()))
 write(ROOT/'IMAGE_DIAGNOSTICS.json',dict(records=image_summaries,operating_point=read(ROOT/'PLAN.json')['offline']['operating_point']))
 verify();write(ROOT/'OFFLINE_COMPLETE.json',dict(status='PASS',results_sha256=sha(ROOT/'OFFLINE_RESULTS.json'),cases_sha256=sha(ROOT/'CASE_MANIFEST.json'),
  image_diagnostics_sha256=sha(ROOT/'IMAGE_DIAGNOSTICS.json'),all_108_existing_predictions_hashed=True,no_training=True,at=time.time()))

if __name__=='__main__':
 try:run()
 except BaseException:write(ROOT/'OFFLINE_FAILURE.json',dict(traceback=traceback.format_exc(),at=time.time()));raise
