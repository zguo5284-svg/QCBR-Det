"""Frozen-model OAT deployment sensitivity; no optimizer or training code is called."""
import argparse,collections,contextlib,copy,io,json,math,time,traceback
from pathlib import Path
from closure_common import ROOT,SOURCE,guard,read,write,sha,setup,verify

def variants():return read(ROOT/'PLAN.json')['sensitivity']['variants']

class MultiPredict:
 def __init__(self,head):
  self.head=head;self.original=head.predict;self.original_extend=head._extend;self.outputs={}
 def extend(self,base,v):
  refined,residual,correction=self.original_extend(base)
  if v['occa_factor']!=1:residual=residual*v['occa_factor']
  if v['sabr_factor']!=1:
   import torch
   correction=correction*v['sabr_factor'];b=base['boxes']
   scale=torch.stack([b[...,2],b[...,3],b[...,2],b[...,3]],-1)
   refined=b+correction*scale
  return refined,residual,correction
 def predict(self,hidden_states,references,memory_text,text_token_mask,batch_data_samples,
             quality_memory,quality_shapes,quality_ratios,quality_mask,rescale=True):
  h=self.head
  base=h._base(hidden_states,references,memory_text,text_token_mask,batch_data_samples,
               quality_memory,quality_shapes,quality_ratios,quality_mask)
  self.outputs={}
  for v in variants():
   refined,residual,_=self.extend(base,v)
   quality=h.quality_logits(hidden_states,refined,quality_memory,quality_shapes,quality_ratios,quality_mask)
   scores=base['scores']*h.multiplier(quality)[...,None]*residual.exp()
   self.outputs[v['name']]=[h._predict_by_feat_single(scores[i],refined[i],s.token_positive_map,s.metainfo,rescale)
                           for i,s in enumerate(batch_data_samples)]
  return self.outputs['default']

def equivalent(a,b):
 import torch
 return len(a)==len(b) and all(torch.equal(getattr(x,n),getattr(y,n)) for x,y in zip(a,b) for n in ['bboxes','scores','labels'])

def initialize(d,k,work,support=False):
 setup()
 from validation_common import build,state_digest
 runner,reference,audit=build('full',d,k,0,work,support=support)
 model=runner.model;model.requires_grad_(False);model.eval()
 assert runner.optim_wrapper is None and runner.train_loop is None
 assert not any(p.requires_grad for p in model.parameters())
 assert not any(x['type']=='LoadAnnotations' for x in runner.cfg.test_dataloader.dataset.pipeline)
 before=state_digest(model)
 write(work/'MODEL_COMPOSITION.json',dict(status='PASS',domain=d,shot=k,seed=0,no_optimizer=True,no_train_loop=True,
  all_parameters_frozen=True,checkpoint=reference['adapter_checkpoint'],model_state_sha256=before,plan_sha256=sha(ROOT/'PLAN.json')))
 return runner,reference,audit,before

def engineering(d,k):
 import torch
 from validation_common import state_digest,empty_gt_input
 work=ROOT/'engineering'/f'{d}_{k}shot_seed0';work.mkdir(parents=True,exist_ok=True)
 runner,reference,audit,before=initialize(d,k,work,True);model=runner.model;multi=MultiPredict(model.bbox_head)
 checked=0
 with torch.inference_mode():
  for batch in runner.test_dataloader:
   guard();empty_gt_input(batch)
   vanilla=[s.pred_instances.clone() for s in model.test_step(batch)]
   model.bbox_head.predict=multi.predict
   default=[s.pred_instances for s in model.test_step(batch)]
   assert equivalent(vanilla,default),'DEFAULT_WRAPPER_NOT_BITWISE_EQUAL'
   shared={name:[p.clone() for p in out] for name,out in multi.outputs.items()}
   model.bbox_head.predict=multi.original
   for v in variants():
    model.bbox_head._extend=lambda base,v=v:multi.extend(base,v)
    separate=[s.pred_instances for s in model.test_step(batch)]
    assert equivalent(separate,shared[v['name']]),('SHARED_FORWARD_MISMATCH',v['name'])
    model.bbox_head._extend=multi.original_extend
   checked+=1
   if checked==2:break
 assert checked==2 and state_digest(model)==before
 verify()
 write(work/'PASS.json',dict(status='PASS',support_images=checked,no_test_AP_gate=True,all_five_variants_bitwise_equal=True,
  frozen_weights_unchanged=True,no_ground_truth_input=True,no_training=True,plan_sha256=sha(ROOT/'PLAN.json')))

def coco(annotation,predictions,work):
 from pycocotools.coco import COCO
 from pycocotools.cocoeval import COCOeval
 log=io.StringIO()
 with contextlib.redirect_stdout(log):
  gt=COCO(str(annotation));gt.dataset.setdefault('info',{})
  ev=COCOeval(gt,gt.loadRes(predictions),'bbox');ev.params.imgIds=sorted(gt.getImgIds());ev.params.catIds=sorted(gt.getCatIds());ev.params.maxDets=[1,10,100]
  ev.evaluate();ev.accumulate();ev.summarize()
 (work/'COCO.log').write_text(log.getvalue())
 return {m:None if x<0 else float(x)*100 for m,x in zip(['AP','AP50','AP75','APs','APm','APl','AR1','AR10','AR100','ARs','ARm','ARl'],ev.stats)}

def run(d,k):
 import torch
 from validation_common import empty_gt_input,state_digest
 verify();guard();work=ROOT/'sensitivity'/f'{d}_{k}shot_seed0';work.mkdir(parents=True,exist_ok=True)
 assert not (work/'COMPLETE.json').exists(),'Do not overwrite completed sensitivity'
 runner,reference,audit,before=initialize(d,k,work)
 model=runner.model;multi=MultiPredict(model.bbox_head);model.bbox_head.predict=multi.predict
 annotation=Path(audit['splits']['test']['view']);raw=read(annotation)
 cats={c['name']:c['id'] for c in raw['categories']};cat_ids=[cats[c] for c in audit['classes']]
 ids={str(im['id']):im['id'] for im in raw['images']};outputs={v['name']:[] for v in variants()};seen=set();start=time.time()
 with torch.inference_mode():
  for ordinal,batch in enumerate(runner.test_dataloader):
   guard();empty_gt_input(batch);model.test_step(batch)
   assert len(batch['data_samples'])==1
   sample=batch['data_samples'][0];key=str(sample.img_id);assert key in ids and key not in seen;seen.add(key)
   for name,instances in multi.outputs.items():
    assert len(instances)==1;p=instances[0];assert len(p)==300
    boxes=p.bboxes.detach().cpu().double().numpy();scores=p.scores.detach().cpu().double().numpy();labels=p.labels.detach().cpu().tolist()
    for box,score,label in zip(boxes,scores,labels):
     x,y,x2,y2=map(float,box);assert math.isfinite(score) and all(math.isfinite(v) for v in box) and x2>=x and y2>=y
     outputs[name].append(dict(image_id=ids[key],category_id=cat_ids[int(label)],bbox=[x,y,x2-x,y2-y],score=float(score)))
   if ordinal%50==0 or ordinal+1==len(ids):
    write(work/'PROGRESS.json',dict(status='INFERENCE',images=ordinal+1,total_images=len(ids),five_variants_per_image=True,elapsed_seconds=time.time()-start,at=time.time()))
 assert seen==set(ids) and state_digest(model)==before
 model.bbox_head.predict=multi.original
 del model,runner,multi;torch.cuda.empty_cache()
 records=[]
 for v in variants():
  guard();vw=work/v['name'];vw.mkdir(exist_ok=True);prediction=vw/'predictions.bbox.json'
  write(prediction,outputs[v['name']]);metrics=coco(annotation,outputs[v['name']],vw)
  result=dict(domain=d,shot=k,seed=0,variant=v['name'],occa_factor=v['occa_factor'],sabr_factor=v['sabr_factor'],metrics=metrics,
   images=len(ids),candidates_per_image=300,checkpoint=reference['adapter_checkpoint'],weights_unchanged=True,no_training=True,
   annotation_sha256=sha(annotation),predictions_sha256=sha(prediction),plan_sha256=sha(ROOT/'PLAN.json'))
  write(vw/'RESULT.json',result);records.append(result)
  write(work/'PROGRESS.json',dict(status='COCO_EVALUATION',evaluated=len(records),planned=5,at=time.time()))
 default=next(x for x in records if x['variant']=='default')
 differences={m:default['metrics'][m]-reference['metrics'][m] for m in ['AP','AP50','AP75']}
 assert all(abs(v)<=.001 for v in differences.values()),('DEFAULT_REPRODUCTION_DIFFERENCE',differences)
 verify();write(work/'RESULTS.json',dict(results=records,default_minus_fixed_main=differences,default_reproduction_tolerance_pp=.001))
 write(work/'COMPLETE.json',dict(status='PASS',results_sha256=sha(work/'RESULTS.json'),all_weights_unchanged=True,no_training=True,at=time.time()))

if __name__=='__main__':
 setup();p=argparse.ArgumentParser();p.add_argument('--domain',required=True);p.add_argument('--shot',required=True,type=int);p.add_argument('--engineering',action='store_true');a=p.parse_args()
 try:
  verify();guard();(engineering if a.engineering else run)(a.domain,a.shot)
 except BaseException:
  where=ROOT/('engineering' if a.engineering else 'sensitivity')/f'{a.domain}_{a.shot}shot_seed0'
  write(where/'FAILURE.json',dict(traceback=traceback.format_exc(),at=time.time()));raise
