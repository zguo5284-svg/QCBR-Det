"""Bounded, isolated strategy experiment and immutable paper provenance."""
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path('/root/autodl-tmp/vfmdetr_repro')
SOURCE = BASE/'experiments/qcal_hed_20261006'
EXTENSION = BASE/'experiments/qcal_hed_occa_sabr_20261007'
THREE = BASE/'experiments/qcal_hed_occa_sabr_three_seeds_20261007'
ABLATION = BASE/'experiments/qcal_hed_ablation_10shot_20261008'
CONTROLS = BASE/'experiments/qcbr_baseline_budget_20261013'
PY = BASE/'software/envs/qcal_hed/bin/python'
DOMAINS = ['NEU-DET', 'DIOR']
VARIANTS = ['no_gate', 'nonzero_init', 'no_reg', 'joint_stage2']
CODE = ['PLAN.json', 'strategy_common.py', 'strategy_model.py', 'strategy_config.py',
        'strategy_runtime.py', 'train_strategy.py', 'evaluate_strategy.py',
        'engineering_strategy.py', 'driver_strategy.py']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def reference(domain, shot, seed):
    return next(r for r in read(THREE/'RESULTS.json')['results']
                if (r['domain'], r['shot'], r['seed']) == (domain, shot, seed))


def source_checkpoint(domain, shot, seed):
    return Path(reference(domain, shot, seed)['adapter_checkpoint']['reference_checkpoint'])


def work_for(variant, domain, shot, seed, engineering=False):
    assert variant in VARIANTS+['full'] and domain in DOMAINS
    assert shot in (1, 10) and seed in (0, 1, 2)
    prefix = ('engineering_joint_trace_v3' if variant == 'joint_stage2' else 'engineering_checks_v2') if engineering else 'runs'
    return ROOT/prefix/variant/f'{domain}_{shot}shot_seed{seed}'


def jobs():
    # Ordered before training, never changed in response to measured AP.
    for seed, shot, domain, variant in itertools.product((0, 1, 2), (1, 10), DOMAINS, VARIANTS):
        yield variant, domain, shot, seed


def verify_frozen():
    for p in (SOURCE, EXTENSION, THREE, ABLATION, CONTROLS):
        for name, expected in read(p/'FROZEN_MANIFEST.json').items():
            assert sha(p/name) == expected, (str(p), name)
    plan = read(ROOT/'PLAN.json')
    for p, key in ((THREE, 'main_results_sha256'), (ABLATION, 'ablation_results_sha256'),
                   (CONTROLS, 'controls_results_sha256')):
        assert sha(p/'RESULTS.json') == read(p/'ALL_COMPLETE.json')['results_sha256'] == plan['references'][key]
    if (ROOT/'FROZEN_MANIFEST.json').exists():
        for name, expected in read(ROOT/'FROZEN_MANIFEST.json').items():
            assert sha(ROOT/name) == expected, name
