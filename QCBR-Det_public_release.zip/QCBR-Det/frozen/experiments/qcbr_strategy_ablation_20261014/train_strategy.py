"""Four-rank training and explicitly audited terminal model inference."""
import argparse
from pathlib import Path
import torch
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmdet.utils import register_all_modules
from qcal_runtime import rank, model_of, barrier, ControlledPause
from extension_model import is_adapter
from strategy_common import ROOT, SOURCE, read, write, sha
from strategy_config import make_config


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--variant', required=True)
    p.add_argument('--domain', required=True)
    p.add_argument('--shot', required=True, type=int)
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--work-dir', required=True)
    p.add_argument('--engineering', action='store_true')
    p.add_argument('--resume')
    p.add_argument('--test', action='store_true')
    p.add_argument('--support-smoke', action='store_true')
    a = p.parse_args()
    register_all_modules(init_default_scope=True)
    cfg = make_config(a.variant, a.domain, a.shot, a.seed, a.work_dir, a.engineering)
    cfg.optim_wrapper.type = 'StrategyOptimWrapper'
    import_modules_from_strings(**cfg.custom_imports)
    if a.resume:
        cfg.load_from, cfg.resume = a.resume, not a.test
    if a.support_smoke:
        assert a.test
        view = read(SOURCE/'DATA_AUDIT.json')['domains'][a.domain]['splits'][f'{a.shot}_shot']['view']
        cfg.test_dataloader.dataset.ann_file = view
        cfg.test_dataloader.dataset.data_prefix.img = cfg.train_dataloader.dataset.data_prefix.img
        cfg.test_evaluator.ann_file = view
        cfg.test_evaluator.outfile_prefix = str(Path(a.work_dir)/'support_smoke')
    runner = Runner.from_cfg(cfg)
    assert runner.seed == a.seed
    if not a.test:
        runner.train()
        if rank() == 0:
            write(Path(a.work_dir)/'TRAIN_COMPLETE.json', dict(variant=a.variant,
                domain=a.domain, shot=a.shot, seed=a.seed, completed_epochs=runner.epoch,
                completed_iter=runner.iter, plan_sha256=sha(ROOT/'PLAN.json'), engineering=a.engineering))
        return
    assert a.resume
    model = model_of(runner)
    model.init_weights()
    runner.load_or_resume()
    saved = torch.load(a.resume, map_location='cpu')
    current = model.state_dict()
    expected = 2 if a.engineering else 100
    assert saved['meta']['seed'] == a.seed and saved['meta']['epoch'] == expected
    assert (saved['strategy_variant'], saved['strategy_domain'], saved['strategy_shot']) == (a.variant, a.domain, a.shot)
    assert saved['strategy_plan_sha256'] == sha(ROOT/'PLAN.json')
    source_hash = sha(model.reference_checkpoint)
    assert saved['reference_sha256'] == source_hash
    if a.variant == 'joint_stage2':
        assert set(saved['state_dict']) == set(current)
        assert all(torch.equal(t.cpu(), saved['state_dict'][n]) for n, t in current.items())
    else:
        adapters = {n for n in current if is_adapter(n)}
        assert set(saved['state_dict']) == adapters
        assert all(torch.equal(current[n].cpu(), saved['state_dict'][n]) for n in adapters)
        source = torch.load(model.reference_checkpoint, map_location='cpu')['state_dict']
        assert all(torch.equal(current[n].cpu(), source[n]) for n in current if not is_adapter(n))
        del source
    evidence = dict(rank=rank(), seed=a.seed, domain=a.domain, shot=a.shot,
        variant=a.variant, checkpoint_sha256=sha(a.resume), reference_sha256=source_hash,
        state_keys=len(current), all_inference_tensors_verified=True)
    gathered = [None]*4
    torch.distributed.all_gather_object(gathered, evidence)
    assert {x['rank'] for x in gathered} == set(range(4))
    assert len({x['checkpoint_sha256'] for x in gathered}) == 1
    if rank() == 0:
        write(Path(a.work_dir)/'INFERENCE_MODEL_AUDIT_PASS.json', dict(status='PASS',
            four_ranks_verified=True, ranks=gathered))
    del current, saved
    barrier()
    runner.test()
    if rank() == 0:
        work = Path(a.work_dir)
        prediction = work/('support_smoke.bbox.json' if a.support_smoke else 'predictions.bbox.json')
        write(work/'INFERENCE_COMPLETE.json', dict(status='PASS', support_smoke=a.support_smoke,
            predictions_sha256=sha(prediction), model_audit_sha256=sha(work/'INFERENCE_MODEL_AUDIT_PASS.json')))
    barrier()


if __name__ == '__main__':
    try:
        main()
    except ControlledPause as error:
        print(str(error), flush=True)
        if torch.distributed.is_initialized():
            torch.distributed.destroy_process_group()
        raise SystemExit(75)
