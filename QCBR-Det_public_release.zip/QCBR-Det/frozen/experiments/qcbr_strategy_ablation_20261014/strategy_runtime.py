"""Finite-gradient audits and exact, pause-safe all-rank checkpointing."""
import math
import hashlib
import random
import shutil
import time
from pathlib import Path
import numpy as np
import torch
from mmengine.hooks import Hook
from mmengine.registry import HOOKS, OPTIM_WRAPPERS
from extension_runtime import AdapterOptimWrapper
from extension_model import is_adapter
from qcal_runtime import model_of, rank, barrier, mixup_transforms, ControlledPause
from strategy_common import ROOT, read, write, sha, reference


def assert_restored_equal(actual, expected):
    if isinstance(actual, torch.Tensor):
        assert isinstance(expected, torch.Tensor) and torch.equal(actual.detach().cpu(), expected.cpu())
    elif isinstance(actual, dict):
        assert set(actual) == set(expected)
        for key in actual:
            assert_restored_equal(actual[key], expected[key])
    elif isinstance(actual, (list, tuple)):
        assert len(actual) == len(expected)
        for x, y in zip(actual, expected):
            assert_restored_equal(x, y)
    else:
        assert actual == expected


@OPTIM_WRAPPERS.register_module()
class StrategyOptimWrapper(AdapterOptimWrapper):
    def step(self, **kwargs):
        names = getattr(self, 'strategy_parameter_names', {})
        maxima = {}
        for group in self.optimizer.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue
                name = names.get(id(p), '?')
                role = 'adapter' if is_adapter(name) else name.split('.')[0]
                # A true backward-path audit, before gradients are cleared by update.
                value = float(p.grad.detach().abs().max())
                maxima[role] = max(maxima.get(role, 0), value)
        self.strategy_gradient_maxima = maxima
        super().step(**kwargs)


@HOOKS.register_module()
class StrategyCheckpointHook(Hook):
    priority = 'LOWEST'

    def __init__(self, root, variant, domain, shot, seed, total_epochs=100, engineering=False):
        self.root = Path(root)
        self.variant = variant
        self.domain, self.shot, self.seed = domain, shot, seed
        self.total_epochs, self.engineering = total_epochs, engineering
        self.joint = variant == 'joint_stage2'
        self.gradient_seen = {}

    def after_load_checkpoint(self, runner, checkpoint):
        if getattr(runner, '_resume', False):
            assert checkpoint['strategy_variant'] == self.variant
            assert checkpoint['strategy_domain'] == self.domain and checkpoint['strategy_shot'] == self.shot
            assert checkpoint['validation_seed'] == checkpoint['meta']['seed'] == self.seed
            assert checkpoint['strategy_plan_sha256'] == sha(self.root/'PLAN.json')
            self.resume_states = checkpoint['strategy_rank_states']
            self.resume_reference_hash = checkpoint['reference_sha256']
            self.gradient_seen = checkpoint.get('gradient_seen', {})

    def before_train(self, runner):
        model = model_of(runner)
        assert runner.seed == self.seed and model._reference_loaded_exact
        assert model.strategy_variant == self.variant
        expected = reference(self.domain, self.shot, self.seed)['adapter_checkpoint']['reference_sha256']
        hashes = [sha(model.reference_checkpoint) if rank() == 0 else None]
        torch.distributed.broadcast_object_list(hashes, src=0)
        self.reference_hash = hashes[0]
        assert self.reference_hash == expected
        trainable = [n for n, p in model.named_parameters() if p.requires_grad]
        assert trainable and not any(n.startswith('bbox_head.quality_net.') for n in trainable)
        assert any(is_adapter(n) for n in trainable)
        assert any(not is_adapter(n) for n in trainable) if self.joint else all(is_adapter(n) for n in trainable)
        runner.optim_wrapper.strategy_parameter_names = {id(p): n for n, p in model.named_parameters()}
        self.group_names = []
        for group in runner.optim_wrapper.optimizer.param_groups:
            names = [runner.optim_wrapper.strategy_parameter_names[id(p)] for p in group['params']]
            prefixes = {n.split('.')[0] for n in names}
            assert len(prefixes) == 1 or not self.joint
            self.group_names.append(names[0])
        torch.cuda.reset_peak_memory_stats()
        if getattr(runner, '_resume', False):
            assert self.reference_hash == self.resume_reference_hash and len(self.resume_states) == 4
            checkpoint = torch.load(runner.cfg.load_from, map_location='cpu')
            current = model.state_dict()
            selected = {n: t for n, t in current.items() if self.joint or is_adapter(n)}
            assert_restored_equal(selected, checkpoint['state_dict'])
            assert_restored_equal(runner.optim_wrapper.state_dict(), checkpoint['optimizer'])
            del checkpoint, current, selected
            info = self.resume_states[rank()]
            assert sha(info['path']) == info['sha256']
            state = torch.load(info['path'], map_location='cpu')
            for index, transform in mixup_transforms(runner):
                transform.results_cache = state['augmentation_caches'][index]
            random.setstate(state['python_rng'])
            np.random.set_state(state['numpy_rng'])
            torch.set_rng_state(state['torch_rng'])
            torch.cuda.set_rng_state(state['cuda_rng'])
            assert random.getstate() == state['python_rng']
            np_state = np.random.get_state()
            assert np_state[0] == state['numpy_rng'][0] and np.array_equal(np_state[1], state['numpy_rng'][1])
            assert np_state[2:] == state['numpy_rng'][2:]
            assert torch.equal(torch.get_rng_state(), state['torch_rng'])
            assert torch.equal(torch.cuda.get_rng_state(), state['cuda_rng'])
            model.bbox_head.identity_checked = True
            if rank() == 0:
                write(Path(runner.work_dir)/'RESUME_PASS.json', dict(status='PASS',
                    epoch=runner.epoch, iter=runner.iter, all_rank_rng_and_cached_mixup_restored=True,
                    model_and_optimizer_restored_bitwise_equal=True,
                    RNG_restoration_bitwise_equal=True, fresh_source_loaded_before_checkpoint=True))
        else:
            final_layers = [model.bbox_head.occa[-1], model.bbox_head.sabr[-1]]
            nonzero = all(torch.count_nonzero(m.weight).item() > 0 for m in final_layers)
            assert nonzero if self.variant == 'nonzero_init' else all(
                not torch.count_nonzero(m.weight).item() and not torch.count_nonzero(m.bias).item()
                for m in final_layers)
            assert not runner.optim_wrapper.optimizer.state
            if rank() == 0:
                write(Path(runner.work_dir)/'SOURCE_COVERAGE_PASS.json', dict(status='PASS',
                    source=model.reference_checkpoint, source_sha256=self.reference_hash,
                    all_existing_keys_loaded_exactly=True, seed=self.seed, source_epochs=100,
                    trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
                    trainable_names=trainable, nonzero_output_initialization=nonzero,
                    fresh_stage2_optimizer=True))
        if self.engineering:
            self.initial_outputs = {n: p.detach().cpu().clone() for n, p in model.named_parameters()
                                    if is_adapter(n) and '.3.' in n}
        barrier()

    def before_train_epoch(self, runner):
        model = model_of(runner)
        assert not model.training and not model.backbone.training and not model.encoder.training
        assert not model.language_model.training and not model.bbox_head.quality_net.training
        if rank() == 0 and shutil.disk_usage(self.root).free < 80*1024**3:
            write(self.root/'PAUSE_REQUESTED', dict(reason='disk free guard', at=time.time()))
        cosine = (1+math.cos(math.pi*runner.epoch/max(self.total_epochs-1, 1)))/2
        for name, group in zip(self.group_names, runner.optim_wrapper.optimizer.param_groups):
            initial = 2e-5 if self.joint and name.startswith(('backbone.', 'language_model.')) else 1e-4
            group['lr'] = 1e-6+(initial-1e-6)*cosine

    def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        model = model_of(runner)
        gradients = getattr(runner.optim_wrapper, 'strategy_gradient_maxima', {})
        for key, value in gradients.items():
            self.gradient_seen[key] = max(self.gradient_seen.get(key, 0), value)
        assert all(p.grad is None for n, p in model.named_parameters() if not p.requires_grad)
        diag = model.bbox_head.strategy_base_diagnostics
        if self.joint:
            assert all(diag[k] for k in ('boxes_require_grad', 'scores_require_grad',
                                        'occa_features_require_grad', 'sabr_features_require_grad'))
        else:
            assert not any(diag[k] for k in ('boxes_require_grad', 'scores_require_grad',
                                            'occa_features_require_grad', 'sabr_features_require_grad'))
        if self.engineering and self.joint:
            trace = dict(self.iter_trace)
            trace.update(losses={k: float(v) for k, v in (outputs or {}).items()},
                         positives=model.bbox_head.adapter_diagnostics['positives'])
            write(Path(runner.work_dir)/'ITER_TRACE'/f'rank{rank()}_iter{runner.iter+1:04d}.json', trace)
        if rank() == 0:
            losses = {k: float(v) for k, v in (outputs or {}).items()}
            assert all(math.isfinite(v) for v in losses.values())
            assert model.bbox_head.adapter_diagnostics['finite']
            if self.variant == 'no_reg':
                assert losses['loss_preservation'] == 0
            write(Path(runner.work_dir)/'PROGRESS.json', dict(status='TRAINING_STRATEGY',
                variant=self.variant, domain=self.domain, shot=self.shot, seed=self.seed,
                epoch=runner.epoch, completed_iter=runner.iter+1, epoch_batch=batch_idx+1,
                batches_per_epoch=len(runner.train_dataloader), time=time.time(), losses=losses,
                adapters=model.bbox_head.adapter_diagnostics, gradient_path=diag,
                gradient_seen=self.gradient_seen, peak_allocated_MiB=torch.cuda.max_memory_allocated()/1024**2,
                peak_reserved_MiB=torch.cuda.max_memory_reserved()/1024**2))
            if getattr(model.bbox_head, 'zero_prediction_identity_pass', False):
                write(Path(runner.work_dir)/'ZERO_IDENTITY_PASS.json', dict(status='PASS',
                    bboxes_scores_labels_bitwise_equal=True))

    def before_train_iter(self, runner, batch_idx, data_batch=None):
        if not (self.engineering and self.joint):
            return
        digest = hashlib.sha256()
        for image, sample in zip(data_batch['inputs'], data_batch['data_samples']):
            for tensor in (image, sample.gt_instances.bboxes, sample.gt_instances.labels):
                tensor = getattr(tensor, 'tensor', tensor)
                cpu = tensor.detach().cpu().contiguous()
                digest.update(str((cpu.dtype, tuple(cpu.shape))).encode())
                digest.update(cpu.numpy().tobytes())
            digest.update(repr({k: sample.metainfo.get(k) for k in
                ('img_id', 'img_shape', 'ori_shape', 'flip', 'flip_direction', 'text')}).encode())
        self.iter_trace = dict(rank=rank(), completed_iter=runner.iter+1,
            epoch=runner.epoch, batch_idx=batch_idx, raw_images_GT_and_metadata_sha256=digest.hexdigest())

    def after_train_epoch(self, runner):
        completed = runner.epoch+1
        pause, final = (self.root/'PAUSE_REQUESTED').exists(), completed == runner.max_epochs
        if not (self.engineering or completed % 10 == 0 or pause or final):
            return
        model, work = model_of(runner), Path(runner.work_dir)
        payload = dict(epoch=completed, iter=runner.iter, python_rng=random.getstate(),
            numpy_rng=np.random.get_state(), torch_rng=torch.get_rng_state(),
            cuda_rng=torch.cuda.get_rng_state(),
            augmentation_caches={i: t.results_cache for i, t in mixup_transforms(runner)})
        path = work/f'rank_state_epoch{completed:03d}_rank{rank()}.pth'
        temp = path.with_suffix('.tmp')
        torch.save(payload, temp)
        temp.replace(path)
        info = dict(path=str(path), sha256=sha(path))
        states = [None]*4
        torch.distributed.all_gather_object(states, info)
        self.rank_states = states
        if rank() == 0:
            runner.save_checkpoint(str(work), 'checkpoint_pending.pth', save_optimizer=True,
                                   save_param_scheduler=False, by_epoch=True)
            pending = work/'checkpoint_pending.pth'
            saved = torch.load(pending, map_location='cpu')
            own = {n: t for n, t in model.state_dict().items() if self.joint or is_adapter(n)}
            assert saved['meta']['epoch'] == completed and 'optimizer' in saved
            assert set(saved['state_dict']) == set(own)
            assert all(torch.equal(t.cpu(), saved['state_dict'][n]) for n, t in own.items())
            del saved, own
            latest = work/'checkpoint_latest.pth'
            if latest.exists():
                latest.replace(work/'checkpoint_previous.pth')
            pending.replace(latest)
            write(work/'LAST_CHECKPOINT.json', dict(path=str(latest), sha256=sha(latest),
                completed_epoch=completed, completed_iter=runner.iter, readback_exact=True,
                head_only=not self.joint, reference_checkpoint=model.reference_checkpoint,
                reference_sha256=self.reference_hash, rank_states=states, variant=self.variant,
                seed=self.seed, domain=self.domain, shot=self.shot))
            if final or self.engineering:
                source = torch.load(model.reference_checkpoint, map_location='cpu')['state_dict']
                current = model.state_dict()
                original = [n for n in current if not is_adapter(n)]
                changed = [n for n in original if not torch.equal(current[n].cpu(), source[n])]
                if self.joint:
                    assert changed and not any(n.startswith('bbox_head.quality_net.') for n in changed)
                    assert self.gradient_seen.get('decoder', 0) > 0
                    assert self.gradient_seen.get('encoder', 0) > 0
                    write(work/'DETECTOR_UPDATE_PASS.json', dict(status='PASS',
                        actual_detector_gradient_and_update=True, changed_detector_keys=len(changed),
                        changed_prefixes=sorted({n.split('.')[0] for n in changed}),
                        quality_head_unchanged=True, gradient_seen=self.gradient_seen,
                        detached_features_reconnected=True, forward_eval_mode_preserved=True))
                else:
                    assert not changed
                    write(work/'FROZEN_BASE_PASS.json', dict(status='PASS',
                        all_existing_state_keys_unchanged=len(original), reference_sha256=self.reference_hash))
                del source, current
                if self.engineering:
                    params = dict(model.named_parameters())
                    updated = {prefix: any(not torch.equal(params[n].detach().cpu(), value)
                        for n, value in self.initial_outputs.items() if n.startswith(prefix))
                        for prefix in ('bbox_head.occa.', 'bbox_head.sabr.')}
                    assert all(updated.values())
                    write(work/'ADAPTER_UPDATE_PASS.json', dict(status='PASS', updated=updated))
            if pause:
                write(work/'PAUSED.json', dict(completed_epoch=completed, at=time.time()))
        barrier()
        if pause:
            raise ControlledPause('Strategy pause: optimizer and four RNG/cache checkpoints saved')

    def before_save_checkpoint(self, runner, checkpoint):
        if not self.joint:
            checkpoint['state_dict'] = {n: t for n, t in checkpoint['state_dict'].items() if is_adapter(n)}
        checkpoint.update(strategy_variant=self.variant, strategy_domain=self.domain,
            strategy_shot=self.shot, validation_seed=self.seed, strategy_rank_states=self.rank_states,
            reference_sha256=self.reference_hash, strategy_plan_sha256=sha(self.root/'PLAN.json'),
            gradient_seen=self.gradient_seen)
