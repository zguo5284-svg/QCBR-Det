"""COCO terminal evaluation, never a configuration or checkpoint selector."""
import argparse
import math
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from strategy_common import ROOT, SOURCE, read, write, sha, work_for, reference


def evaluate(variant, domain, shot, seed):
    work = work_for(variant, domain, shot, seed)
    data = read(SOURCE/'DATA_AUDIT.json')['domains'][domain]['splits']
    annotation, prediction = data['test']['view'], work/'predictions.bbox.json'
    inference, audit = read(work/'INFERENCE_COMPLETE.json'), read(work/'INFERENCE_MODEL_AUDIT_PASS.json')
    last, done = read(work/'LAST_CHECKPOINT.json'), read(work/'TRAIN_COMPLETE.json')
    assert inference['status'] == 'PASS' and not inference['support_smoke']
    assert audit['four_ranks_verified']
    assert inference['predictions_sha256'] == sha(prediction)
    assert inference['model_audit_sha256'] == sha(work/'INFERENCE_MODEL_AUDIT_PASS.json')
    assert last['completed_epoch'] == done['completed_epochs'] == 100 and last['readback_exact']
    assert last['sha256'] == sha(last['path']) and done['plan_sha256'] == sha(ROOT/'PLAN.json')
    assert (done['variant'], done['domain'], done['shot'], done['seed']) == (variant, domain, shot, seed)
    assert all((r['variant'], r['domain'], r['shot'], r['seed'], r['checkpoint_sha256']) ==
               (variant, domain, shot, seed, last['sha256']) for r in audit['ranks'])
    raw, predictions = read(annotation), read(prediction)
    ids, categories = {r['id'] for r in raw['images']}, {r['id'] for r in raw['categories']}
    assert len(predictions) == 300*len(ids)
    assert all(r['image_id'] in ids and r['category_id'] in categories and math.isfinite(r['score'])
               and all(math.isfinite(v) for v in r['bbox']) for r in predictions)
    gt = COCO(annotation)
    gt.dataset.setdefault('info', {})
    evaluator = COCOeval(gt, gt.loadRes(predictions), 'bbox')
    evaluator.params.imgIds, evaluator.params.catIds = sorted(ids), sorted(categories)
    evaluator.params.maxDets = [1, 10, 100]
    evaluator.evaluate()
    evaluator.accumulate()
    evaluator.summarize()
    names = ['AP', 'AP50', 'AP75', 'APs', 'APm', 'APl', 'AR1', 'AR10', 'AR100', 'ARs', 'ARm', 'ARl']
    metrics = {k: None if v < 0 else float(v)*100 for k, v in zip(names, evaluator.stats)}
    full = reference(domain, shot, seed)
    assert full['annotation_sha256'] == sha(annotation)
    assert last['reference_sha256'] == full['adapter_checkpoint']['reference_sha256']
    result = dict(variant=variant, domain=domain, shot=shot, seed=seed, metrics=metrics,
        checkpoint=last, backbone='Swin-B', metric='COCO bbox AP@[0.50:0.95] (%)',
        source_epochs=100, residual_phase_epochs=100, phase_updates=done['completed_iter'],
        evaluation_images=len(ids), annotation_sha256=sha(annotation),
        support_annotation_sha256=sha(data[f'{shot}_shot']['view']), predictions_sha256=sha(prediction),
        fixed_support=True, four_rank_inference_weights_verified=True, plan_sha256=sha(ROOT/'PLAN.json'),
        selection='fixed terminal epoch, no AP selection',
        paired_difference_from_full={k: metrics[k]-full['metrics'][k] for k in ('AP', 'AP50', 'AP75')})
    write(work/'RESULT.json', result)
    write(work/'COMPLETE.json', dict(status='COMPLETE', result_sha256=sha(work/'RESULT.json')))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    for name in ('variant', 'domain'):
        p.add_argument('--'+name, required=True)
    for name in ('shot', 'seed'):
        p.add_argument('--'+name, type=int, required=True)
    a = p.parse_args()
    evaluate(a.variant, a.domain, a.shot, a.seed)
