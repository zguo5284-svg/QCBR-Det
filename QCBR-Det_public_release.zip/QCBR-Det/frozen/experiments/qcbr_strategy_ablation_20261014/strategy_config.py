"""The terminal source and fixed recipe are shared by paired interventions."""
from extension_config import make_config as original_config
from strategy_common import ROOT, source_checkpoint


def make_config(variant, domain, shot, seed, work, engineering=False):
    cfg = original_config(domain, shot, work, False)
    cfg.model.update(type='StrategyDetector', strategy_variant=variant,
                     reference_checkpoint=str(source_checkpoint(domain, shot, seed)))
    cfg.model.bbox_head.update(type='StrategyHead', strategy_variant=variant, training_seed=seed)
    cfg.randomness.seed = seed
    cfg.custom_imports = dict(imports=['strategy_model', 'strategy_runtime'], allow_failed_imports=False)
    epochs = 2 if engineering else 100
    cfg.train_cfg.max_epochs = epochs
    cfg.train_cfg.val_interval = 101
    cfg.custom_hooks = [dict(type='StrategyCheckpointHook', root=str(ROOT), variant=variant,
        domain=domain, shot=shot, seed=seed, total_epochs=epochs, engineering=engineering)]
    if variant == 'joint_stage2':
        # Same reference FP32 and clipping, no new loss; only gradient/update scope changes.
        cfg.model_wrapper_cfg.find_unused_parameters = True
        cfg.optim_wrapper.paramwise_cfg = dict(custom_keys={
            'absolute_pos_embed': dict(decay_mult=0),
            'backbone': dict(lr_mult=0.2), 'language_model': dict(lr_mult=0.2)})
    return cfg
