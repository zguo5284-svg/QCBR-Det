"""One-factor interventions; original classes/files are never patched."""
import ast
import copy
import functools
import inspect
import math
import textwrap
import torch
from torch import nn
from torch.utils.checkpoint import checkpoint
from mmdet.registry import MODELS
from qcal_model import QCalHEDDetector
from extension_model import FourModuleDetector, FourModuleHead, is_adapter


def remove_outer_no_grad(function):
    """Retain the frozen function body verbatim except its outer grad guard.

    Used only by the joint-update control, not any fixed-method execution.
    Additional nested no-grad matching/target construction is left untouched.
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(function)))
    node = tree.body[0]
    assert isinstance(node.body[0], ast.With) and len(node.body[0].items) == 1
    assert ast.unparse(node.body[0].items[0].context_expr) == 'torch.no_grad()'
    node.body = node.body[0].body + node.body[1:]
    node.decorator_list = []
    ast.fix_missing_locations(tree)
    env = dict(function.__globals__)
    exec(compile(tree, '<isolated-joint-gradient-control>', 'exec'), env)
    return env[function.__name__]


JOINT_BASE = remove_outer_no_grad(FourModuleHead._base)
JOINT_LOSS = remove_outer_no_grad(FourModuleDetector.loss)


@MODELS.register_module()
class StrategyDetector(FourModuleDetector):
    def __init__(self, strategy_variant, **kwargs):
        self.strategy_variant = strategy_variant
        super().__init__(**kwargs)
        if strategy_variant == 'joint_stage2':
            for name, p in self.named_parameters():
                p.requires_grad_(not name.startswith(('bbox_head.quality_net.', 'dn_query_generator.')))
            for module in self.modules():
                original = getattr(module.forward, '__wrapped__', None)
                if original is not None and getattr(original, '__self__', None) is module:
                    # Retain the exact eval forward, but permit activation recomputation
                    # on its newly enabled gradient path without enabling dropout/DN.
                    def recompute(*args, _original=original, **kw):
                        if torch.is_grad_enabled():
                            return checkpoint(_original, *args, use_reentrant=False, **kw)
                        return _original(*args, **kw)
                    module.forward = functools.wraps(original)(recompute)

    def forward_decoder(self, *args, **kwargs):
        output = super().forward_decoder(*args, **kwargs)
        if self.strategy_variant == 'joint_stage2':
            # Reconnect encoder evidence, rather than merely flipping requires_grad.
            memory = kwargs['memory'] if 'memory' in kwargs else args[1]
            output['quality_memory'] = memory
        return output

    def loss(self, batch_inputs, batch_data_samples):
        if self.strategy_variant == 'joint_stage2':
            return JOINT_LOSS(self, batch_inputs, batch_data_samples)
        return super().loss(batch_inputs, batch_data_samples)


@MODELS.register_module()
class StrategyHead(FourModuleHead):
    def __init__(self, strategy_variant, training_seed, **kwargs):
        self.strategy_variant = strategy_variant
        self.training_seed = training_seed
        super().__init__(**kwargs)

    def reset_adapters(self):
        if self.strategy_variant != 'nonzero_init':
            return super().reset_adapters()
        generator = torch.Generator(device='cpu').manual_seed(100000+self.training_seed)
        for module in (self.occa, self.sabr):
            final = module[-1]
            bound = 1/math.sqrt(final.in_features)
            with torch.no_grad():
                for parameter in (final.weight, final.bias):
                    initial = torch.empty(parameter.shape, dtype=parameter.dtype, device='cpu')
                    initial.uniform_(-bound, bound, generator=generator)
                    parameter.copy_(initial.to(parameter.device))
        # The removed initialization guarantee must not be asserted as an identity.
        self.identity_checked = True

    def _base(self, *args, **kwargs):
        function = JOINT_BASE if self.strategy_variant == 'joint_stage2' else FourModuleHead._base
        base = function(self, *args, **kwargs)
        if self.strategy_variant == 'no_gate':
            base['gate'] = torch.ones_like(base['gate'])
        if torch.is_grad_enabled():
            # The initial identity probe runs predict() under no_grad; it must
            # not overwrite diagnostics of the actual loss/backward graph.
            self.strategy_base_diagnostics = dict(
                boxes_require_grad=base['boxes'].requires_grad,
                scores_require_grad=base['scores'].requires_grad,
                occa_features_require_grad=base['occa_features'].requires_grad,
                sabr_features_require_grad=base['sabr_features'].requires_grad,
                quality_gate_removed=self.strategy_variant == 'no_gate')
        return base

    def adapter_loss(self, **kwargs):
        losses = super().adapter_loss(**kwargs)
        if self.strategy_variant == 'no_reg':
            losses['loss_preservation'] = losses['loss_preservation']*0
        return losses
