"""Check calibration identities and gradients using synthetic tensors only."""
import json
from pathlib import Path
import torch
from qcal_config import make_config
from qcal_runtime import json_write
from mmdet.utils import register_all_modules
from mmengine.utils import import_modules_from_strings
from mmdet.registry import MODELS


def main():
    root = Path(__file__).resolve().parent
    register_all_modules()
    cfg = make_config('NEU-DET',1,root/'engineering')
    import_modules_from_strings(**cfg.custom_imports)
    # A head-only build avoids allocating the full detector for unit tests.
    head_cfg = dict(cfg.model.bbox_head)
    head_cfg.update(embed_dims=256, num_pred_layer=7, share_pred_layer=False,
                    as_two_stage=True, train_cfg=cfg.model.train_cfg,
                    test_cfg=cfg.model.test_cfg)
    head = MODELS.build(head_cfg).cuda()
    head.init_weights()
    states = torch.randn(6,1,900,256,device='cuda',requires_grad=True)
    boxes = torch.rand(1,900,4,device='cuda')
    memory = torch.randn(1,16*20,256,device='cuda',requires_grad=True)
    mask = torch.zeros(1,16*20,device='cuda',dtype=torch.bool)
    mask.reshape(1,16,20)[:,:,18:] = True
    output = head.quality_logits(states,boxes,memory,
        torch.tensor([[16,20]],device='cuda'),
        torch.tensor([[[.9,1.]]],device='cuda'),mask)
    assert torch.equal(output,torch.zeros_like(output))
    assert torch.equal(head.multiplier(output),torch.ones_like(output))
    target = torch.full_like(output,.8)
    torch.nn.functional.binary_cross_entropy_with_logits(output,target).backward()
    assert torch.isfinite(head.quality_net[-1].weight.grad).all()
    assert head.quality_net[-1].weight.grad.abs().sum() > 0
    assert states.grad is None and memory.grad is None
    optimizer = torch.optim.AdamW(head.quality_net.parameters(),lr=1e-4)
    optimizer.step()
    changed = head.quality_logits(states,boxes,memory,
        torch.tensor([[16,20]],device='cuda'),
        torch.tensor([[[.9,1.]]],device='cuda'),mask)
    assert torch.isfinite(changed).all() and not torch.equal(output,changed)
    json_write(root/'UNIT_PASS.json',{'initial_score_identity':True,
        'finite_quality_gradients':True,'detached_detector_features':True,
        'quality_parameters':sum(p.numel() for p in head.quality_net.parameters()),
        'padding_aware_region_pooling':True})
    print('UNIT_PASS',flush=True)


if __name__ == '__main__':
    main()
