"""Unrounded standard COCO metrics from saved final-epoch predictions."""
import argparse
import json
import math
from pathlib import Path
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from qcal_runtime import json_write, sha256


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--domain',required=True)
    parser.add_argument('--shot',type=int,required=True)
    parser.add_argument('--work-dir',required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    work=Path(args.work_dir)
    audit=json.loads((root/'DATA_AUDIT.json').read_text())['domains'][args.domain]
    gt_path=Path(audit['splits']['test']['view'])
    pred_path=work/'predictions.bbox.json'
    predictions=json.loads(pred_path.read_text())
    raw=json.loads(gt_path.read_text())
    ids={x['id'] for x in raw['images']}
    cats={x['id'] for x in raw['categories']}
    assert predictions
    assert all(p['image_id'] in ids and p['category_id'] in cats and
               math.isfinite(p['score']) and all(math.isfinite(v) for v in p['bbox'])
               for p in predictions)
    coco=COCO(str(gt_path))
    coco.dataset.setdefault('info',{})
    detected=coco.loadRes(predictions)
    evaluator=COCOeval(coco,detected,'bbox')
    evaluator.params.imgIds=sorted(ids)
    evaluator.params.catIds=sorted(cats)
    evaluator.params.maxDets=[1,10,100]
    evaluator.evaluate()
    evaluator.accumulate()
    evaluator.summarize()
    metrics={name:float(value)*100 for name,value in zip(
        ['AP','AP50','AP75','APs','APm','APl','AR1','AR10','AR100','ARs','ARm','ARl'],
        evaluator.stats)}
    last=json.loads((work/'LAST_CHECKPOINT.json').read_text())
    assert last['completed_epoch']==100 and last['readback_exact']
    result={'domain':args.domain,'shot':args.shot,'seed':0,
            'metrics':metrics,'metric':'COCO bbox AP@[0.50:0.95] (%)',
            'maxDets':[1,10,100],'evaluation_images':len(ids),
            'candidate_detections':len(predictions),
            'checkpoint':last,'predictions_sha256':sha256(pred_path),
            'annotation_sha256':sha256(gt_path),'ID_remapping_only':True,
            'model_selection':'fixed epoch100; no test AP selection',
            'backbone':'Swin-B','base':'MMGroundingDINO-B source pretrained',
            'single_seed_not_three_seed_mean':True}
    json_write(work/'RESULT.json',result)
    json_write(work/'COMPLETE.json',{'status':'COMPLETE','result_sha256':sha256(work/'RESULT.json')})


if __name__=='__main__':
    main()
