"""Create audited integer-ID views without changing boxes or support samples."""
import copy
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path('/root/autodl-tmp/vfmdetr_repro')
DOMAINS = ['ArTaxOr', 'clipart1k', 'DIOR', 'FISH', 'NEU-DET', 'UODD']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, obj):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2))
    temporary.replace(path)


def main():
    assert json.loads((ROOT / 'PLAN.json').read_text())['training']['formal_jobs'] == 18
    output = ROOT / 'data_views'
    output.mkdir(exist_ok=True)
    audit = {'status': 'PASS', 'domains': {}, 'ID_remapping_only': True}
    for domain in DOMAINS:
        folder = BASE / 'datasets' / domain
        first = json.loads((folder / 'annotations/1_shot.json').read_text())
        categories = first['categories']
        assert len({x['name'] for x in categories}) == len(categories)
        names = [x['name'] for x in categories]
        view_folder = output / domain
        view_folder.mkdir(exist_ok=True)
        items = {}
        for split in ['1_shot', '5_shot', '10_shot', 'test']:
            source = folder / 'annotations' / (split + '.json')
            raw = json.loads(source.read_text())
            assert set(x['name'] for x in raw['categories']) == set(names)
            class_names = {x['id']: x['name'] for x in raw['categories']}
            cat_map = {key: names.index(value) + 1 for key, value in class_names.items()}
            images = {x['id']: x for x in raw['images']}
            duplicate_images = len(raw['images'])-len(images)
            # The existing DIOR support JSON repeats one identical image row.
            # COCO's own image-ID dictionary already treats it as one image.
            # Do not change annotations, samples, boxes, or evaluation geometry.
            assert all(image == images[image['id']] for image in raw['images']), 'Conflicting duplicate image ID'
            image_map = {key: i + 1 for i, key in enumerate(images)}
            annotations = raw['annotations']
            assert len({x['id'] for x in annotations}) == len(annotations)
            out_of_bounds, skipped_by_parser = 0, 0
            prefix = folder / ('test' if split == 'test' else 'train')
            for image in images.values():
                assert image['width'] > 0 and image['height'] > 0
                image_path = (prefix / image['file_name']).resolve()
                assert image_path.is_relative_to(prefix.resolve())
                assert image_path.is_file(), str(image_path)
            for annotation in annotations:
                assert annotation['image_id'] in images
                assert annotation['category_id'] in cat_map
                box = annotation['bbox']
                assert len(box) == 4 and all(math.isfinite(v) for v in box)
                x, y, w, h = box
                assert w > 0 and h > 0 and annotation['area'] > 0
                image = images[annotation['image_id']]
                if x < 0 or y < 0 or x+w > image['width'] or y+h > image['height']:
                    out_of_bounds += 1
                intersection = max(0, min(x+w, image['width'])-max(x, 0)) * max(
                    0, min(y+h, image['height'])-max(y, 0))
                if intersection == 0 or w < 1 or h < 1 or annotation.get('ignore'):
                    skipped_by_parser += 1
            view = copy.deepcopy(raw)
            view['images'] = copy.deepcopy(list(images.values()))
            view['categories'] = [dict(x, id=i+1) for i, x in enumerate(categories)]
            for image in view['images']:
                image['id'] = image_map[image['id']]
            for i, annotation in enumerate(view['annotations']):
                annotation['id'] = i + 1
                annotation['image_id'] = image_map[annotation['image_id']]
                annotation['category_id'] = cat_map[annotation['category_id']]
            destination = view_folder / (split + '.json')
            write_json(destination, view)
            mapping_path = view_folder / (split + '_id_map.json')
            write_json(mapping_path, {'images': [[key, val] for key, val in image_map.items()],
                                      'categories': [[key, val] for key, val in cat_map.items()]})
            # Check every non-ID attribute is identical, including original area.
            for old, new in zip(raw['annotations'], view['annotations']):
                assert {k:v for k,v in old.items() if k not in ('id','image_id','category_id')} == {
                    k:v for k,v in new.items() if k not in ('id','image_id','category_id')}
            counts = {name: sum(class_names[a['category_id']] == name for a in annotations)
                      for name in names}
            items[split] = {'source': str(source), 'source_sha256': digest(source),
                            'view': str(destination), 'view_sha256': digest(destination),
                            'images': len(images), 'annotations': len(annotations),
                            'identical_repeated_image_rows':duplicate_images,
                            'annotations_per_class': counts, 'boxes_outside_image': out_of_bounds,
                            'parser_ignored_annotations': skipped_by_parser,
                            'ground_truth_geometry_unchanged': True}
        audit['domains'][domain] = {'classes': names, 'splits': items}
    write_json(ROOT / 'DATA_AUDIT.json', audit)
    print('DATA_AUDIT_PASS: all 18 support configurations and 6 tests', flush=True)


if __name__ == '__main__':
    main()
