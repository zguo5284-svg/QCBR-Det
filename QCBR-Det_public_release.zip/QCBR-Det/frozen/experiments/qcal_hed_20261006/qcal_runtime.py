"""Fixed-stage optimization and audited epoch-boundary checkpoints."""
import hashlib
import json
import math
import random
import shutil
import time
from pathlib import Path

import numpy as np
import torch
from mmengine.hooks import Hook
from mmengine.optim import OptimWrapper
from mmengine.registry import HOOKS, OPTIM_WRAPPERS


def model_of(runner):
    return runner.model.module if hasattr(runner.model, 'module') else runner.model


def rank():
    return torch.distributed.get_rank() if torch.distributed.is_initialized() else 0


def barrier():
    if torch.distributed.is_initialized():
        torch.distributed.barrier()


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            value.update(block)
    return value.hexdigest()


def json_write(path, obj):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2))
    temporary.replace(path)


class ControlledPause(RuntimeError):
    pass


@OPTIM_WRAPPERS.register_module()
class FixedStageOptimWrapper(OptimWrapper):
    def step(self, **kwargs):
        # Freeze parameter updates AND Adam moments, not merely their LR.
        # Keeping requires_grad stable avoids reconstructing the DDP reducer.
        for group in self.optimizer.param_groups:
            if group.get('_stage_frozen', False):
                for parameter in group['params']:
                    parameter.grad = None
        gradients = [p.grad for group in self.optimizer.param_groups
                     for p in group['params'] if p.grad is not None]
        device = self.optimizer.param_groups[0]['params'][0].device
        finite = torch.tensor(all(bool(torch.isfinite(g).all()) for g in gradients),
                              device=device, dtype=torch.int)
        if torch.distributed.is_initialized():
            torch.distributed.all_reduce(finite, op=torch.distributed.ReduceOp.MIN)
        if not finite.item():
            raise FloatingPointError('Nonfinite gradient; no optimizer update performed')
        super().step(**kwargs)


@HOOKS.register_module()
class FixedTwoStageHook(Hook):
    priority = 'VERY_HIGH'

    def __init__(self, stage2_epoch=50, total_epochs=100):
        self.stage2_epoch = stage2_epoch
        self.total_epochs = total_epochs

    def before_train(self, runner):
        names = {id(p): name for name,p in model_of(runner).named_parameters()}
        self.group_names = []
        for group in runner.optim_wrapper.optimizer.param_groups:
            group_names = [names[id(p)] for p in group['params']]
            assert group_names, 'Empty optimizer group'
            prefixes = {n.split('.')[0] for n in group_names}
            assert len(prefixes) == 1, 'Mixed groups would make stage freezing ambiguous'
            self.group_names.append(group_names[0])
        self.before_train_epoch(runner)

    def before_train_epoch(self, runner):
        root = Path(__file__).resolve().parent
        if rank() == 0 and shutil.disk_usage(root).free < 80*1024**3:
            json_write(root/'PAUSE_REQUESTED',{'reason':'free-space safety guard','at':time.time()})
        epoch = runner.epoch
        cosine = (1 + math.cos(math.pi * epoch / max(self.total_epochs-1,1))) / 2
        frozen_prefixes = ('backbone.', 'language_model.', 'encoder.')
        for name, group in zip(self.group_names, runner.optim_wrapper.optimizer.param_groups):
            frozen = epoch < self.stage2_epoch and name.startswith(frozen_prefixes)
            initial = 2e-5 if name.startswith(('backbone.', 'language_model.')) else 1e-4
            group['_stage_frozen'] = frozen
            group['lr'] = 0.0 if frozen else 1e-6 + (initial-1e-6)*cosine
        if rank() == 0 and epoch in (0,self.stage2_epoch):
            json_write(Path(runner.work_dir)/f'STAGE_{1 if epoch < self.stage2_epoch else 2}.json',
                {'epoch':epoch, 'policy':'fixed epoch; no AP feedback',
                 'frozen_prefixes': list(frozen_prefixes) if epoch < self.stage2_epoch else [],
                 'optimizer_freezing':'zero LR and absent gradients/moment updates',
                 'all_requires_grad_stable_for_DDP':True})


def mixup_transforms(runner):
    dataset = runner.train_dataloader.dataset
    return [(i,t) for i,t in enumerate(dataset.pipeline.transforms)
            if hasattr(t,'results_cache')]


@HOOKS.register_module()
class AuditedCheckpointHook(Hook):
    priority = 'LOWEST'

    def __init__(self, root, engineering=False):
        self.root = Path(root)
        self.engineering = engineering

    def after_load_checkpoint(self, runner, checkpoint):
        self.resume_states = checkpoint.get('qcal_rank_states')

    def before_train(self, runner):
        model = model_of(runner)
        if getattr(runner, '_resume', False):
            states = getattr(self, 'resume_states', None)
            assert states and len(states) == 4, 'Resume requires all four rank states'
            state_info = states[rank()]
            path = Path(state_info['path'])
            assert sha256(path) == state_info['sha256']
            state = torch.load(path, map_location='cpu')
            for index, transform in mixup_transforms(runner):
                transform.results_cache = state['augmentation_caches'][index]
            random.setstate(state['python_rng'])
            np.random.set_state(state['numpy_rng'])
            torch.set_rng_state(state['torch_rng'])
            torch.cuda.set_rng_state(state['cuda_rng'])
            if rank() == 0:
                json_write(Path(runner.work_dir)/'RESUME_PASS.json',
                    {'epoch':runner.epoch,'iter':runner.iter,
                     'all_rank_rng_and_mixup_cache_restored':True})
        elif rank() == 0:
            source = torch.load(runner.cfg.load_from, map_location='cpu')
            state_dict = source.get('state_dict', source.get('model',source))
            own = model.state_dict()
            missing = [k for k in own if k not in state_dict and
                       not k.startswith('bbox_head.quality_net.')]
            target_dependent = ['dn_query_generator.label_embedding.weight']
            expected_mismatches = [k for k in own if k in state_dict and
                                   own[k].shape != state_dict[k].shape and k in target_dependent]
            mismatched = [k for k in own if k in state_dict and
                          own[k].shape != state_dict[k].shape and k not in target_dependent]
            assert not missing and not mismatched, (missing,mismatched)
            assert all(torch.equal(own[k].cpu(),state_dict[k]) for k in own
                       if k in state_dict and k not in expected_mismatches and
                       not k.startswith('bbox_head.quality_net.'))
            assert not torch.count_nonzero(model.bbox_head.quality_net[-1].weight)
            json_write(Path(runner.work_dir)/'SOURCE_COVERAGE_PASS.json',
                {'covered_keys':len(own)-len([k for k in own if k.startswith('bbox_head.quality_net.')])-len(expected_mismatches),
                 'missing_existing_keys':missing,'shape_mismatches':mismatched,
                 'expected_target_class_DN_embedding_reinitialization':expected_mismatches,
                 'source_sha256':sha256(runner.cfg.load_from)})
            del source,state_dict,own
        barrier()
        if self.engineering and not getattr(runner,'_resume',False):
            self.frozen_snapshot = {n:p.detach().cpu().clone() for n,p in model.named_parameters()
                                    if n.startswith(('backbone.','language_model.','encoder.'))}
            self.qcal_snapshot = model.bbox_head.quality_net[-1].weight.detach().cpu().clone()

    def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        if rank() == 0:
            values = {key:float(value) for key,value in (outputs or {}).items()}
            assert all(math.isfinite(v) for v in values.values()), values
            diag = model_of(runner).bbox_head.last_quality_diagnostics
            assert diag['finite']
            json_write(Path(runner.work_dir)/'PROGRESS.json',
                {'status':'TRAINING','epoch':runner.epoch,'completed_iter':runner.iter+1,
                 'epoch_batch':batch_idx+1,'batches_per_epoch':len(runner.train_dataloader),
                 'time':time.time(),'losses':values,'quality':diag})

    def after_train_epoch(self, runner):
        completed = runner.epoch + 1
        pause = (self.root / 'PAUSE_REQUESTED').exists()
        if self.engineering and completed == 1 and hasattr(self,'frozen_snapshot'):
            model = model_of(runner)
            params = dict(model.named_parameters())
            assert all(torch.equal(params[n].cpu(),v) for n,v in self.frozen_snapshot.items())
            assert not torch.equal(model.bbox_head.quality_net[-1].weight.cpu(), self.qcal_snapshot)
            if rank() == 0:
                json_write(Path(runner.work_dir)/'STAGE1_FREEZE_AND_QUALITY_PASS.json',
                    {'all_frozen_parameters_unchanged':True,'quality_head_updated':True})
        if self.engineering and completed == runner.max_epochs and hasattr(self,'frozen_snapshot'):
            params = dict(model_of(runner).named_parameters())
            changed = {prefix:any(not torch.equal(params[n].cpu(),value)
                                  for n,value in self.frozen_snapshot.items() if n.startswith(prefix))
                       for prefix in ('backbone.','language_model.','encoder.')}
            assert all(changed.values()), changed
            if rank() == 0:
                json_write(Path(runner.work_dir)/'STAGE2_UNFREEZE_PASS.json',changed)
            del self.frozen_snapshot
        should_save = self.engineering or completed % 10 == 0 or pause or completed == runner.max_epochs
        if not should_save:
            return
        work = Path(runner.work_dir)
        state_path = work / f'rank_state_epoch{completed:03d}_rank{rank()}.pth'
        caches = {i:t.results_cache for i,t in mixup_transforms(runner)}
        payload = {'epoch':completed, 'iter':runner.iter,
                   'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),
                   'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state(),
                   'augmentation_caches':caches}
        temporary = state_path.with_suffix('.tmp')
        torch.save(payload,temporary)
        temporary.replace(state_path)
        self.state_info = {'path':str(state_path),'sha256':sha256(state_path)}
        info = [None] * 4
        torch.distributed.all_gather_object(info,self.state_info)
        self.rank_states = info
        if rank() == 0:
            filename = 'checkpoint_pending.pth'
            runner.save_checkpoint(str(work),filename,save_optimizer=True,
                                   save_param_scheduler=False,by_epoch=True)
            pending = work/filename
            restored = torch.load(pending,map_location='cpu')
            assert restored['meta']['epoch'] == completed
            assert 'optimizer' in restored and len(restored['qcal_rank_states']) == 4
            own = model_of(runner).state_dict()
            assert all(torch.equal(t.cpu(),restored['state_dict'][n]) for n,t in own.items())
            del restored,own
            latest = work/'checkpoint_latest.pth'
            if latest.exists():
                latest.replace(work/'checkpoint_previous.pth')
            pending.replace(latest)
            json_write(work/'LAST_CHECKPOINT.json',
                {'path':str(latest),'sha256':sha256(latest),'completed_epoch':completed,
                 'completed_iter':runner.iter,'readback_exact':True,'rank_states':info})
            if pause:
                json_write(work/'PAUSED.json',{'completed_epoch':completed,'time':time.time()})
        barrier()
        if pause:
            raise ControlledPause('User pause: checkpoint and all four rank states saved')

    def before_save_checkpoint(self,runner,checkpoint):
        checkpoint['qcal_rank_states'] = self.rank_states
        checkpoint['qcal_plan_sha256'] = sha256(self.root/'PLAN.json')
