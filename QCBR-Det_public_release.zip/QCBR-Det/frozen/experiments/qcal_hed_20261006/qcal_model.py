"""Support-only quality learning on the published HED detector.

This module does not use evaluation annotations, choose checkpoints, or tune AP.
The HED architecture remains attributed to FT-FSOD. Calibration is a candidate.
"""
import functools

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint
from mmcv.ops import roi_align
from mmengine.structures import InstanceData
from mmdet.registry import MODELS
from mmdet.models.detectors.grounding_dino_HED import (
    GroundingDINO_ParallelDecoder_15_DNQuery_rand,
)
from mmdet.models.dense_heads.grounding_dino_head_HED import (
    GroundingDINOHead_ParallelDecoder_DN,
)
from mmdet.models.dense_heads.atss_vlfusion_head import (
    convert_grounding_to_cls_scores,
)
from mmdet.structures.bbox import bbox_cxcywh_to_xyxy, bbox_overlaps
import mmdet.models.layers.transformer.grounding_dino_layers as encoder_module
import mmdet.models.layers.transformer.grounding_dino_layers_HED as hed_module


def nonreentrant_wrapper(module):
    """Checkpoint activations without adding state-dict prefixes."""
    original = module.forward

    @functools.wraps(original)
    def forward(*args, **kwargs):
        if module.training and torch.is_grad_enabled():
            return checkpoint(original, *args, use_reentrant=False, **kwargs)
        return original(*args, **kwargs)

    module.forward = forward
    return module


# The author's fairscale wrapper is reentrant. Use the same forward with the
# PyTorch non-reentrant variant to support the fixed-stage DDP optimizer.
encoder_module.checkpoint_wrapper = nonreentrant_wrapper
hed_module.checkpoint_wrapper = nonreentrant_wrapper


@MODELS.register_module()
class QCalHEDDetector(GroundingDINO_ParallelDecoder_15_DNQuery_rand):
    def forward_decoder(self, query, memory, memory_mask, reference_points,
                        spatial_shapes, level_start_index, valid_ratios,
                        dn_mask=None, additional_dn_items=None, **kwargs):
        output = super().forward_decoder(
            query=query, memory=memory, memory_mask=memory_mask,
            reference_points=reference_points, spatial_shapes=spatial_shapes,
            level_start_index=level_start_index, valid_ratios=valid_ratios,
            dn_mask=dn_mask, additional_dn_items=additional_dn_items, **kwargs)
        output.update(quality_memory=memory.detach(),
                      quality_shapes=spatial_shapes,
                      quality_ratios=valid_ratios,
                      quality_mask=memory_mask)
        return output


@MODELS.register_module()
class QCalHEDHead(GroundingDINOHead_ParallelDecoder_DN):
    def __init__(self, shot, quality_hidden=64, quality_weight=0.1,
                 quality_strength=0.25, matching_queries=900, **kwargs):
        super().__init__(**kwargs)
        assert shot in (1, 5, 10)
        self.shot = shot
        self.quality_weight = quality_weight
        self.quality_strength = quality_strength * shot / (shot + 2)
        self.matching_queries = matching_queries
        self.quality_net = nn.Sequential(
            nn.LayerNorm(2 * self.embed_dims),
            nn.Linear(2 * self.embed_dims, quality_hidden), nn.SiLU(),
            nn.Linear(quality_hidden, 1))
        self.reset_quality_output()

    def reset_quality_output(self):
        nn.init.zeros_(self.quality_net[-1].weight)
        nn.init.zeros_(self.quality_net[-1].bias)

    def init_weights(self):
        super().init_weights()
        self.reset_quality_output()

    def quality_logits(self, hidden_states, boxes, quality_memory,
                       quality_shapes, quality_ratios, quality_mask):
        """Mean query + padding-aware region mean from finest encoder level.

        Boxes are normalized to the unpadded image. valid_ratios converts them
        to the padded encoder grid; no ground truth enters this operation.
        """
        states = hidden_states[:, :, -self.matching_queries:].mean(0).detach()
        boxes = boxes.detach()
        batch, queries, channels = states.shape
        h, w = map(int, quality_shapes[0].tolist())
        feature = quality_memory[:, :h*w].detach().float()
        feature = feature.transpose(1, 2).reshape(batch, channels, h, w)
        if quality_mask is None:
            valid = feature.new_ones(batch, 1, h, w)
        else:
            valid = (~quality_mask[:, :h*w]).float().reshape(batch, 1, h, w)
        xyxy = bbox_cxcywh_to_xyxy(boxes).clamp(0, 1)
        ratio = quality_ratios[:, 0]
        scale = torch.stack([ratio[:, 0]*w, ratio[:, 1]*h,
                             ratio[:, 0]*w, ratio[:, 1]*h], dim=-1)
        xyxy = xyxy * scale[:, None]
        indices = torch.arange(batch, device=boxes.device, dtype=xyxy.dtype)
        indices = indices[:, None, None].expand(batch, queries, 1)
        rois = torch.cat([indices, xyxy], -1).reshape(-1, 5).contiguous()
        numerator = roi_align(feature * valid, rois, (3, 3),
                              1.0, 2, 'avg', True).mean((2, 3))
        denominator = roi_align(valid, rois, (3, 3),
                                1.0, 2, 'avg', True).mean((2, 3))
        regions = (numerator / denominator.clamp_min(1e-6)).reshape(
            batch, queries, channels)
        features = torch.cat([states.float(), regions], -1).detach()
        return self.quality_net(features).squeeze(-1)

    def multiplier(self, logits):
        return 1 + self.quality_strength * (2 * logits.sigmoid() - 1)

    def loss(self, hidden_states, references, memory_text, text_token_mask,
             enc_outputs_class, enc_outputs_coord, batch_data_samples, dn_meta,
             quality_memory, quality_shapes, quality_ratios, quality_mask):
        classes, coordinates = self(hidden_states, references, memory_text,
                                    text_token_mask)
        gt = [sample.gt_instances for sample in batch_data_samples]
        metas = [sample.metainfo for sample in batch_data_samples]
        self.text_masks = text_token_mask
        losses = self.loss_by_feat(classes, coordinates, enc_outputs_class,
                                   enc_outputs_coord, gt, metas, dn_meta)
        boxes = coordinates[:, :, -self.matching_queries:].detach().mean(0)
        logits = self.quality_logits(hidden_states, boxes, quality_memory,
                                     quality_shapes, quality_ratios, quality_mask)
        # Match the prediction ensemble, not a denoising query or a GT region.
        scores = classes[:, :, -self.matching_queries:].detach().sigmoid().mean(0)
        raw_scores = torch.logit(scores.clamp(1e-6, 1-1e-6))
        per_image = []
        positive_count = 0
        for index, (instances, meta) in enumerate(zip(gt, metas)):
            with torch.no_grad():
                ih, iw = meta['img_shape'][:2]
                pixel_boxes = bbox_cxcywh_to_xyxy(boxes[index]) * boxes.new_tensor(
                    [iw, ih, iw, ih])
                assignment = self.assigner.assign(
                    InstanceData(scores=raw_scores[index], bboxes=pixel_boxes),
                    instances, meta)
                positive = torch.where(assignment.gt_inds > 0)[0]
                if len(positive):
                    matched = assignment.gt_inds[positive] - 1
                    targets = bbox_overlaps(pixel_boxes[positive],
                                            instances.bboxes[matched],
                                            is_aligned=True).clamp(0, 1)
            if len(positive):
                per_image.append(F.binary_cross_entropy_with_logits(
                    logits[index, positive], targets, reduction='sum'))
                positive_count += len(positive)
        # All ranks retain the quality graph even when a crop contains no GT.
        zero = logits.sum() * 0
        numerator = sum(per_image, zero)
        # Normalize globally so unequal object counts do not overweight ranks.
        count = logits.new_tensor(float(positive_count))
        if torch.distributed.is_initialized():
            torch.distributed.all_reduce(count)
            count /= torch.distributed.get_world_size()
        losses['loss_quality'] = self.quality_weight * numerator / count.clamp_min(1)
        self.last_quality_diagnostics = dict(
            positives=positive_count, finite=bool(torch.isfinite(logits).all()),
            mean_quality=float(logits.detach().sigmoid().mean()))
        return losses

    def predict(self, hidden_states, references, memory_text, text_token_mask,
                batch_data_samples, quality_memory, quality_shapes,
                quality_ratios, quality_mask, rescale=True):
        classes, coordinates = self(hidden_states, references, memory_text,
                                    text_token_mask)
        boxes = coordinates.mean(0)
        logits = self.quality_logits(hidden_states, boxes, quality_memory,
                                     quality_shapes, quality_ratios, quality_mask)
        factors = self.multiplier(logits)
        predictions = []
        for index, sample in enumerate(batch_data_samples):
            positive_map = sample.token_positive_map
            layer_scores = []
            for layer in classes:
                if positive_map is None:
                    score = layer[index].sigmoid()
                else:
                    score = convert_grounding_to_cls_scores(
                        layer[index].sigmoid()[None], [positive_map])[0]
                layer_scores.append(score)
            scores = torch.stack(layer_scores).mean(0)
            # Calibrate the full query pool BEFORE candidate top-k selection.
            scores = scores * factors[index, :, None]
            predictions.append(self._predict_by_feat_single(
                scores, boxes[index], positive_map, sample.metainfo, rescale))
        return predictions
