"""Fixed configs: no test-set validation, AP scheduler, or best-AP checkpoint."""
import json
from pathlib import Path
from mmengine.config import Config

ROOT = Path(__file__).resolve().parent
BASE = Path('/root/autodl-tmp/vfmdetr_repro')


def make_config(domain, shot, work_dir, engineering=False):
    cfg = Config.fromfile(str(ROOT / 'FT-FSOD/configs_cdfsod/grounding_dino_swin-b_pretrain_all.py'))
    audit = json.loads((ROOT / 'DATA_AUDIT.json').read_text())['domains'][domain]
    classes = tuple(audit['classes'])
    cfg.custom_imports = dict(imports=['qcal_model', 'qcal_runtime'], allow_failed_imports=False)
    cfg.model.type = 'QCalHEDDetector'
    cfg.model.rand_dnquery_rate = 0.5
    cfg.model.language_model.name = str(ROOT / 'assets/bert-base-uncased')
    cfg.model.language_model.init_from_config = True
    cfg.model.bbox_head.update(type='QCalHEDHead', num_classes=len(classes), shot=shot,
                               quality_hidden=64, quality_weight=0.1,
                               quality_strength=0.25, matching_queries=900)
    cfg.model.test_cfg = dict(max_per_img=300)
    train_pipeline = [
        dict(type='LoadImageFromFile'), dict(type='LoadAnnotations', with_bbox=True),
        dict(type='YOLOXHSVRandomAug'), dict(type='RandomFlip', prob=0.5),
        dict(type='CachedMixUp', img_scale=(640, 640), ratio_range=(1.0, 1.0),
             max_cached_images=10, pad_val=(114, 114, 114), prob=0.3),
        dict(type='RandomChoice', transforms=[
            [dict(type='RandomChoiceResize', scales=[(800,1333),(768,1333),(960,1333)], keep_ratio=True)],
            [dict(type='RandomChoiceResize', scales=[(600,4200),(800,4200),(960,4200)], keep_ratio=True),
             dict(type='HumanityRandomCrop', crop_type='absolute_range',
                  crop_size=(640,960), allow_negative_crop=True),
             dict(type='RandomChoiceResize', scales=[(800,1333),(768,1333),(960,1333)], keep_ratio=True)]
        ]),
        dict(type='PackDetInputs', meta_keys=('img_id','img_path','ori_shape','img_shape',
                                            'scale_factor','flip','flip_direction','text','custom_entities'))]
    test_pipeline = [
        dict(type='LoadImageFromFile', imdecode_backend='pillow'),
        dict(type='FixScaleResize', scale=(800,1333), keep_ratio=True, backend='pillow'),
        # GT is read by the evaluator only; prediction receives no GT boxes.
        dict(type='PackDetInputs', meta_keys=('img_id','img_path','ori_shape','img_shape',
                                            'scale_factor','text','custom_entities','tokens_positive'))]
    cfg.train_dataloader = dict(batch_size=1, num_workers=0, persistent_workers=False,
        sampler=dict(type='DefaultSampler', shuffle=True),
        dataset=dict(type='CocoDataset', metainfo=dict(classes=classes),
                     ann_file=audit['splits'][f'{shot}_shot']['view'],
                     data_prefix=dict(img=str(BASE / 'datasets' / domain / 'train')),
                     return_classes=True, filter_cfg=dict(filter_empty_gt=False, min_size=32),
                     pipeline=train_pipeline))
    cfg.test_dataloader = dict(batch_size=1, num_workers=0, persistent_workers=False,
        drop_last=False, sampler=dict(type='DefaultSampler', shuffle=False),
        dataset=dict(type='CocoDataset', metainfo=dict(classes=classes),
                     ann_file=audit['splits']['test']['view'],
                     data_prefix=dict(img=str(BASE / 'datasets' / domain / 'test')),
                     return_classes=True, test_mode=True, pipeline=test_pipeline))
    cfg.val_dataloader = cfg.val_evaluator = cfg.val_cfg = None
    cfg.test_cfg = dict(type='TestLoop')
    cfg.test_evaluator = dict(type='CocoMetric', metric='bbox', format_only=True,
        ann_file=audit['splits']['test']['view'], outfile_prefix=str(Path(work_dir) / 'predictions'))
    cfg.train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=2 if engineering else 100,
                         val_interval=101)
    cfg.optim_wrapper = dict(type='FixedStageOptimWrapper',
        optimizer=dict(type='AdamW', lr=1e-4, weight_decay=0.05),
        clip_grad=dict(max_norm=0.1, norm_type=2),
        paramwise_cfg=dict(custom_keys={'absolute_pos_embed':dict(decay_mult=0),
                                       'backbone':dict(lr_mult=0.2),
                                       'language_model':dict(lr_mult=0.2)}))
    cfg.param_scheduler = []
    cfg.auto_scale_lr = dict(enable=False, base_batch_size=4)
    cfg.default_hooks = dict(timer=dict(type='IterTimerHook'),
                             logger=dict(type='LoggerHook', interval=5),
                             sampler_seed=dict(type='DistSamplerSeedHook'),
                             checkpoint=None, param_scheduler=None)
    cfg.custom_hooks = [dict(type='FixedTwoStageHook', stage2_epoch=1 if engineering else 50,
                             total_epochs=2 if engineering else 100),
                        dict(type='AuditedCheckpointHook', root=str(ROOT),
                             engineering=engineering)]
    cfg.model_wrapper_cfg = dict(type='MMDistributedDataParallel',
                                 find_unused_parameters=True, broadcast_buffers=False)
    cfg.randomness = dict(seed=0, diff_rank_seed=False, deterministic=False)
    cfg.env_cfg = dict(cudnn_benchmark=False,
                       mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
                       dist_cfg=dict(backend='nccl', timeout=600))
    cfg.log_processor = dict(type='LogProcessor', window_size=5, by_epoch=True)
    cfg.visualizer = dict(type='DetLocalVisualizer', vis_backends=[], name='visualizer')
    cfg.work_dir = str(work_dir)
    cfg.launcher = 'pytorch'
    cfg.load_from = str(ROOT / 'assets/grounding_dino_swin-b_pretrain_all-f9818a7c.pth')
    cfg.resume = False
    return cfg
