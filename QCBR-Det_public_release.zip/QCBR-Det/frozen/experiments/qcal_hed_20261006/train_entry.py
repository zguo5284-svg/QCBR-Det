"""Four-rank training or inference entry; runs only fixed configs."""
import argparse
import json
import os
import sys
from pathlib import Path

os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
import torch
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from qcal_config import make_config
from qcal_runtime import ControlledPause, json_write, rank
from mmdet.utils import register_all_modules


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--domain',required=True)
    parser.add_argument('--shot',type=int,required=True)
    parser.add_argument('--work-dir',required=True)
    parser.add_argument('--engineering',action='store_true')
    parser.add_argument('--resume')
    parser.add_argument('--test',action='store_true')
    parser.add_argument('--support-smoke',action='store_true')
    args = parser.parse_args()
    register_all_modules(init_default_scope=True)
    cfg = make_config(args.domain,args.shot,args.work_dir,args.engineering)
    import_modules_from_strings(**cfg.custom_imports)
    if args.resume:
        cfg.load_from = args.resume
        cfg.resume = not args.test
    if args.support_smoke:
        root = Path(__file__).resolve().parent
        audit = json.loads((root/'DATA_AUDIT.json').read_text())['domains'][args.domain]
        cfg.test_dataloader.dataset.ann_file = audit['splits'][f'{args.shot}_shot']['view']
        cfg.test_dataloader.dataset.data_prefix.img = cfg.train_dataloader.dataset.data_prefix.img
        cfg.test_evaluator.ann_file = cfg.test_dataloader.dataset.ann_file
        cfg.test_evaluator.outfile_prefix = str(Path(args.work_dir)/'support_smoke')
    if not args.test:
        Path(args.work_dir).mkdir(parents=True,exist_ok=True)
    runner = Runner.from_cfg(cfg)
    if args.test:
        assert args.resume and Path(args.resume).is_file()
        runner.test()
    else:
        runner.train()
        if rank() == 0:
            json_write(Path(args.work_dir)/'TRAIN_COMPLETE.json',
                {'domain':args.domain,'shot':args.shot,'seed':0,
                 'completed_epochs':runner.epoch,'completed_iter':runner.iter,
                 'selection':'fixed final epoch, no test AP selection',
                 'engineering':args.engineering})


if __name__ == '__main__':
    try:
        main()
    except ControlledPause as error:
        print(str(error),flush=True)
        if torch.distributed.is_initialized():
            torch.distributed.destroy_process_group()
        sys.exit(75)
